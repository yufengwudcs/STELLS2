//
//  GSTProbComposite.cpp
//  
//
//  Created by Yufeng Wu on 1/18/16.
//
//

#include "GSTProbComposite.h"
#include "STBranchLenFinder.h"

//////////////////////////////////////////////////////////////////////////////////
// Calc tree prob from look-up interface

const int SZ_DEF_SUBSET_TAXA = 2;
int GeneTreeProbComposite :: szSubsetTaxaSz = SZ_DEF_SUBSET_TAXA;

GeneTreeProbComposite :: GeneTreeProbComposite( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn ) : treeSpecies(treeSpeciesIn), treeGene(treeGeneIn)
{
    string nwt;
    treeGene.ConsNewick(nwt, false, 1.0, true);
    treeGeneUse.ConsOnNewick( nwt );
    AssignConsecutiveIdsForTree(treeGeneUse);
    //cout << "treeGeneUse: ";
    //treeGeneUse.Dump();
    //string nwt3;
    //treeGeneUse.ConsNewick(nwt3);
    //cout << "Newick of treeGeneUse: " << nwt3 << endl;
    
    //cout << nwt << endl;
    // get the subtree that we will use
    set<int> species;
    GetLeavesSpeciesFromGT( treeGeneUse, species );
    //cout << "species found in gene tree: ";
    //DumpIntSet(species);
    CreateSubtreeFromLeaves( treeSpecies, species, treeSpeciesUse, mapNewNodeToOldNode );
#if 0
    cout << "Original species tree: " << treeSpecies.GetNewick() << endl;
    cout << "Constructed treeSpeciesUse:" << treeSpeciesUse.GetNewick() << endl;
    for( map<int,int> :: iterator it = mapNewNodeToOldNode.begin(); it != mapNewNodeToOldNode.end(); ++it )
    {
        //
        cout << "mapNewNodeToOldNodeTemp: " << it->first << " was originally " << it->second << endl;
    }
#endif
    
#if 0
    // re-map the species to consecutive ids
    map<int,int> mapLblsToConsecutiveIds;
    int idToUse = 0;
    for(set<int> :: iterator it = species.begin(); it != species.end(); ++it)
    {
        mapLblsToConsecutiveIds.insert( map<int,int> :: value_type(*it,idToUse++) );
    }
    treeSpeciesUse.RemapLeafLabels( mapLblsToConsecutiveIds );
    //cout << "After remapping treeSpeciesUse:" << treeSpeciesUse.GetNewick() << endl;
    
    // change the gene tree labels
    //cout << "Within: GeneTreeProbLookup :: GeneTreeProbLookup:\n";
    ChangeLeafIntLabelOfTree( treeGeneUse, mapLblsToConsecutiveIds );
#endif
}

GeneTreeProbComposite :: ~GeneTreeProbComposite()
{
}

void GeneTreeProbComposite :: SetSubsetTaxaSize(int sz)
{
    szSubsetTaxaSz = sz;
}

double GeneTreeProbComposite :: CalcProb()
{
    double logprob = CalcLogProb();
    return exp( logprob );
}

double GeneTreeProbComposite :: CalcLogProb()
{
    //cout << "&&&&&&&&&&&&&&&&& CALCLOGPROB" << endl;
    // use the composite prob
    double res = 0.0;
    
    map<set<int>,MarginalTree> mapSubSTrees;
    map<set<int>,map<int,int> > mapMapOldTaxaToNew;
    GenSubSTreeSets( mapSubSTrees, mapMapOldTaxaToNew );
    for( map<set<int>,MarginalTree> :: iterator it = mapSubSTrees.begin(); it != mapSubSTrees.end(); ++it )
    {
#if 0
        cout << "Set of taxa: ";
        DumpIntSet(it->first);
        cout << "sub-species-tree: " << it->second.GetNewick() << endl;
#endif
        PhylogenyTreeBasic phtreeSub;
        CreateSubGTree( it->first, mapMapOldTaxaToNew[it->first], phtreeSub );
#if 0
        string strNWPhsub;
        phtreeSub.ConsNewick( strNWPhsub );
        cout << "CalcLogProb:created sub-genetree: " << strNWPhsub << endl;
#endif
        
        MarginalTree &mtree = const_cast<MarginalTree &>(it->second);
        
        // compute this
        GenericGeneSpeciesTreeProb *pComp = CreateGeneTreeProbCompNoComposite( mtree, phtreeSub );
        double probstep = pComp->CalcLogProb();
        delete pComp;
//cout << "FOUND PROB: " << probstep << endl;
        res += probstep;
    }
    
    return res;
}

// attempt to change a branch to a new length, and update the prob. Since we may need to recover the original
// unchanged probs, we just save those changed one (i.e. keep a copy of what was there before)
double GeneTreeProbComposite :: TestNewBranchLenAt(int threadId, int branch, double lenNew, map<int,set< LineageConfig,LTLinCfg > > &origLinCfgs, bool fSetBrlen )
{
    //cout << "Testing: branch: " << branch << " to new length: " << lenNew << endl;
    // simply set the ebranch length
    double brOld = GetSTBranchLen( branch );
    if( fSetBrlen == true )
    {
        SetSTBranchLen(branch, lenNew);
    }
    double res = CalcLogProb();
    
    // set the old branch length back
    if( fSetBrlen == true )
    {
        SetSTBranchLen( branch, brOld );
    }
    
    //cout << "Species tree after testing: ";
    //treeSpeciesUse.Dump();
    
    return res;
}

void GeneTreeProbComposite ::SetLinCfgs(map<int,set< LineageConfig,LTLinCfg > > &linCfgsToSet)
{
    // do noothing
}

void GeneTreeProbComposite :: SetSTBranchLen(int br, double brLen)
{
    treeSpecies.SetBranchLen(br, brLen);
    
    // now should set the branch length of the used species tree
    UpdateBranchLenInSubtree( treeSpecies, this->mapNewNodeToOldNode, treeSpeciesUse );
}
int GeneTreeProbComposite :: GetTaxaAtLeafST(int snid)
{
    if( treeSpecies.IsLeaf(snid) == false )
    {
        return -1;
    }
    //cout << "GetTaxaAtLeafST: " << snid << endl;
	// get the taxa id from a particular leaf node of species tree
	// treat the species tree label
	//YW_ASSERT_INFO( treeSpecies.IsLeaf(snid) == true, "Must be a leaf1" );
	return treeSpecies.GetLabel(snid);
}
void GeneTreeProbComposite :: GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles)
{
    //
    geneAlleles.clear();
    //cout << "GetGeneAllelesForSpecies: taxon = " << taxon << endl;
	// get all alleles in GT for a gene
	char idbuf[100];
	sprintf(idbuf, "%d", taxon);
	string idstr = idbuf;
	// search for each leaf, to find match
	treeGeneUse.GetLeavesIdsWithLabel(  idstr, geneAlleles );
}

// create list of subtrees to work with
void GeneTreeProbComposite :: GenSubSTreeSets( map<set<int>,MarginalTree> &mapSubSTrees, map<set<int>,map<int,int> > &mapMapOldTaxaToNew )
{
    // if the species tree is small enough, just use it
    if( treeSpeciesUse.GetNumLeaves() <= szSubsetTaxaSz )
    {
        //cout << "DIRECTLY using the whole trees..." << endl;
        set<int> ss;
        PopulateSetWithInterval(ss, 0, treeSpeciesUse.GetNumLeaves()-1);
        map<int,int> mapss;
        for(int i=0; i<treeSpeciesUse.GetNumLeaves(); ++i)
        {
            mapss.insert( map<int,int> :: value_type(i,i) );
        }
        mapSubSTrees.insert( map<set<int>,MarginalTree>  :: value_type( ss, treeSpeciesUse ) );
        mapMapOldTaxaToNew.insert( map<set<int>,map<int,int> > :: value_type(ss, mapss) );
        return;
    }
    
    // enumerate all the subsets
    vector<int> posvec;
    GetFirstCombo(szSubsetTaxaSz, treeSpeciesUse.GetNumLeaves(), posvec);
    while(true)
    {
        set<int> sschoices;
        PopulateSetByVec( sschoices, posvec );
        map<int,int> mapNewNodeToOldNodeStep;
        MarginalTree mTreeSub;
        CreateSubtreeFromLeaves( treeSpeciesUse, sschoices, mTreeSub, mapNewNodeToOldNodeStep );
#if 0
        cout << "GenSubSTreeSets: mapNewNodeToOldNodeStep:";
        for(map<int,int> :: iterator it= mapNewNodeToOldNodeStep.begin(); it !=mapNewNodeToOldNodeStep.end(); ++it)
        {
            cout << "[" << it->first << "," << it->second << "]  ";
        }
        cout << endl;
#endif
        
        mTreeSub.ResetIncLabel();   // the subtree is now using the original taxa name; so we just make it using the conventional 0,1,2,....
        mapSubSTrees.insert( map<set<int>,MarginalTree>  :: value_type( sschoices,mTreeSub ) );
        mapMapOldTaxaToNew.insert( map<set<int>,map<int,int> > :: value_type(sschoices, mapNewNodeToOldNodeStep) );
        
        if( GetNextCombo(szSubsetTaxaSz, treeSpeciesUse.GetNumLeaves(), posvec) == false )
        {
            break;
        }
    }
}

void GeneTreeProbComposite :: CreateSubGTree( const set<int> &ssTaxa, map<int,int> &mapMapOldTaxaToNew, PhylogenyTreeBasic &phtreeSub )
{
#if 0
    cout << "^^^^CreateSubGTree: mapMapOldTaxaToNew:";
    for(map<int,int> :: iterator it= mapMapOldTaxaToNew.begin(); it !=mapMapOldTaxaToNew.end(); ++it)
    {
        cout << "[" << it->first << "," << it->second << "]  ";
    }
    cout << endl;
#endif
    //
    set<string> ssSelected;
    for(set<int> :: iterator it = ssTaxa.begin(); it != ssTaxa.end(); ++it)
    {
        //
        char buf[1000];
        sprintf(buf,"%d", *it);
        string strbuf = buf;
        ssSelected.insert(strbuf);
    }
    
    treeGeneUse.CreatePhyTreeFromLeavesWithLabels( ssSelected, phtreeSub, false );
#if 0
    string strNWPhsub;
    phtreeSub.ConsNewick( strNWPhsub );
    cout << "Beore chaing leaf label: sub-genetree: " << strNWPhsub << endl;
#endif
    
    // map the old taxa back to new
    ChangeLeafIntLabelOfTree( phtreeSub, mapMapOldTaxaToNew );
    // also change the user label
    phtreeSub.SetLabelsToCurrUserLabels();
}


