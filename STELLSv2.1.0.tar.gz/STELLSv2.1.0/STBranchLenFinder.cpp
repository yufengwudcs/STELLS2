#include "STBranchLenFinder.h"
#include "FixedSTGeneTreeProb.h"
#include "GSTProbComposite.h"
#include <cmath>
#include "pthread.h"
#include "ApproxGeneTreeProb.h"
#include "UtilsNumerical.h"

//const double DEFAULT_GRID_LEN = 0.05;
const double DEFAULT_GRID_LEN = 0.1;

// hill climb param
const double MIN_LIKELIHOOD_INC_RATIO = 1.05;
const double MIN_LOGLIKELI_INC = log(MIN_LIKELIHOOD_INC_RATIO);


//////////////////////////////////////////////////////////////////////////////////

static int numThreads = 1;
const int MAX_ITER_APPROX = 2;
//static int numSubsetSz = 2;
//static bool fApproxLikelihood = false;
static bool fCompositeLikelihood = false;
bool fApproxLikelihood = false;

void SetNumThreads(int nt)
{
    numThreads = nt;
}

int GetNumThreads()
{
    return numThreads;
}

//void ChangeToApproxLikelihood(char *filenamePrestoredProbs)
//{
//    //fApproxLikelihood = true;
//    YW_ASSERT_INFO(false, "Not implemented yet");
//}

void SetCompositeProb(bool fComposite)
{
    //
    fCompositeLikelihood = fComposite;
}

void SetSubsetTaxaSize(int sz)
{
    GeneTreeProbComposite :: SetSubsetTaxaSize(sz);
}

bool IsApproxLikelihood()
{
    //return false;
    return fApproxLikelihood;
}

void SetApproxLikelihood(bool f)
{
    fApproxLikelihood = f;
}

GenericGeneSpeciesTreeProb *CreateGeneTreeProbComp(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene)
{
    GenericGeneSpeciesTreeProb *gstProb=NULL;
    if( IsFixedCoalMode() == false && IsApproxLikelihood() == false && fCompositeLikelihood == false )
    {
        gstProb = new GeneSpeciesTreeProb(treeSpecies, treeGene);
    }
    else if( IsFixedCoalMode() == true && fCompositeLikelihood == false )
    {
        gstProb = new FastGeneTreeProbFixedSpecies(treeSpecies, treeGene);
    }
    else if( fCompositeLikelihood == true )
    {
        //
        gstProb = new GeneTreeProbComposite(treeSpecies, treeGene);
    }
    else if( IsApproxLikelihood() == true )
    {
        //
        gstProb = new ApproxGeneTreeProb(treeSpecies, treeGene);
    }

    YW_ASSERT_INFO( gstProb != NULL, "FATAL error: fail to initialize the computing tool" );
    return gstProb;
}

GenericGeneSpeciesTreeProb * CreateGeneTreeProbCompNoComposite(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene)
{
    //
    GenericGeneSpeciesTreeProb *gstProb=NULL;
    if( IsFixedCoalMode() == false && IsApproxLikelihood() == false )
    {
        gstProb = new GeneSpeciesTreeProb(treeSpecies, treeGene);
    }
    else if( IsFixedCoalMode() == true )
    {
        gstProb = new FastGeneTreeProbFixedSpecies(treeSpecies, treeGene);
    }

    YW_ASSERT_INFO( gstProb != NULL, "FATAL error: fail to initialize the computing tool" );
    return gstProb;
}

//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

STBranchLenFinder :: STBranchLenFinder( const vector<PhylogenyTreeBasic *> &listGTP, 
									   const MarginalTree &stInit, double minBL, double maxBL ): 
listGTreePtrs(listGTP), speciesTreeBest(stInit),
minBranchLen(minBL), maxBranchLen(maxBL), maxBranchOptRounds(HAP_MAX_INT), fBrentMode(true), knownLikeliOtherTree( -1.0*HAP_MAX_INT )
{
//cout << "STBranchLenFinder: species tree is " << stInit.GetNewick() << endl;
    
    
	// setup default multiplicity
	for(int i=0; i<(int)listGTP.size(); ++i)
	{
		listGTreeMultiplicty.push_back(1);
	}
	gridBranchLen = DEFAULT_GRID_LEN;
	logHillClimbRatio = MIN_LOGLIKELI_INC;
	// in case minBranchLen is small, we will use it
	if( minBL < gridBranchLen )
	{
		gridBranchLen = minBL;
	}
//cout << "*************************+++++++++++++++++++++++++++++++++++ minloglilike inc = " << MIN_LOGLIKELI_INC << endl;
}

STBranchLenFinder :: ~STBranchLenFinder()
{
	for(int i=0; i<	(int)listGSTProbFinder.size(); ++i)
	{
		delete listGSTProbFinder[i];
	}
	listGSTProbFinder.clear();
}

double STBranchLenFinder :: HillClimbBranchLen( MarginalTree &treeRes )
{
    ApproxGTPStats::Instance().RecordBranchLenOpt();
    
    return OptBranchLenByBFGS( treeRes );
    
#if 0
    
#if 0
for(int i=0; i<(int)listGTreePtrs.size(); ++i)
{
cout << "Gene tree: ";
string strNW;
listGTreePtrs[i]->ConsNewick(strNW);
cout << "In STBranchLenFinder: gene tree: " << strNW << endl;
}
    
cout << "HillClimbBranchLen: tree is: ";
speciesTreeBest.Dump();
#endif
	// this is based on
//	const double FRACTION_ITER_INC = 0.2;

	// initialize first
	//Init();

//cout << "STBranchLenFinder: Multiplicity = ";
//DumpIntVec(listGTreeMultiplicty);
	// keep updating until the change of log-likelihood is small (0.5)
	double loglikeliIterate = loglikeliCurBest;
	int iterationIndex = 0;
    //bool fEarlyTerm = false;
    //int nIteration = 0;
	while(true)
	{
//cout << "****************Interation " << iterationIndex << ", current log likelihood = " << loglikeliCurBest << endl;
		// releax each edge one by one
        double loglikeliIterateThis = loglikeliIterate;
		for(int b=0; b<speciesTreeBest.GetTotNodesNum()-1; ++b)
		//for(int b=speciesTreeBest.GetTotNodesNum()-2; b>=0; --b)
		{
			if( IsEdgeSkipped(b) == false )
			{
				// tweak this edge
				if( fBrentMode == false)
				{
					TweakEdgeLen(b);
				}
				else
				{
					OptEdgeLenSearchBrent(b, iterationIndex);
				}
                
                
                // early stop if we have already done one round
#if 0
                if( iterationIndex >=1 )
                {
                    //
                    if( loglikeliCurBest - loglikeliIterateThis < logHillClimbRatio )
                    {
                        fEarlyTerm = true;
//cout << "EARLY BREAK....: loglikeliCurBest: " << loglikeliCurBest << ", logLikiIteratThis: " << loglikeliIterateThis << endl;
                        break;
                    }
                }
#endif
                loglikeliIterateThis = loglikeliCurBest;
			}
            else
            {
//cout << "Edge: " << b << " is skipped.\n";
            }
		}
		iterationIndex++;
		const double toltot=0.1;
		YW_ASSERT_INFO( loglikeliCurBest+toltot*listGTreePtrs.size() >= loglikeliIterate, "Likelihood can not decrease");
		if( loglikeliCurBest - loglikeliIterate < logHillClimbRatio )
		{
			break;
		}
		// break off when the tree is rather hopeless
#if 0
		if( fBrentMode == true )
		{
			// how much it improves over the previous one
			// we actually bet that the future iterations will not lead to higher improvements
			// so we use this information in predicting whether we can get better results in future
			// if not, we should stop now
			double diffLikeliIteration = loglikeliCurBest - loglikeliIterate;
			if(  loglikeliCurBest+diffLikeliIteration <= knownLikeliOtherTree )
			{
				//loglikeliIterate = loglikeliCurBest;
				break;
			}
			// moreover, if the current likeli is clearly smaller (with some pre-defined margin)
			// than the current best known one, then we figure it may not be very productive to continue
			if( loglikeliCurBest*(1.0-FRACTION_ITER_INC) <=  knownLikeliOtherTree )
			{
//cout << "Stop iteration: knownLikeliOtherTree = " << knownLikeliOtherTree << ", loglikeliCurBest = " << loglikeliCurBest << endl ;
				//loglikeliIterate = loglikeliCurBest;
				break;
			}
		}
#endif
		// continue
		loglikeliIterate = loglikeliCurBest;
        
        //if( fEarlyTerm == true )
        //{
        //    break;
        //}
        
        // in approximate mode, just do one round
        //if( IsApproxLikelihood() == true )
        //{
        //    break;
        //}
        if( iterationIndex >= GetMaxOptRound() )
        {
            break;
        }
	}
	// return the current best loglikeli
	treeRes = speciesTreeBest;

#if 0
// make sure the solver has the most up-to-date ST
for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr )
{
MarginalTree mst;
listGSTProbFinder[tr]->GetSpeciesTree(mst);
cout << "For the " << tr << " prob solver: species tree = " << mst.GetNewick() << endl;
}
// now just re-compute the prob again
double loglikeliCheck = 0.0;
for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
{
loglikeliCheck += log(listGSTProbFinder[tr]->CalcProb() );
}
cout << "****************--------------------------------\n";
cout << "current log-likeli = " << loglikeliCheck << endl;
cout << "****************--------------------------------\n";
#endif
	return loglikeliCurBest;
    
#endif
}

// optimize branch length by BFGS
double STBranchLenFinder :: OptBranchLenByBFGS( MarginalTree &treeRes )
{
    //
    vector<int> listEdgesOpt;
    GetEdgesToOpt(listEdgesOpt);
    
    int numVars = listEdgesOpt.size();
    
    //
    lbfgsfloatval_t fx;
    lbfgsfloatval_t *m_x = lbfgs_malloc( numVars );
    
    if (m_x == NULL) {
        printf("ERROR: Failed to allocate a memory block for variables.\n");
        return 1;
    }
    
    /* Initialize the variables. */
    for (int i = 0;i < numVars; ++i) {
        m_x[i] = log(this->speciesTreeBest.GetEdgeLen( listEdgesOpt[i]  ) ) ;
    }
//cout << "BFGS initial value: ";
//for(int i=0; i<numVars; ++i)
//{
//cout << m_x[i] << "  ";
//}
//cout << endl;
    
    /*
     Start the L-BFGS optimization; this will invoke the callback functions
     evaluate() and progress() when necessar
     */
    const double DEF_BFGS_DELTA = 0.00001;
    lbfgs_parameter_t param;
    lbfgs_parameter_init(&param);
    param.past = 1;
    param.delta = DEF_BFGS_DELTA;
    //int ret =
    lbfgs(numVars, m_x, &fx, _evaluate, _progress, this, &param);
    
    /* Report the result. */
#if 0
printf("L-BFGS optimization terminated with status code = %d\n", ret);
cout << "BFGS optimal value: " << fx << endl;
cout << "BFGS optimized value at branches: ";
for(int i=0; i<numVars; ++i)
{
cout << exp(m_x[i]) << "  ";
}
cout << endl;
#endif
    //printf("  fx = %f, x[0] = %f, x[1] = %f\n", fx, m_x[0], m_x[1]);
    
    // set final tree length
    for(int i=0; i<numVars; ++i)
    {
        this->speciesTreeBest.SetBranchLen( listEdgesOpt[i], exp(m_x[i]) );
//cout << "In OptBranchLenByBFGS: setting branch length to " << exp(m_x[i]) << " for branch: " << listEdgesOpt[i] << endl;
    }
    treeRes = this->speciesTreeBest;
    
    lbfgs_free( m_x );
    
    //return loglikeliCurBest;
    return -1.0*fx;
}

#if 0
static double CalcPenaltyFuncCoalProb( const lbfgsfloatval_t *x, int n )
{
    const double COEFF_PENTALTY = 1000000.0;
    double valAdded = 0.0;
    for(int i=0; i<n; ++i)
    {
        if( x[i] < 0.0 )
        {
            valAdded += COEFF_PENTALTY * x[i] * x[i];
        }
    }
    return valAdded;
}
#endif

static double GetDeltaIncBFGS(double valCurr)
{
    //
    const double DEF_BFGS_STEP_SIZE = 0.0001;
    return log(exp(valCurr)+DEF_BFGS_STEP_SIZE) - valCurr;
}


lbfgsfloatval_t STBranchLenFinder :: evaluate(
                         const lbfgsfloatval_t *x,
                         lbfgsfloatval_t *g,
                         const int n,
                         const lbfgsfloatval_t step
                         )
{
//    static int numEvaluation = 0;
//cout << "[" << ++numEvaluation  << "]: evaluaing at: ";
//for(int i=0; i<n; ++i)
//{
//    cout << x[i] << "  ";
//}
//cout << endl;
    

    // make sure every branch length is positive    
    // evaluate the value and also gradient
    vector<int> listEdgesOpt;
    GetEdgesToOpt(listEdgesOpt);
    YW_ASSERT_INFO( (int)listEdgesOpt.size() == n, "Number of opt edges: mismatch");
//cout << "listEdges: ";
//DumpIntVec( listEdgesOpt );
    
    for( int i=0; i<n; ++i )
    {
        //
        UpdateSTBranchLen( listEdgesOpt[i], exp(x[i]) );
    }
    //
    this->setBranchesToSet.clear();
    double logprob = -1.0*CalcLogProb();
    //double logprobAdded = logprob + CalcPenaltyFuncCoalProb(x, n);
    YW_ASSERT_INFO( listEdgesOpt.size() > 0, "Cannot be empty" );
    //double logprob = EvaluateAt( listEdgesOpt[0], x[0] );
    
    // now calculte the graidient
    //double deltaInc = 0.001;
    // temparily changing each branch length
    for(int i=0; i<n; ++i)
    {
        //
        double deltaInc = GetDeltaIncBFGS( x[i] );
        double len2 = exp(x[i] + deltaInc);
        UpdateSTBranchLen( listEdgesOpt[i], len2 );
        //lbfgsfloatval_t *px = const_cast< lbfgsfloatval_t * >(x);
        double logprob2 = -1.0*CalcLogProb();
//cout << "x[i] =  " << x[i] << ", exp(x[i]): " << exp(x[i]) << ", deltaInc: " << deltaInc << ", len2: " << len2 << ", logprob2: " << logprob2 << endl;
        //px[i] = len2;
        //double valAdded = CalcPenaltyFuncCoalProb( px, n );
        //double logprob2Added = logprob2 + valAdded;
        //px[i] -= deltaInc;
        
        //double logprob2 = EvaluateAt( listEdgesOpt[i], len2  );
        UpdateSTBranchLen( listEdgesOpt[i], exp(x[i]) );
        //double gradientVal = ( logprob2Added-logprobAdded )/deltaInc;
        double gradientVal = ( logprob2-logprob )/deltaInc;
        g[i] = gradientVal;
    }
//cout << "prob: " << logprob << endl;
////cout << "Penalized prob: " << logprobAdded << endl;
//cout << " gradients: ";
//for(int i=0; i<n; ++i)
//{
//    cout << g[i] << "  ";
//}
//cout << endl;
    
    return logprob;
}

int STBranchLenFinder :: progress(
             const lbfgsfloatval_t *x,
             const lbfgsfloatval_t *g,
             const lbfgsfloatval_t fx,
             const lbfgsfloatval_t xnorm,
             const lbfgsfloatval_t gnorm,
             const lbfgsfloatval_t step,
             int n,
             int k,
             int ls
             )
{
#if 0
    //
    printf("Iteration %d:\n", k);
    printf("  fx = %f, x[0] = %f, x[1] = %f\n", fx, x[0], x[1]);
    printf("  xnorm = %f, gnorm = %f, step = %f\n", xnorm, gnorm, step);
    printf("\n");
#endif
    return 0;
}

void STBranchLenFinder :: GetEdgesToOpt( vector<int> &listEdgesOpt ) const
{
    //
    listEdgesOpt.clear();
    YW_ASSERT_INFO(listEdgeCheckFlags.size() > 0, "Not init yet");
    for(int i=0; i<(int)listEdgeCheckFlags.size(); ++i)
    {
        if( listEdgeCheckFlags[i] == false  && i != this->speciesTreeBest.GetRoot()  )
        {
            //
            listEdgesOpt.push_back(i);
        }
    }
}

//////////////////////////////////////////////////////////////////////////////////
// implementaiton methods

void STBranchLenFinder :: Init()
{
	// initialize the trees
    if( listGSTProbFinder.size() == 0 )
    {
        // need to init all gene tree prob comp components
        for(int tr=0; tr<(int)listGTreePtrs.size(); ++tr)
        {
#if 0
cout << "Gene tree: ";
string strNW;
listGTreePtrs[tr]->ConsNewick(strNW);
cout << "In STBranchLenFinder: Init() : gene tree: " << strNW << endl;
#endif
            GenericGeneSpeciesTreeProb *gstProb = CreateGeneTreeProbComp(speciesTreeBest, *listGTreePtrs[tr]);
            //GenericGeneSpeciesTreeProb *gstProb;
            //if( IsFixedCoalMode() == false )
            //{
            //    gstProb = new GeneSpeciesTreeProb(speciesTreeBest, *listGTreePtrs[tr]);
            //}
            //else
            //{
            //    gstProb = new FastGeneTreeProbFixedSpecies(speciesTreeBest, *listGTreePtrs[tr]);
            //}
            listGSTProbFinder.push_back(gstProb);
        }
    }
	loglikeliCurBest =  0.0;
	for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
	{
		double logvalProb = listGSTProbFinder[tr]->CalcLogProb();
//cout << "INIT: multiplicity size = " << listGTreeMultiplicty.size() << ", tree size = " << listGTreePtrs.size() << ", logvalProb: " << logvalProb  << endl;
		YW_ASSERT_INFO(listGTreeMultiplicty.size() == listGTreePtrs.size(), "Tree and multiplicity size mismatch" );
		loglikeliCurBest += logvalProb*listGTreeMultiplicty[tr];
	}
//cout << "STBranchLenFinder: initial log likelihood = " << loglikeliCurBest << endl;

	// setup edge checking flags
	for(int b=0; b<speciesTreeBest.GetTotNodesNum(); ++b)
	{
		// tweak this edge
		bool fEdge = CanSkipEdge(b);
		listEdgeCheckFlags.push_back( fEdge );
if(fEdge == true )
{
//cout << "***---***---: edge " << b << " is skipped\n";
}
	}

}

double STBranchLenFinder :: CalcLogProb()
{
    static int numProbCalc = 0;
    if( ++numProbCalc % 10 == 0 )
    {
        //cout << "++Performing number of prob calculation: " << numProbCalc << endl;
    }
    
    if( numThreads > 1 )
    {
        return CalcLogProbMultithread();
        //return TempIncEdgeLenMultithreadV2(branch, lenNew, listOrigCfgsSaved);
    }
    
    // for benchmarking
    ApproxGTPStats::Instance().RecordProbComputeStart();
    
    
    double loglikeli =  0.0;
	for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
	{
		double logvalProb = listGSTProbFinder[tr]->CalcLogProb();
        //cout << "INIT: multiplicity size = " << listGTreeMultiplicty.size() << ", tree size = " << listGTreePtrs.size() << ", logvalProb: " << logvalProb  << endl;
		YW_ASSERT_INFO(listGTreeMultiplicty.size() == listGTreePtrs.size(), "Tree and multiplicity size mismatch" );
		loglikeli += logvalProb*listGTreeMultiplicty[tr];
	}
    
    // for benchmarking
    ApproxGTPStats::Instance().RecordProbComputeEnd();
    
    
    return loglikeli;
}


void STBranchLenFinder :: TweakEdgeLen(int branch)
{
//cout << "TweakEdgeLen:\n";
	const int SCALE_FACTOR = 1000;
	map<int, double> mapLoglikeliBranchLen;

	// approach: each time, try two ways: plus or minus the grid length of branch 
	// (if they are within the range). Other ways are also possible
	double loglikeliStep = loglikeliCurBest;
	bool fDirDec = true;
	bool fDirInc = true;
	double szCurr = speciesTreeBest.GetEdgeLen(branch);
//cout << "*******TweakEdgeLen: for edge " << branch << ", current length = " << szCurr << endl;

	// first decide which direction to go
	double blenDec = szCurr - gridBranchLen;
	if( blenDec < minBranchLen )
	{
		fDirDec = false;
	}
	double blenInc = szCurr + gridBranchLen;
	if( blenInc > maxBranchLen )
	{
		fDirInc = false;
	}
	if( fDirDec == false && fDirInc == false)
	{
		// done
		return;
	}
	double loglikeliDec = loglikeliStep;
	double loglikeliInc = loglikeliStep ;
	vector< map<int,set< LineageConfig,LTLinCfg > > >  listOrigCfgsSavedDec, listOrigCfgsSavedInc, listOrigCfgsSaved;
	if( fDirDec == true)
	{
		loglikeliDec = TempIncEdgeLen( branch, blenDec, listOrigCfgsSavedDec );
		// save it
		mapLoglikeliBranchLen.insert( map<int,double> :: value_type( (int)(blenDec*SCALE_FACTOR), loglikeliDec ));
		if( listOrigCfgsSaved.size() == 0 )
		{
			listOrigCfgsSaved = listOrigCfgsSavedDec;
		}
	}
	if( fDirInc == true)
	{
		loglikeliInc = TempIncEdgeLen( branch, blenInc, listOrigCfgsSavedInc );
		mapLoglikeliBranchLen.insert( map<int,double> :: value_type( (int)(blenInc*SCALE_FACTOR), loglikeliInc ));
		if( listOrigCfgsSaved.size() == 0 )
		{
			listOrigCfgsSaved = listOrigCfgsSavedInc;
		}
	}

	//if( fDirDec == true && fDirInc == true )
	//{
	// we need to figure out the direction to move
	// by taking the one increasing the likeli the most
	if( loglikeliDec <= loglikeliInc )
	{
		fDirDec = false;
	}
	else
	{
		fDirInc = false;
	}
	// but can this lead to high likelihood (more than the current val)?
	if( fDirDec == true && loglikeliDec <= loglikeliCurBest )
	{
		fDirDec = false;
	}
	if( fDirInc == true && loglikeliInc <= loglikeliCurBest )
	{
		fDirInc = false;
	}
	//}
	YW_ASSERT_INFO( fDirDec == false || fDirInc == false, "Can not go both direction");
	if( fDirDec == false && fDirInc == false )
	{
		// no more to do
		// need to restore the two
		//RestoreSavedCfgs(listOrigCfgsSavedInc);
		//RestoreSavedCfgs(listOrigCfgsSavedDec);
		RestoreSavedCfgs(listOrigCfgsSaved);
		return;
	}
	// make sure it is consistent
	RestoreSavedCfgs(listOrigCfgsSaved);

#if 0
	if(fDirDec == true)
	{
		RestoreSavedCfgs(listOrigCfgsSavedInc);
		loglikeliStep = loglikeliDec;
		szCurr = blenDec;
cout << "Moving to decreasing direction...loglikeliStep = " << loglikeliStep << endl;
	}
	else
	{
		loglikeliStep = loglikeliInc;
		szCurr = blenInc;
cout << "Moving to increasing direction...loglikeliStep = " << loglikeliStep << endl;
	}
	YW_ASSERT_INFO( loglikeliStep <= 0.0, "loglikelihood can not be positive" );
#endif

#if 0
	while(true)
	{
		// now moving in one direction only
		double blenNew = szCurr - gridBranchLen;
		if( fDirInc == true )
		{
			blenNew = szCurr + gridBranchLen;
		}
cout << "Iterate through blenNew = " << blenNew << endl;
		// stop when out of range
		if(  blenNew > maxBranchLen || blenNew < minBranchLen )
		{
			break;
		}
		// test the new value
		vector< map<int,set< LineageConfig,LTLinCfg > > >  listOrigCfgsSavedNew;
		double loglikeliTemp	= TempIncEdgeLen( branch, blenNew, listOrigCfgsSavedNew );
		
cout << "new likelihood = " << loglikeliTemp << endl;
		if( loglikeliTemp - loglikeliStep <= logHillClimbRatio )
		{
			// stop, but restore first
			RestoreSavedCfgs(listOrigCfgsSavedNew);
			break;
		}
		else
		{
			loglikeliStep = loglikeliTemp;
			szCurr = blenNew;
//cout << "**Changing branch to " << szCurr << endl;
		}
	}
#endif


//#if 0
	// now search in one direction
	double srangeMin = szCurr;
	double srangeMax = maxBranchLen;
	if( fDirDec == true )
	{
		srangeMin = minBranchLen;
		srangeMax = szCurr;
	}
	while(true)
	{
		// idea: starting from szCurr, compute points whose distance to szCurr doubles each time
		// with the last point being the limit.
		// if there is a point with decreasing, re-iterate between those two points
		// if the last point has very small difference from the current point, stop there
		double szCurrLast = -1.0;
		double szCurrOneBefore = -1.0;
		double szCurrOneBefore2 = -1.0;
		double stepDiff = gridBranchLen;
		//bool fFinish = false;
		bool fLikeliInc = false;
		while(true)
		{
//cout << "srangeMin = " << srangeMin << ", srangeMax = " << srangeMax << ", stepDiff = " << stepDiff << endl;
			// 
			double blenNew = szCurr - stepDiff;
			if( fDirInc == true )
			{
				blenNew = szCurr + stepDiff;
			}
//cout << "Iterate through blenNew = " << blenNew << endl;
			// stop when out of range
			szCurrOneBefore2 = szCurrOneBefore;
			szCurrOneBefore = szCurrLast;
			szCurrLast = blenNew;
			if(  blenNew > srangeMax || blenNew < srangeMin )
			{
				//fFinish = true;
				break;
			}
			// calculating the prob here
			vector< map<int,set< LineageConfig,LTLinCfg > > >  listOrigCfgsSavedNew;
			double loglikeliTemp;
			int idBrlen = (int)(blenNew*SCALE_FACTOR);
			if( mapLoglikeliBranchLen.find( idBrlen ) == mapLoglikeliBranchLen.end()   )
			{
				loglikeliTemp = TempIncEdgeLen( branch, blenNew, listOrigCfgsSavedNew );
				mapLoglikeliBranchLen.insert( map<int,double> :: value_type(idBrlen, loglikeliTemp) );
			}
			else
			{
				loglikeliTemp = mapLoglikeliBranchLen[idBrlen];
			}

//cout << "loglikeliTemp = " << loglikeliTemp << ", loglikeliStep = " << loglikeliStep << endl;
			if( loglikeliTemp - loglikeliStep <= logHillClimbRatio )
			{
				// should stop, but should mark where we stop
				RestoreSavedCfgs(listOrigCfgsSavedNew);
				break;
			}
			else
			{
//cout << "new likelihood = " << loglikeliTemp << endl;
				loglikeliStep = loglikeliTemp;
				szCurr = blenNew;
				fLikeliInc = true;
//cout << "**Changing branch to " << szCurr << endl;
			}

			// now doubling the distance
			const double MAX_GRID_JUMP=1.0;
			if( stepDiff <= MAX_GRID_JUMP/2)
			{
				stepDiff *= 2.0;
			}

		}
		// now focus on smaller region now
		if( fLikeliInc == false )
		{
			// we are done
			break;
		}
		// setup region again
		srangeMin = szCurr;
		srangeMax = szCurrLast;
		if(szCurrOneBefore2 >= 0.0)
		{
			srangeMin = szCurrOneBefore2;
		}
		if( srangeMax > maxBranchLen)
		{
			srangeMax = maxBranchLen;
		}
		if( fDirDec == true )
		{
			srangeMin = szCurrLast;
			srangeMax = szCurr;
			if(szCurrOneBefore2 >= 0.0)
			{
				srangeMax = szCurrOneBefore2;
			}
			if( srangeMin < minBranchLen )
			{
				srangeMin = minBranchLen;
			}
		}
	}
//#endif

	// set the best current value
	loglikeliCurBest = loglikeliStep;
	//speciesTreeBest.SetBranchLen(branch, szCurr);
	UpdateSTBranchLen( branch, szCurr );
//cout << "*******final likelihood = " << loglikeliCurBest << ", which is achieved at new branch length " << szCurr << endl;
}

double STBranchLenFinder :: TempIncEdgeLen(int branch, double lenNew, vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved )
{
    if( numThreads > 1 )
    {
        return TempIncEdgeLenMultithread(branch, lenNew, listOrigCfgsSaved);
        //return TempIncEdgeLenMultithreadV2(branch, lenNew, listOrigCfgsSaved);
    }
    
    static int numProbInc = 0;
    if( ++numProbInc % 10 == 0 )
    {
        //cout << "++Performing number of prob calculation (inc): " << numProbInc << endl;
    }
    
//cout << "TempIncEdgeLen: branch " << branch << ", lenNew " << lenNew << ", orig log-likeli = " << loglikeliCurBest << ", tree: ";
//cout << this->speciesTreeBest.GetNewick() << endl;
	// 
	listOrigCfgsSaved.clear();
	double loglikeliStep = 0.0;
    
    bool fSetOldBr = true;
    
	for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
	{
		map<int,set< LineageConfig,LTLinCfg > >  mapSavedCfgs;
        int threadId = 0;
		double loglikelival = listGSTProbFinder[tr]->TestNewBranchLenAt(threadId, branch, lenNew, mapSavedCfgs, fSetOldBr);
//cout << "tr = " << tr << ", listGTreeMultiplicty[tr] = " << listGTreeMultiplicty[tr] << ", loglikelival: " << loglikelival << endl;
		loglikeliStep += loglikelival*listGTreeMultiplicty[tr];
		listOrigCfgsSaved.push_back( mapSavedCfgs );
	}
//cout << "After tweaking: " << loglikeliStep << endl;
	return loglikeliStep;
}

void STBranchLenFinder :: RestoreSavedCfgs( vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved)
{
	// allow empty re-set
	if( listOrigCfgsSaved.size() == 0)
	{
		return;
	}
	YW_ASSERT_INFO( listOrigCfgsSaved.size() == listGSTProbFinder.size(), "Wrong size" );
	// 
	for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
	{
		listGSTProbFinder[tr]->SetLinCfgs( listOrigCfgsSaved[tr] );
	}
}

void STBranchLenFinder :: JumpStartBy( STBranchLenFinder *pSTBrFinderPrev )
{
    // when a previous branch length searcher is given, use it as the blueprint
    if ( pSTBrFinderPrev == NULL )
    {
        return;
    }
    // find the differences in ST tree: should only differ by one branch
    set<int> setBrDiffThis, setBrDiffPrev;
    this->speciesTreeBest.FindDiffSubtreesFrom(pSTBrFinderPrev->speciesTreeBest, setBrDiffThis, setBrDiffPrev);
    YW_ASSERT_INFO( setBrDiffThis.size() == 1, "Must diff by exactly one branch" );
    // find the path from this to root
    int brSTDiff = *( setBrDiffThis.begin() );
    set<int> setPathToRoot;
    this->speciesTreeBest.GetPath( brSTDiff, this->speciesTreeBest.GetRoot(), setPathToRoot );
    setPathToRoot.insert( this->speciesTreeBest.GetRoot() );
    
    // create a mapping between the two trees
    map<int,int> mapSTNewToRef;
    FindMatchedSubtrees( this->speciesTreeBest, pSTBrFinderPrev->speciesTreeBest, mapSTNewToRef );
    
    //
    YW_ASSERT_INFO( this->listGSTProbFinder.size() == pSTBrFinderPrev->listGSTProbFinder.size(), "Number of probability computation: mismatch" );
    for(int tr=0; tr<(int)this->listGSTProbFinder.size(); ++tr)
    {
        this->listGSTProbFinder[tr]->JumpStartAtSTNodes( pSTBrFinderPrev->listGSTProbFinder[tr], setPathToRoot, mapSTNewToRef );
    }
}

void STBranchLenFinder :: UpdateSTBranchLen(int br, double lenNew)
{
//cout << "****** UpdateSTBranchLen: br:" << br << " to lenNew: " << lenNew << endl;
	// 
	speciesTreeBest.SetBranchLen(br, lenNew);
	// should update all the current species tree in the solver themselves
	for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
	{
		listGSTProbFinder[tr]->SetSTBranchLen(br, lenNew);
	}

#if 0
cout << "Current ST tree: ";
speciesTreeBest.Dump();
cout << "Newick: " << speciesTreeBest.GetNewick() << endl;
#endif
}

bool STBranchLenFinder :: CanSkipEdge(int br)
{
	// can we skip this branch br? Rule: we can skip an edge out of leaf of the species tree
	// as long as this leaf has only one allele collected
    //YW_ASSERT_INFO( mapEdgeSkipFlag.find(br) != mapEdgeSkipFlag.end(), "fail to find" );
    //return mapEdgeSkipFlag[br];
    
	if( speciesTreeBest.IsLeaf(br) == true )
	{
		// how many alleles does this taxa has? YW: need to check each tree
		YW_ASSERT_INFO(listGSTProbFinder.size()>=1, "Can not be empty list");
        for(int tr=0; tr<(int)listGSTProbFinder.size(); ++tr)
        {
            int taxa = listGSTProbFinder[tr]->GetTaxaAtLeafST(br);
            if( taxa >= 0  )
            {
                set<int> allelesTaxa;
                listGSTProbFinder[tr]->GetGeneAllelesForSpecies(taxa, allelesTaxa);
                if( allelesTaxa.size() == 0 )
                {
                    cout << "Tree " << tr << ": taxa: " << taxa << endl;
                }
                
                YW_ASSERT_INFO( allelesTaxa.size() >=1, "Can not be empty3" );
                if( allelesTaxa.size() > 1 )
                {
                    return false;
                }
            }
        }
        return true;
	}
	return false;
}


double STBranchLenFinder :: Func1DMinBrent(int br, double ax, double bx, double cx, double tol, double *xmin )
{
//cout << "Func1DMinBrent: evaluate branch " << br << ", [" << ax << ", " << bx << ", " << cx << "], \n";
	// YW: this function is based Numerical Receipe in C book.
	// search for best 1 D function (in this case, the likelihood) using Brent's method
	//Given a function f, and given a bracketing triplet of abscissas ax, bx, cx (such that bx is
	//between ax and cx, and f(bx) is less than both f(ax) and f(cx)), this routine isolates
	//the minimum to a fractional precision of about tol using Brent�s method. The abscissa of
	//the minimum is returned as xmin, and the minimum function value is returned as brent, the
	//returned function value.
	#define ITMAX 100
	#define CGOLD 0.3819660
	#define ZEPS 1.0e-10
	//Here ITMAX is the maximum allowed number of iterations; CGOLD is the golden ratio; ZEPS is
	//a small number that protects against trying to achieve fractional accuracy for a minimum that
	//happens to be exactly zero.
	#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);
	#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
	

	int iter;
	double a,b,d,etemp,fu,fv,fw,fx,p,q,r,tol1,tol2,u,v,w,x,xm;
	double e=0.0;   // This will be the distance moved on the step before last.
    d=0.0;
	a=(ax < cx ? ax : cx);  //a and b must be in ascending order,
	b=(ax > cx ? ax : cx); // but input abscissas need not be.
	x=w=v=bx;				//Initializations...
	fw=fv=fx= EvaluateAt(br, x);
	for (iter=1;iter<=ITMAX;iter++) 
	{ //Main program loop.
//cout << "iteration " << iter << endl;
		xm=0.5*(a+b);
		tol2=2.0*(tol1=tol*fabs(x)+ZEPS);
		if (fabs(x-xm) <= (tol2-0.5*(b-a))) 
		{ //Test for done here.
			*xmin=x;
			return fx;
		}
		if (fabs(e) > tol1) 
		{ // Construct a trial parabolic fit.
			r=(x-w)*(fx-fv);
			q=(x-v)*(fx-fw);
			p=(x-v)*q-(x-w)*r;
			q=2.0*(q-r);
			if (q > 0.0) p = -p;
			q=fabs(q);
			etemp=e;
			e=d;
			if (fabs(p) >= fabs(0.5*q*etemp) || p <= q*(a-x) || p >= q*(b-x))
				d=CGOLD*(e=(x >= xm ? a-x : b-x));
			//The above conditions determine the acceptability of the parabolic fit. Here we
			//take the golden section step into the larger of the two segments.
			else 
			{
				d=p/q; //Take the parabolic step.
				u=x+d;
				if (u-a < tol2 || b-u < tol2)
					d=SIGN(tol1,xm-x);
			}
		} 
		else 
		{
			d=CGOLD*(e=(x >= xm ? a-x : b-x));
		}
		u=(fabs(d) >= tol1 ? x+d : x+SIGN(tol1,d));
		fu=EvaluateAt(br,u);
		//This is the one function evaluation per iteration.
		if (fu <= fx) { //Now decide what to do with our func
			if(u >= x) a=x; else b=x; //tion evaluation.
			SHFT(v,w,x,u)                       //Housekeeping follows:
			SHFT(fv,fw,fx,fu)
		} 
		else 
		{
			if (u < x) a=u; else b=u;
			if (fu <= fw || w == x) 
			{
				v=w;
				w=u;
				fv=fw;
				fw=fu;
			} 
			else if (fu <= fv || v == x || v == w) 
			{
				v=u;
				fv=fu;
			}
		} //Done with housekeeping. Back for
//cout << "** -fx = " << -1.0*fx << endl;
	} //another iteration.
	YW_ASSERT_INFO(false, "Too many iterations in brent");
	*xmin=x; //Never get here.
	return fx;
}

double STBranchLenFinder :: EvaluateAt(int br, double lenTest)
{
//cout << "EvaluateAt branch " << br << ", lenTest = " << lenTest <<endl;
	// first save copy of configs
	//vector< map<int,set< LineageConfig,LTLinCfg > > >  listOrigCfgsSaved;
	double res = TempIncEdgeLen( br, lenTest, listOrigCfgsSavedBrentSearch );
    
	// make sure it is consistent. DO WE REALLY NNED RESTORE?
	//RestoreSavedCfgs(listOrigCfgsSaved);
	// here we want to minimize it since Brent's method implements min finding 
	return -1.0*res;
}

void STBranchLenFinder :: OptEdgeLenSearchBrent(int branch, int round)
{
//cout << "OptEdgeLenSearchBrent: branch: " << branch << ", round: " << round << endl;
	// run Brent's method to search for best opt
	// we start from a range which is determined by round: the more rounds 
	// we run, the narrower we get
	double regMid = speciesTreeBest.GetEdgeLen(branch);
    double lenOrigSave = regMid;
	double regLeft = minBranchLen;
	double regRight = maxBranchLen;
	//YW_ASSERT_INFO( regMid >= regLeft && regMid <= regRight, "Branch length error" );
    if( (regMid >= regLeft && regMid <= regRight) == false )
    {
        // YW: 10/09/13, change this to allow program to continue
        // TBD!!!!!
        //cout <<"Warning: branch length search early termination.\n";
        //return;
        // if current branch length is out of range, re-init midpoint
        loglikeliCurBest = -1.0*HAP_MAX_INT;    // make current likelihood invalid
        regMid = 0.5*(regLeft + regRight);
    }
	if( round > 0)
	{
		// narrow down
		int fac = 0x1 << round;
		regLeft = regMid - (regMid - regLeft)/fac;
		regRight = regMid + (regRight-regMid)/fac;
	}
	double tolnum = 0.2;		// tolerance of MLE finding
	double brNew;
	double likeliMax = -1.0*Func1DMinBrent(branch, regLeft, regMid, regRight, tolnum, &brNew );
//cout << "--- Branch: " << branch << ", cur len: " << regMid << ", curBestProb " << loglikeliCurBest <<  ", loglikMax = " << likeliMax << endl;;
	//YW_ASSERT_INFO( likeliMax+tolnum >= loglikeliCurBest, "Wrong: Brent's result does not make sense" );
	if( likeliMax > loglikeliCurBest )
	{
		//
		loglikeliCurBest = likeliMax;
		//speciesTreeBest.SetBranchLen(branch, szCurr);
		UpdateSTBranchLen( branch, brNew );
	}
	else
	{
		// restore to original settings, do not change branch length since no increase is found
		RestoreSavedCfgs(listOrigCfgsSavedBrentSearch);
        
        // restore the old br length
        UpdateSTBranchLen( branch, lenOrigSave );
	}
}

typedef struct
{
    int threadId;
    vector<GenericGeneSpeciesTreeProb *> listGSTProbFinderUse;      // list of TreeProb ptrs
    vector<int> listGTreeMultiplicty;
    int trStart;
    int trEnd;                              // range of trees for this particular tree to work with
    //GenericGeneSpeciesTreeProb *GGSTPtr;    // which tree prob to compaute
    int branch;                             // which branch to tweak
    double lenNew;                          // what new branch
    //map<int,set< LineageConfig,LTLinCfg > >  mapSavedCfgs;  // save cfgs to later use
    vector< map<int,set< LineageConfig,LTLinCfg > > > listMapSavedCfgs; // list of cfgs to use
    double loglikelival;                       // computed loglikelihood of all the trees we use
    //int tmpres;
} STBFThreadInfo;

#if 0
// test function
static int CalcStuff( int trStart, int trEnd )
{
    //
    int res = 0;
    const int numReps = 100000;
    for(int j=0; j<numReps; ++j)
    {
    for(int i=trStart; i<=trEnd; ++i)
    {
        res += i;
    }
    }
    return res;
}
#endif

static void *ThreadFuncProbCalculator(void *ptr)
{
    //
    STBFThreadInfo *ptinfo = (STBFThreadInfo *)ptr;
//#if 0
    ptinfo->loglikelival = 0.0;
//cout << "Starting a thread for processing branch: " << ptinfo->branch << ", lenNew: " << ptinfo->lenNew << endl;
//cout << "Start tree: " << ptinfo->trStart << ", end tree: " << ptinfo->trEnd << endl;
    // calculate prob for the range of trees we need to process
    for( int tr = ptinfo->trStart; tr <=ptinfo->trEnd; ++tr )
    {
        map<int,set< LineageConfig,LTLinCfg > > mapSavedCfgs;
        int threadId = ptinfo->threadId;
        double loglikelivalstep = ptinfo->listGSTProbFinderUse[tr]->TestNewBranchLenAt( threadId, ptinfo->branch, ptinfo->lenNew, mapSavedCfgs, false);
        ptinfo->listMapSavedCfgs.push_back(mapSavedCfgs);
        ptinfo->loglikelival += loglikelivalstep*ptinfo->listGTreeMultiplicty[tr];
    }
//#endif
//ptinfo->tmpres = CalcStuff( ptinfo->trStart, ptinfo->trEnd );
    
//cout << "Thread: [" << ptinfo->trStart << ", " << ptinfo->trEnd << "] is done\n";
    return NULL;
}

// Calculate prob of all trees w/ multithreaded after branch length change
double STBranchLenFinder :: TempIncEdgeLenMultithread(int branch, double lenNew, vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved)
{
    // start bunch processing by launching multiple threads
	listOrigCfgsSaved.clear();
	double loglikeliStep = 0.0;
    
    // save the old branch length
    double brOld = speciesTreeBest.GetEdgeLen( branch );
    // set the new branch length
    for( int tr=0; tr<(int)listGSTProbFinder.size(); ++tr )
    {
        listGSTProbFinder[tr]->SetSTBranchLen( branch, lenNew );
    }
    
    // create all the thread for processing the trees by spliting the tasks evenly
    // init threads
    int numThreadsUse = numThreads;
    // if not that many trees, reduce it
    if( numThreadsUse > (int) listGSTProbFinder.size() )
    {
        //
        numThreadsUse = (int)listGSTProbFinder.size();
    }
    
    pthread_t* pid = new pthread_t[numThreadsUse];
    STBFThreadInfo *pThreadInfo = new STBFThreadInfo[numThreadsUse];
    
    // start the threads
    int numTreesPerThread = (int)listGSTProbFinder.size()/numThreadsUse;
    YW_ASSERT_INFO(numTreesPerThread>=1, "Must have at least one tree to process");
    int numLeftOver = (int)listGSTProbFinder.size() - numThreadsUse * numTreesPerThread ;
    YW_ASSERT_INFO( numLeftOver >= 0, "Must be non-negative");
    int trCurToProc = 0;
    for(int i=0;i<numThreadsUse;++i)
    {
//cout << "Starting thread " << i << endl;
        // wait for all threads finishing
        pThreadInfo[i].threadId = i;
        pThreadInfo[i].trStart = trCurToProc;
        pThreadInfo[i].trEnd = trCurToProc + numTreesPerThread-1;
        trCurToProc += numTreesPerThread;
        // if there is leftover to do, add one more
        if( numLeftOver > 0 )
        {
            // add one more
            ++pThreadInfo[i].trEnd;
            ++trCurToProc;
            --numLeftOver;
        }
        pThreadInfo[i].listGSTProbFinderUse = listGSTProbFinder;
        pThreadInfo[i].listGTreeMultiplicty = listGTreeMultiplicty;
        pThreadInfo[i].branch = branch;
        pThreadInfo[i].lenNew = lenNew;
        
        // start thread
        int ret = pthread_create(&pid[i], NULL, &ThreadFuncProbCalculator, (void *)&pThreadInfo[i]);
        if(ret)
        {
            cout << "Fatal error in creating pthread!" << endl;
            exit(1 );
        }

    }
    
    
    // free up resource
    for(int i=0;i<numThreadsUse;++i)
    {
        //wait for all threads finishing
        pthread_join(pid[i], NULL);
    }
    delete [] pid;
//cout << "All threas are done.\n";
#if 0
// collect results
for( int i = 0; i<numThreadsUse; ++i )
{
    cout << "tmpres: " << pThreadInfo[i].tmpres << endl;
}
exit(1);
#endif
    
    // collect results
    for( int i = 0; i<numThreadsUse; ++i )
    {
        loglikeliStep += pThreadInfo[i].loglikelival;
        for( int jj=0; jj<(int)pThreadInfo[i].listMapSavedCfgs.size(); ++jj)
        {
            listOrigCfgsSaved.push_back( pThreadInfo[i].listMapSavedCfgs[jj] );
        }
    }
    delete [] pThreadInfo;

    // set the old branch length back
    for( int tr=0; tr<(int)listGSTProbFinder.size(); ++tr )
    {
        listGSTProbFinder[tr]->SetSTBranchLen( branch, brOld );
    }
    

    //cout << "After tweaking: " << loglikeliStep << endl;
	return loglikeliStep;
}

// Calculate prob of all trees w/ multithreaded after branch length change
// YW: different from above, this version has one thread working on one particular tree and taking the next when done
static int nextTreeToCalc = 0;
static pthread_mutex_t mutexTreeSel;
static bool mutexTreeSelInit = false;

static int GetNextTreeToCalc()
{
    int res;
    pthread_mutex_lock(&mutexTreeSel);
    res = nextTreeToCalc;
    ++nextTreeToCalc;
    pthread_mutex_unlock(&mutexTreeSel);
    return res;
}

static void *ThreadFuncProbCalculatorV2(void *ptr)
{
    //
    STBFThreadInfo *ptinfo = (STBFThreadInfo *)ptr;
    //#if 0
    ptinfo->loglikelival = 0.0;
    //cout << "Starting a thread for processing branch: " << ptinfo->branch << ", lenNew: " << ptinfo->lenNew << endl;
    //cout << "Start tree: " << ptinfo->trStart << ", end tree: " << ptinfo->trEnd << endl;
    // calculate prob for the range of trees we need to process
    while(true)
    {
        int trNextToCalc = GetNextTreeToCalc();
        
        // stop if it is out of range
        if( trNextToCalc >= ptinfo->trEnd )
        {
            break;
        }
        
        map<int,set< LineageConfig,LTLinCfg > > mapSavedCfgs;
        
        // set thread id
        ptinfo->listGSTProbFinderUse[trNextToCalc]->SetThreadId( ptinfo->threadId );
        
        double loglikelivalstep = ptinfo->listGSTProbFinderUse[trNextToCalc]->CalcLogProb( );
        ptinfo->loglikelival += loglikelivalstep*ptinfo->listGTreeMultiplicty[trNextToCalc];
    }
    //#endif
    //ptinfo->tmpres = CalcStuff( ptinfo->trStart, ptinfo->trEnd );
    
    //cout << "Thread: [" << ptinfo->trStart << ", " << ptinfo->trEnd << "] is done\n";
    return NULL;
}


double STBranchLenFinder :: CalcLogProbMultithread()
{
    // start bunch processing by launching multiple threads
	double loglikeliStep = 0.0;
    
    // reset the tree counter
    nextTreeToCalc = 0;
    if( mutexTreeSelInit == false)
    {
        pthread_mutex_init(&mutexTreeSel, NULL);
        mutexTreeSelInit = true;
    }
    
    // create all the thread for processing the trees by spliting the tasks evenly
    // init threads
    int numThreadsUse = numThreads;
    // if not that many trees, reduce it
    if( numThreadsUse > (int) listGSTProbFinder.size() )
    {
        //
        numThreadsUse = (int)listGSTProbFinder.size();
    }
    
    pthread_t* pid = new pthread_t[numThreadsUse];
    STBFThreadInfo *pThreadInfo = new STBFThreadInfo[numThreadsUse];
    
    // start the threads
    for(int i=0;i<numThreadsUse;++i)
    {
        //cout << "Starting thread " << i << endl;
        // wait for all threads finishing
        pThreadInfo[i].threadId = i;
        pThreadInfo[i].trStart = 0;
        pThreadInfo[i].trEnd = (int)listGSTProbFinder.size();
        pThreadInfo[i].listGSTProbFinderUse = listGSTProbFinder;
        pThreadInfo[i].listGTreeMultiplicty = listGTreeMultiplicty;
        
        // start thread
        int ret = pthread_create(&pid[i], NULL, &ThreadFuncProbCalculatorV2, (void *)&pThreadInfo[i]);
        if(ret)
        {
            cout << "Fatal error in creating pthread!" << endl;
            exit(1 );
        }
    }
    
    // free up resource
    for(int i=0;i<numThreadsUse;++i)
    {
        //wait for all threads finishing
        pthread_join(pid[i], NULL);
    }
    delete [] pid;
    //cout << "All threas are done.\n";
#if 0
    // collect results
    for( int i = 0; i<numThreadsUse; ++i )
    {
        cout << "tmpres: " << pThreadInfo[i].tmpres << endl;
    }
    exit(1);
#endif
    
    // collect results
    for( int i = 0; i<numThreadsUse; ++i )
    {
        loglikeliStep += pThreadInfo[i].loglikelival;
    }
    delete [] pThreadInfo;
    
    
    //cout << "After tweaking: " << loglikeliStep << endl;
	return loglikeliStep;
}

bool STBranchLenFinder :: IsEdgeSkipped(int br)
{
    YW_ASSERT_INFO( br<(int)listEdgeCheckFlags.size(), "Out of bound" );
    if( listEdgeCheckFlags[br] == true )
    {
        return true;
    }
    
    // if the set of edges to explore is not empty, then skip is not in the set
    if( this->setBranchesToSet.size() > 0 && this->setBranchesToSet.find( br ) == this->setBranchesToSet.end()  )
    {
        return true;
    }
    return false;
}


