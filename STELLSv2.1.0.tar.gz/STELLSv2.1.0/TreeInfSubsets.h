//
//  TreeInfSubsets.h
//  
//
//  Created by Yufeng Wu on 9/13/15.
//
//

#ifndef ____TreeInfSubsets__
#define ____TreeInfSubsets__

#include "MarginalTree.h"
#include "PhylogenyTreeBasic.h"

//////////////////////////////////////////////////////////////////////////////////
// Infer species tree from pairwise distance of species

class SpeciesTreeBuilderPairwiseDists
{
public:
	SpeciesTreeBuilderPairwiseDists( int numSpeciesIn, vector<PhylogenyTreeBasic *> &listGeneTreePtrsIn, const vector<int> &listMPIn, TaxaMapper &mapperTaxaIdsIn );

    void Infer();
    void SetOutputHere(bool f) { fOutputHere = f; }
    string GetBestInfSpeicesTreeConv() const { return strTreeResConvBack; }
    
    // change the max-degree
    static void SetMaxGTDegree(int szMax);
    
private:
    // discard trees with too large degree in order to speedup the computation
    void FilterGeneTreeByMaxDegree( vector<PhylogenyTreeBasic *> &listTreeSubsAll, vector<PhylogenyTreeBasic *> &listTreeSubsUse, const vector<int> &listMP, vector<int> & listMPUse );
    
    int numSpecies;
    vector<PhylogenyTreeBasic *> &listGeneTreePtrs;
    const vector<int> &listMP;
    TaxaMapper &mapperTaxaIds;
    
    // tree inference param
    double minBranchLenHillClimb;
    double maxBranchLenHillClimb;
    double fExploreNgbrTrees;
    bool fBrentMode;
    int numNearOptTreesKept;
    bool fOutputHere;
    
    // cache for inference result
    string strTreeResConvBack;
    
    // limit the maximum degree (thus number of subsets)
    static int maxDegreeGT;
};

//////////////////////////////////////////////////////////////////////////////////
// Infer species tree heuristically from gene tree splits
// this code allows subsets of taxa to appear in each gene tree

class SpeciesTreeBuilderHeuGTSplits
{
public:
    SpeciesTreeBuilderHeuGTSplits( int numSpeciesIn, vector<PhylogenyTreeBasic *> &listGeneTreePtrsIn, const vector<int> &listMPIn, TaxaMapper &mapperTaxaIdsIn );
    
    void Infer(bool fBinTreeOnly);
    string GetNWTreeInf() const { return treeInfNWRes; }
    string GetNWTreeInfChangedTaxon() const { return treeInfNWResChangedTaxon; }
    
private:
    int numSpecies;
    vector<PhylogenyTreeBasic *> &listGeneTreePtrs;
    const vector<int> &listMP;
    TaxaMapper &mapperTaxaIds;
    string treeInfNWRes;
    string treeInfNWResChangedTaxon;
};


#endif /* defined(____TreeInfSubsets__) */
