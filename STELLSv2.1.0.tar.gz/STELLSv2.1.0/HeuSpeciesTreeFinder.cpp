#include <stack>
#include <cmath>
#include "HeuSpeciesTreeFinder.h"

//////////////////////////////////////////////////////////////////////////////////
// Fast but less accurate finding of species tree 

const double DEFAULT_GRID_WIDTH = 0.5;


HeuSpeciesTreeFinder :: HeuSpeciesTreeFinder( const vector<PhylogenyTreeBasic *> &listGT, int ng, double gw, int ns ) 
 : //listGTreePtrs( listGT), 
 listGTConvertPtrs(listGT),
 numGrids(ng), gridWidth(gw), numSpecies(ns)
{
	 //gridWidth = DEFAULT_GRID_WIDTH;


#if 0
	// store a private copy of trees
	bool fNoZeroChange = true;
	// find whether we need to re-adjust zero
	string strNewickLen;
	YW_ASSERT_INFO( listGT.size() > 0, "Empty tree list" );
	listGT[0]->ConsNewick(strNewickLen, true, gridWidth);
cout << "strnewickLen = " << strNewickLen << endl;
	// 
	MarginalTree treeDummy;
	fNoZeroChange = ReadinMarginalTreesNewickWLenString(strNewickLen, numSpecies, treeDummy);

	for(int i=0; i<(int)listGT.size();++i)
	{
		// 
		PhylogenyTreeBasic *ptree = new PhylogenyTreeBasic;
		string strNewickLen;
		listGT[i]->ConsNewick(strNewickLen);	
		ptree->ConsOnNewickDupLabels(strNewickLen );	
		// adjust leaf label if needed
		if( fNoZeroChange == false)
		{
cout << "************************CHANGING NODE ID*****************************\n";
//cout << "Before start: tree is: \n";
//ptree->Dump();
			// iterate the node and reduce by one
			ptree->InitPostorderWalk();
			while(true)
			{
				TreeNode *pnode = ptree->NextPostorderWalk();
				if( pnode == NULL)
				{
					break;
				}
				string lbl = pnode->GetLabel();
				int idcurr;
				sscanf(lbl.c_str(), "%d", &idcurr);
				char buff[100];
				sprintf(buff, "%d", idcurr-1);
				string lblNew = buff;
				pnode->SetLabel( lblNew );
				//if( pnode->IsLeaf() == true)
				//{
				//int idnew = pnode->GetID()-1;
				//YW_ASSERT_INFO( idnew >=0, "id wrong" );
				//pnode->SetID( idnew );
				//}
			}
		}
		listGTConvertPtrs.push_back( ptree );
	}
#endif
}

HeuSpeciesTreeFinder :: ~HeuSpeciesTreeFinder()
{
#if 0
	for(int i=0; i<(int)listGTConvertPtrs.size(); ++i)
	{
		delete listGTConvertPtrs[i];
	}
	listGTConvertPtrs.clear();
#endif
}

// idea: find a species tree that minimize the number of inconsistent taxa???
// A taxa is said to be inconsistent if this taxa appears in a subtree of species tree
// but this taxa does coalescence within it (although it is not in the subtree)
// return the prob incurred by the heuristic tree
double HeuSpeciesTreeFinder :: InferByMinInconsistency( MarginalTree &treeRes )
{
	// simple approach: just try the gene tree (with default length) to get the best tree
	double resMax = 0.0;
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		//
		MarginalTree treeWLen;
		ConvToTreeWithLength(listGTConvertPtrs[tr], treeWLen);

		// 
		double resStep = 1.0;
		for( int tt2 = 0; tt2<(int)listGTConvertPtrs.size(); ++tt2 )
		{
			// reconstruct a phylo tree (not quite necessarily, but just in case...)
			string strNewickGT;
			listGTConvertPtrs[tt2]->ConsNewick(strNewickGT);
			PhylogenyTreeBasic phtree;
			phtree.ConsOnNewickDupLabels(strNewickGT );

			GeneSpeciesTreeProb gstComp( treeWLen, phtree );


			resStep *= gstComp.CalcProb();
		}
		if( resStep > resMax )
		{
			resMax = resStep;
		}
	}
	return resMax;
}



void HeuSpeciesTreeFinder :: ConvToTreeWithLength( PhylogenyTreeBasic *ptrTreeNoLength, MarginalTree &treeWLen )
{
	YW_ASSERT_INFO( ptrTreeNoLength != NULL, "tree can not be NULL" );
	string strNewickLen;
	ptrTreeNoLength->ConsNewick(strNewickLen, true, gridWidth);
//cout << "strnewickLen = " << strNewickLen << endl;
	// 
	bool fNoChangeToZero = ReadinMarginalTreesNewickWLenString(strNewickLen, numSpecies, treeWLen, true);
	if( fNoChangeToZero == false)
	{
//#if 0
		// add back the index
		for(int i=0; i<treeWLen.GetTotNodesNum();++i)
		{
			treeWLen.SetLabel(i, treeWLen.GetLabel(i)+1);
		}
//#endif
	}
//cout << "Constructed tree with length: ";
//treeWLen.Dump();
}


//////////////////////////////////////////////////////////////////////////////////

STSampleLineage :: STSampleLineage() 
{
}

STSampleLineage :: STSampleLineage(int numTrees, const set<int> sps)
{
	Init(numTrees, sps);
}


void STSampleLineage :: Init(int numTrees,  const set<int> &sps )
{
	species = sps;
	probAtLinNums.resize(numTrees);
	//wtTot = -1.0;
	wtTot.clear();
}

void STSampleLineage :: InitProbTbl(int tr, int minNL, int maxNL)
{
	YW_ASSERT_INFO(tr <(int)probAtLinNums.size(), "Tree num out of range");
	probAtLinNums[tr].resize(maxNL+1);
	for( int i=0; i<=maxNL; ++i )
	{
		probAtLinNums[tr][i]=0.0;
	}
}

void STSampleLineage :: SetProbAt(int tr, int k, double prob)
{
	YW_ASSERT_INFO( tr<(int)probAtLinNums.size() && k<(int)probAtLinNums[tr].size(), "Out of range2" );
	probAtLinNums[tr][k] = prob;
}

double STSampleLineage :: GetProbAt(int tr, int k) const
{
	if(  tr>=(int)probAtLinNums.size() || k>=(int)probAtLinNums[tr].size() )
	{
		return 0.0;
	}

	//if(  tr>=(int)probAtLinNums.size() || k>=(int)probAtLinNums[tr].size() )
	//{
	//	cout << "tr = " << tr << ", k = " << k << endl;
	//	const_cast<STSampleLineage *>(this)->Dump();
	//}
	YW_ASSERT_INFO( tr<(int)probAtLinNums.size() && k<(int)probAtLinNums[tr].size(), "Out of range3" );
	return probAtLinNums[tr][k];
}

void STSampleLineage :: GetSpecies(set<int> &sps) const
{
	sps = this->species;
}

void STSampleLineage :: CalcTotWt()
{
	if( wtTot.size() > 0 )
	{
		// do not re=work
		return;
	}

	//if( wtTot >= 0.0)
	//{
	//	return wtTot;
	//}
	wtTot.clear();
	wtTot.resize( probAtLinNums.size() );

	//double res = 1.0;
	for(int tr=0; tr<(int)probAtLinNums.size(); ++tr)
	{
		double tmp =0.0;
		for(int sz=0; sz<(int)probAtLinNums[tr].size(); ++sz)
		{
			tmp += GetProbAt(tr, sz);
		}
		wtTot[tr] = tmp;
		//res *= tmp;
	}
	//wtTot = res;
	//return res;
}

double STSampleLineage :: GetWtForTree(int tr)
{
	YW_ASSERT_INFO( tr <(int)wtTot.size(), "Out of bound0" );
	return wtTot[tr];
}


double STSampleLineage :: GetWtTotal()
{
	double res = 1.0;
	for(int tr=0; tr<(int)wtTot.size(); ++tr)
	{
		res *= GetWtForTree(tr);
	}
	return res;
}


void STSampleLineage :: Dump() 
{
	cout << "**  " << " for species: ";
	DumpIntSet( species );
	for(int tr=0; tr<(int)probAtLinNums.size(); ++tr)
	{
		for(int sz=0; sz<(int)probAtLinNums[tr].size(); ++sz)
		{
			cout <<  GetProbAt(tr, sz) << "    ";
		}
		cout << endl;;
	}
}



//////////////////////////////////////////////////////////////////////////////////
HeuSpeciesTreeSampler ::  HeuSpeciesTreeSampler( const vector<PhylogenyTreeBasic *> &listGT)
:  listGTConvertPtrs(listGT), numSpecies(-1)
{
	// prepare sampling
	PreSampling();
}

HeuSpeciesTreeSampler :: ~HeuSpeciesTreeSampler()
{
}

#if 0
void HeuSpeciesTreeSampler :: Sample( MarginalTree &treeRes )
{
	// start from whole set
	stack<set<int> > sspeciesToSample;
	set<int> initSS;
	PopulateSetWithInterval(initSS, 0, this->numSpecies-1);
	sspeciesToSample.push(initSS);

	// 
	vector< pair<set<int>, pair<set<int>, set<int> > > > listSPNodeSets;
	while( sspeciesToSample.empty() == false )
	{
		set<int> ssToSample = sspeciesToSample.top();
		sspeciesToSample.pop();
//cout << "Considering subset: ";
//DumpIntSet( ssToSample );
		set<int> subsetSp1, subsetSp2; 
		SampleSubset( ssToSample, subsetSp1, subsetSp2 );

		// continue until reaching the leaf
		if( subsetSp1.size() > 1 )
		{
			sspeciesToSample.push(subsetSp1);
		}
		if( subsetSp2.size() > 1 )
		{
			sspeciesToSample.push(subsetSp2);
		}
		pair<set<int>, set<int> > pp(subsetSp1, subsetSp2);
		pair<set<int>, pair<set<int>, set<int> > > pp2( ssToSample, pp);
		listSPNodeSets.push_back( pp2 );
	}
	FormSpeciesTree(listSPNodeSets, treeRes);
}
#endif

//#if 0
void HeuSpeciesTreeSampler :: SampleBU( MarginalTree &treeRes )
{
	// start from leaves in a bottom up way
	set< STSampleLineage > sspeciesToSample;
	for(int i=0; i<this->numSpecies; ++i)
	{
		set<int> initSS;
		initSS.insert(i);
		// 
		STSampleLineage stslSingle(GetNumGTrees(), initSS);

		for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
		{
			int minNL = GetMaxLinsNumAt(tr, initSS);
			int maxNL = GetMaxLinsNumAt(tr, initSS);
			stslSingle.InitProbTbl(tr, minNL, maxNL);
			int totNumLins = GetNumAllelesForSpecies( i );
			YW_ASSERT_INFO(maxNL == totNumLins, "Wrong in init");

			for(int k=minNL; k<=maxNL; ++k)
			{
				double probStep = CalcCoalProb(totNumLins, k);
				//double probStep = 1.0;
				// 
				YW_ASSERT_INFO( probStep <= 1.0, "Wrong: prob can not be over 1.0" );
				stslSingle.SetProbAt( tr, k, probStep );
			}
		}
		stslSingle.CalcTotWt();

		sspeciesToSample.insert(stslSingle);
	}

	// 
	vector< pair<set<int>, pair<set<int>, set<int> > > > listSPNodeSets;
	while( sspeciesToSample.size() > 1 )
	{
//cout << "Current list of lineages: \n";
//for( set<STSampleLineage > :: iterator itt= sspeciesToSample.begin(); itt != sspeciesToSample.end(); ++itt)
//{
//const_cast<STSampleLineage &>(*itt).Dump( );
//}

		STSampleLineage subsetSpNew, subsetSpOld1, subsetSpOld2; 
		SampleSubset( sspeciesToSample, subsetSpNew, subsetSpOld1, subsetSpOld2 );

		set<int> ss1, ss2, ss3;
		subsetSpNew.GetSpecies(ss1);
		subsetSpOld1.GetSpecies(ss2);
		subsetSpOld2.GetSpecies(ss3);
		pair<set<int>, set<int> > pp(ss2, ss3);
		pair<set<int>, pair<set<int>, set<int> > > pp2( ss1, pp);
		listSPNodeSets.push_back( pp2 );

		// update set of lineages
		YW_ASSERT_INFO( sspeciesToSample.find( subsetSpOld1) != sspeciesToSample.end(), "Wrong ssp1" );
		YW_ASSERT_INFO( sspeciesToSample.find( subsetSpOld2) != sspeciesToSample.end(), "Wrong ssp2" );
		sspeciesToSample.erase( subsetSpOld1 );
		sspeciesToSample.erase( subsetSpOld2 );
		sspeciesToSample.insert( subsetSpNew );
	}

	// now reverse the order
	vector< pair<set<int>, pair<set<int>, set<int> > > > listSPNodeSetsRev;
	for( int i=(int)listSPNodeSets.size()-1; i>=0; --i )
	{
		listSPNodeSetsRev.push_back( listSPNodeSets[i] );
	}
	FormSpeciesTree(listSPNodeSetsRev, treeRes);
}
//#endif


#if 0
void HeuSpeciesTreeSampler :: SampleBU( MarginalTree &treeRes )
{
	// start from leaves in a bottom up way
	set< set<int> > sspeciesToSample;
	for(int i=0; i<this->numSpecies; ++i)
	{
		set<int> initSS;
		initSS.insert(i);
		// 
		//STSampleLineage stslSingle(GetNumGTrees(), initSS);
		//for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
		//{
		//	int minNL = GetMaxLinsNumAt(tr, initSS);
		//	int maxNL = GetMaxLinsNumAt(tr, initSS);
		//	stslSingle.InitProbTbl(tr, minNL, maxNL);
		//	int totNumLins = GetNumAllelesForSpecies( i );
		//	YW_ASSERT_INFO(maxNL == totNumLins, "Wrong in init");
		//	for(int k=minNL; k<=maxNL; ++k)
		//	{
		//		double probStep = CalcCoalProb(totNumLins, k);
		//		//double probStep = 1.0;
		//		// 
		//		YW_ASSERT_INFO( probStep <= 1.0, "Wrong: prob can not be over 1.0" );
		//		stslSingle.SetProbAt( tr, k, probStep );
		//	}
		//}
		//stslSingle.CalcTotWt();
		sspeciesToSample.insert(initSS);
	}

	// 
	vector< pair<set<int>, pair<set<int>, set<int> > > > listSPNodeSets;
	while( sspeciesToSample.size() > 1 )
	{
//cout << "Current list of lineages: \n";
//for( set<STSampleLineage > :: iterator itt= sspeciesToSample.begin(); itt != sspeciesToSample.end(); ++itt)
//{
//const_cast<STSampleLineage &>(*itt).Dump( );
//}

		set<int> subsetSpNew, subsetSpOld1, subsetSpOld2;
		//STSampleLineage subsetSpNew, subsetSpOld1, subsetSpOld2; 
		SampleSubset( sspeciesToSample, subsetSpNew, subsetSpOld1, subsetSpOld2 );

		//set<int> ss1, ss2, ss3;
		//subsetSpNew.GetSpecies(ss1);
		//subsetSpOld1.GetSpecies(ss2);
		//subsetSpOld2.GetSpecies(ss3);
		pair<set<int>, set<int> > pp(subsetSpOld1, subsetSpOld2);
		pair<set<int>, pair<set<int>, set<int> > > pp2( subsetSpNew, pp);
		listSPNodeSets.push_back( pp2 );

		// update set of lineages
		YW_ASSERT_INFO( sspeciesToSample.find( subsetSpOld1) != sspeciesToSample.end(), "Wrong ssp1" );
		YW_ASSERT_INFO( sspeciesToSample.find( subsetSpOld2) != sspeciesToSample.end(), "Wrong ssp2" );
		sspeciesToSample.erase( subsetSpOld1 );
		sspeciesToSample.erase( subsetSpOld2 );
		sspeciesToSample.insert( subsetSpNew );
	}

	// now reverse the order
	vector< pair<set<int>, pair<set<int>, set<int> > > > listSPNodeSetsRev;
	for( int i=(int)listSPNodeSets.size()-1; i>=0; --i )
	{
		listSPNodeSetsRev.push_back( listSPNodeSets[i] );
	}
	FormSpeciesTree(listSPNodeSetsRev, treeRes);
}
#endif


void HeuSpeciesTreeSampler :: PreSampling( )
{
	CollectSpeciesInfo();

	// make sure numSpecies is setup properly
	YW_ASSERT_INFO(this->numSpecies > 0, "Wrong tree format");
//cout << "Num of species = " << numSpecies << endl;

	// setup the buffer for holding min lineages number
	listClusterMinLinsNumPerTree.resize( listGTConvertPtrs.size() );
	listClusterMaxLinsNumPerTree.resize( listGTConvertPtrs.size() );

	FindSpeciesInGT();
	InitAlleleNums();
	//CollectTriples();
	//BuildCNMap();

#if 0
	// the results of building map
	for(int tr = 0; tr<(int)listClusterNumLinsProbPerTree.size(); ++tr )
	{
		cout << "***tree: " << tr << endl;
		for( map< set<int>, vector<double> > :: iterator it = listClusterNumLinsProbPerTree[tr].begin(); 
			it != listClusterNumLinsProbPerTree[tr].end(); ++it )
		{
			cout << "---subset: ";
			DumpIntSet( it->first );
			DumpDoubleVec(it->second);
		}
	}
#endif


#if 0
	// pre-sampling. Look through each gene tree and see how much support a cluster (subtree) has
	// first do some info collection
	CollectSpeciesInfo();

	// process each tree and each node
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++i )
	{
		// iterate through the nodes in this tree
		PhylogenyTreeIterator titor( *listGTConvertPtrs[tr] );
		titor.Init();
		while( titor.IsDone() == false )
		{
			// get current node
			TreeNode *pnCurr = titor.GetCurrNode();
			// if this is leaf, nothing
			if( pnCurr->IsLeaf() == false )
			{
				// 
				ProcNodeAt(tr, pnCurr);
			}

			titor.Next();
		}
	}
#endif
}

#if 0
bool HeuSpeciesTreeSampler :: SampleSubset( const set<int> &species, set<int> &subsetSp1, set<int> &subsetSp2 )
{
cout << " SampleSubset = ";
DumpIntSet( species );
	// nothing to containue, then return false
	YW_ASSERT_INFO(species.size() > 1, "Nothing to continue subset sampling");
	if( species.size() == 2)
	{
		set<int> :: iterator itt1 = species.begin();
		subsetSp1.insert( *itt1 );
		itt1 ++;
		subsetSp2.insert( *itt1 );
		return false;
	}
	// consider the other subsets
	vector<int> vecSpecies;
	for( set<int> :: iterator it = species.begin(); it != species.end(); ++it )
	{
		// 
		vecSpecies.push_back( *it );
	}
	// consider all subsets
	vector< set<int> > listSubsetOne;
	vector<double> listSubsetProb;
	for(int ssize = 0; ssize < (int)vecSpecies.size()-1; ++ssize)
	{
		vector<int> posvec;
		GetFirstCombo( ssize, vecSpecies.size()-1, posvec );
		while(true)
		{
			// form two side
			set<int> sset1, sset2;
			for(int ii=0; ii<(int)posvec.size(); ++ii)
			{
				sset1.insert( vecSpecies[ posvec[ii] ] );
			}
			sset1.insert( vecSpecies[ vecSpecies.size()-1 ] );
			// sset2 is complement of sset1
			sset2 = species;
			SubtractSets(sset2, sset1);
			YW_ASSERT_INFO( sset1.size() + sset2.size() == species.size(), "Wrong here222" );
cout << "sset1 = ";
DumpIntSet( sset1 );
cout << "sset2 = ";
DumpIntSet( sset2 );
			// prob of two
			double prob1 = GetProbWeight( sset1 );
			double prob2 = GetProbWeight( sset2 );
			double wtss = prob1*prob2;
			//double wtss = pow(prob1, 1.0/sset1.size() ) * pow( prob2, 1.0/sset2.size() );
			//if( sset1.size() > 1 && sset2.size() > 1 )
			//{
			//	wtss = sqrt(wtss);
			//}
			listSubsetProb.push_back( wtss );
			listSubsetOne.push_back( sset1 );

			// move to next
			if( GetNextCombo( ssize, vecSpecies.size()-1, posvec ) == false )
			{
				break;
			}
		}
	}
	// now pick one based on prob wts
cout << "Subsets: =\n";
for( int i=0; i<(int)listSubsetOne.size(); ++i)
{
DumpIntSet( listSubsetOne[i] );
}
cout << "Sample subset with prob: ";
DumpDoubleVec(listSubsetProb);
	int sindex = GetWeightedRandItemIndex(listSubsetProb);
	YW_ASSERT_INFO( sindex <(int)listSubsetOne.size(), "Array out of bound" );
	subsetSp1 = listSubsetOne[sindex];
	subsetSp2 = species;
	SubtractSets( subsetSp2, subsetSp1 );
	return true;
}
#endif

//#if 0

bool HeuSpeciesTreeSampler :: SampleSubset( const  set< set<int> > & sspeciesToSample,  set<int> &subsetNew, set<int> &subsetSp1, set<int> &subsetSp2 )
{
	// sample a new subset by merging a pair of existing subsets, based on the probability of the new subset
	// nothing to containue, then return false
	YW_ASSERT_INFO(sspeciesToSample.size() > 1, "Nothing to continue subset sampling");


	// consider all subsets
	vector< set<int> > listSubsetNew, listSubsetOrig1, listSubsetOrig2;
	vector<double> listSubsetProb;

	for(  set< set<int> > :: iterator it1 =  sspeciesToSample.begin(); it1 != sspeciesToSample.end(); ++it1)
	{
		set< set<int> > :: iterator it2 = it1;
		it2 ++;
		for( ; it2 != sspeciesToSample.end(); ++it2)
		{
			// consider adding these two (make sure they are disjoint)
			set<int> stot = *it1;
			UnionSets( stot, *it2 );
			YW_ASSERT_INFO( stot.size() == it1->size() + it2->size(), "Subset wrong" );
			listSubsetNew.push_back( stot );
			listSubsetOrig1.push_back( *it1 );
			listSubsetOrig2.push_back( *it2 );
			//double probSSNew = GetProbWeight( stot );
			double probSSNew = 1.0;
			for(int tr=0; tr<GetNumGTrees(); ++tr)
			{
				probSSNew *= GetTripleSupport( tr, *it1, *it2 );
			}
			listSubsetProb.push_back( probSSNew );
		}
	}
	// 

	// now pick one based on prob wts
//cout << "Subsets (new): =\n";
//for( int i=0; i<(int)listSubsetNew.size(); ++i)
//{
//DumpIntSet( listSubsetNew[i] );
//}
//cout << "Sample subset with prob: ";
//DumpDoubleVec(listSubsetProb);
	int sindex = GetWeightedRandItemIndex(listSubsetProb);
	YW_ASSERT_INFO( sindex <(int)listSubsetNew.size(), "Array out of bound" );
	subsetNew = listSubsetNew[sindex];
	subsetSp1 = listSubsetOrig1[sindex];
	subsetSp2 = listSubsetOrig2[sindex];
	return true;
}
//#endif


bool HeuSpeciesTreeSampler :: SampleSubset(set< STSampleLineage > & sspeciesToSample,  STSampleLineage &subsetNew, STSampleLineage &subsetSp1, STSampleLineage &subsetSp2 )
{
	// when the size of the tree space is reduced to sufficiently small, we resort to uniform sampling of topology
	const int UNIFORM_SAMPLE_THRESHOLD = 4;

	// 
	YW_ASSERT_INFO(sspeciesToSample.size() > 1, "Nothing to continue subset sampling");

	// consider all subsets
	vector< pair<STSampleLineage, pair<const STSampleLineage *, const STSampleLineage *> > > listCoalChoices;
	vector<vector<double > > listSubsetProbForTrees;
	//vector<double> listSubsetProb;

	for(  set< STSampleLineage > :: iterator it1 =  sspeciesToSample.begin(); it1 != sspeciesToSample.end(); ++it1)
	{
		set< STSampleLineage > :: iterator it2 = it1;
		it2 ++;
		for( ; it2 != sspeciesToSample.end(); ++it2)
		{
			// consider adding these two (make sure they are disjoint)
			STSampleLineage coalLinNew;
			GenCoalSTLin(*it1, *it2, coalLinNew);
			pair<const STSampleLineage *, const STSampleLineage *> pp( &(*it1), &(*it2) );
			pair<STSampleLineage, pair<const STSampleLineage *,  const STSampleLineage *> > pp2(coalLinNew, pp);
			listCoalChoices.push_back( pp2 );

			set<int> stot;
			coalLinNew.GetSpecies(stot);

			//double probNormalized = 1.0;
			//if((int) sspeciesToSample.size()  > UNIFORM_SAMPLE_THRESHOLD )
			//{
			//	double probBackground = CalcDefaultProb(stot);
			//	probNormalized = coalLinNew.GetWtTotal()/probBackground;
			//}
			//listSubsetProb.push_back(probNormalized);

//#if 0
			vector<double> probSSNewVec;
			for(int tr=0; tr<GetNumGTrees(); ++tr)
			{
				double probSSNew = 1.0;
				if( (int) sspeciesToSample.size() > UNIFORM_SAMPLE_THRESHOLD )
				{
					probSSNew = coalLinNew.GetWtForTree( tr );
					probSSNew = probSSNew/ CalcDefaultProb(tr, stot );
				}
				probSSNewVec.push_back(probSSNew);
			}
			listSubsetProbForTrees.push_back( probSSNewVec );
//#endif
		}
	}

//#if 0
	// now pick one based on prob wts
	// to avoid numerical problem, divide by the largest item in the each dimension
	for(int tr=0; tr<GetNumGTrees(); ++tr)
	{
		double maxVal = 0.0;
		for( int i=0; i<(int) listSubsetProbForTrees.size(); ++i  )
		{
			if(listSubsetProbForTrees[i][tr] > maxVal )
			{
				maxVal = listSubsetProbForTrees[i][tr];
			}
		}
		// normalize it
		YW_ASSERT_INFO( maxVal > 0.0, "Can not divide by zero" );
		for( int i=0; i<(int) listSubsetProbForTrees.size(); ++i  )
		{
			listSubsetProbForTrees[i][tr] *= 1.0/maxVal;
		}
	}
	// now save the value after the normalization
	vector<double> listSubsetProb;
	for( int i=0; i<(int) listSubsetProbForTrees.size(); ++i  )
	{
		double prob = 1.0;
		for(int tr=0; tr<(int)listSubsetProbForTrees[i].size(); ++tr)
		{
			prob *= listSubsetProbForTrees[i][tr];
		}
		// to avoid overly concerntraing on a single tree (when num of trees grows)
		// we take an average
		//prob = pow(prob, 1.0/GetNumGTrees() );

		listSubsetProb.push_back( prob );
	}
//#endif

//cout << "listCoalChoices (new): =\n";
//for( int i=0; i<(int)listCoalChoices.size(); ++i)
//{
//set<int> setNew;
//listCoalChoices[i].first.GetSpecies(setNew);
//DumpIntSet( setNew );
//}
//cout << "Sample subset with prob: ";
//DumpDoubleVec(listSubsetProb);
	int sindex = GetWeightedRandItemIndex(listSubsetProb);
	YW_ASSERT_INFO( sindex <(int)listCoalChoices.size(), "Array out of bound" );
	subsetNew = listCoalChoices[sindex].first;
	subsetSp1 = *listCoalChoices[sindex].second.first;
	subsetSp2 = *listCoalChoices[sindex].second.second;
	return true;
}

void HeuSpeciesTreeSampler :: GenCoalSTLin(const STSampleLineage &subsetSp1, const STSampleLineage &subsetSp2, STSampleLineage &subsetNew  )
{
	// 
	set<int> sps1, sps2;
	subsetSp1.GetSpecies( sps1 );
	subsetSp2.GetSpecies( sps2 );
	set<int> ssetTot = sps1;
	UnionSets( ssetTot, sps2 );
	YW_ASSERT_INFO( ssetTot.size() == sps1.size() + sps2.size(), "Wrong in GenCoalSTLin"  );
	subsetNew.Init( GetNumGTrees(), ssetTot);
	// setup the prob for each grid point
	//const double SCALE_FACTOR = 1.0;
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		int minNL = GetMinLinsNumAt(tr, ssetTot);
		int maxNL = GetMaxLinsNumAt(tr, ssetTot);
		//int maxNL = GetCNMapNumLinsMax(tr, species);
		subsetNew.InitProbTbl(tr, minNL, maxNL);
		for(int k=minNL; k<=maxNL; ++k)
		{
			double probStep = 0.0;
			for(int k2=k; k2<=maxNL; ++k2)
			{
				// need to try all the number of lineages
				double probSubTot = 0.0;
				for(int k3=1; k3<=k2-1; ++k3)
				{
					double probSub1 = subsetSp1.GetProbAt(tr, k3);
					double probSub2 = subsetSp2.GetProbAt(tr, k2-k3);
					probSubTot += probSub1*probSub2;
				}
				//probTemp += CalcCoalProb(k2, k);
				probStep += probSubTot * CalcCoalProb(k2, k);
			}
			// 
			YW_ASSERT_INFO( probStep <= 1.0, "Wrong: prob can not be over 1.0" );
			subsetNew.SetProbAt( tr, k, probStep );
		}
	}
	// finally compute the prob here
	subsetNew.CalcTotWt();
}


void HeuSpeciesTreeSampler :: FormSpeciesTree(vector< pair<set<int>, pair<set<int>, set<int> > > > &listSPNodeSets, MarginalTree &mTree)
{
	// ASSUME the first node is the root partition
	// The key assumption: the noe splits are in top-down fashion
	vector<int> listLabels;
	vector<int> listParentNodePos;

	int totNodesNum = 2*this->numSpecies - 1;

	// nodes label = 0, 1, 2, ...
	for(int i=0; i<totNodesNum; ++i)
	{
		// 
		listLabels.push_back( i );
	}

	// start from the last node when the ndoe is internal
	listParentNodePos.resize(totNodesNum);
	int nodePosToAssign = totNodesNum-1;
	map< set<int>, int > mapNodeSetToPos;
	for(int i=0; i<(int)listSPNodeSets.size(); ++i )
	{
//cout << "node whole subtree: ";
//DumpIntSet( listSPNodeSets[i].first );
//cout << "node side 1: ";
//DumpIntSet( listSPNodeSets[i].second.first );
//cout << "node side 2: ";
//DumpIntSet( listSPNodeSets[i].second.second );
		// is the larger set already seen?
		if( mapNodeSetToPos.find(listSPNodeSets[i].first) == mapNodeSetToPos.end()  )
		{
			// no, then it must be the root
			YW_ASSERT_INFO( (int)listSPNodeSets[i].first.size() == this->numSpecies, "Root partition wrong" );
			// 
			listParentNodePos[nodePosToAssign] = -1;
			mapNodeSetToPos.insert(  map<set<int>,int> :: value_type( listSPNodeSets[i].first, nodePosToAssign-- ) );
		}
		int nodeParPos = mapNodeSetToPos[listSPNodeSets[i].first];
		// the descendent can not be the in map
		YW_ASSERT_INFO( listSPNodeSets[i].second.first.size() >=1 &&  
			mapNodeSetToPos.find(listSPNodeSets[i].second.first) == mapNodeSetToPos.end(), "Wrong tree format" );
		YW_ASSERT_INFO(listSPNodeSets[i].second.second.size() >= 1 && 
			mapNodeSetToPos.find(listSPNodeSets[i].second.second) == mapNodeSetToPos.end(), "Wrong tree format" );
		int leftDescPos = *(listSPNodeSets[i].second.first.begin() );
		if(listSPNodeSets[i].second.first.size() > 1)
		{
			leftDescPos = nodePosToAssign;
			mapNodeSetToPos.insert(  map<set<int>,int> :: value_type( listSPNodeSets[i].second.first, nodePosToAssign-- ) );
//cout << "Adding to mapNodeSetToPos: " << mapNodeSetToPos[ listSPNodeSets[i].second.first  ] << " for species ";
//DumpIntSet( listSPNodeSets[i].second.first );
		}
		int rightDescPos = *(listSPNodeSets[i].second.second.begin() );
		if(listSPNodeSets[i].second.second.size() > 1)
		{
			rightDescPos = nodePosToAssign;
			mapNodeSetToPos.insert(  map<set<int>,int> :: value_type( listSPNodeSets[i].second.second, nodePosToAssign-- ) );
		}

		// now assign node property in root
		listParentNodePos[leftDescPos] = nodeParPos;
		listParentNodePos[rightDescPos] = nodeParPos;
	}
	InitMarginalTree(mTree, this->numSpecies, listLabels, listParentNodePos );
}


void HeuSpeciesTreeSampler :: CollectSpeciesInfo()
{
	// collect what species label each node has in each of the gene trees
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
//cout << "CollectSpeciesInfo: tree " << tr << endl;
		// iterate through the nodes in this tree
		PhylogenyTreeIterator titor( *listGTConvertPtrs[tr] );
		titor.Init();
		while( titor.IsDone() == false )
		{
			// get current node
			TreeNode *pnCurr = titor.GetCurrNode();
			// if this is leaf, nothing
			//if( pnCurr->IsLeaf() == false )
			//{
			// 
			multiset<int> sSpecies;
			CollectSpecies(pnCurr, sSpecies);
			// store it
			treesNodeLabelsUnder.insert( map<TreeNode *, multiset<int> > :: value_type(pnCurr, sSpecies) );
//cout << "list of subtree labels: ";
//DumpMultiset(sSpecies);
			// setup species info if it is root
			if( pnCurr->GetParent() == NULL)
			{
				set<int> sDistinctSpecies;
				ConvMSetToSet(sSpecies, sDistinctSpecies);
				if(this->numSpecies < 0)
				{
					this->numSpecies = (int)sDistinctSpecies.size();
				}
				else
				{
					YW_ASSERT_INFO( this->numSpecies == (int)sDistinctSpecies.size(), "Inconsistency in different gene tree in labeling"  );
				}
			}

			//}

			titor.Next();
		}
	}
}

void HeuSpeciesTreeSampler :: CollectSpecies(TreeNode *pn, multiset<int> &listSpecies)
{
	// 
	YW_ASSERT_INFO( pn != NULL, "Can not be empty" );
	listSpecies.clear();
	vector<string> listLeafLabels;
	pn->GetAllLeafLabeles(listLeafLabels);
	// convert to int
	for(int i=0; i<(int)listLeafLabels.size(); ++i)
	{
		int id;
		sscanf( listLeafLabels[i].c_str(), "%d", &id );
		listSpecies.insert(id);
	}
}

void HeuSpeciesTreeSampler :: GetSpeciesUnder(TreeNode *pn, multiset<int> &listSpecies)
{
	// 
	YW_ASSERT_INFO( treesNodeLabelsUnder.find(pn) != treesNodeLabelsUnder.end(), "Fail to find" );
	listSpecies = treesNodeLabelsUnder[pn];
}

void HeuSpeciesTreeSampler :: InitAlleleNums()
{
	// simply look at the root of the first tree
	YW_ASSERT_INFO(listGTConvertPtrs.size() > 0, "Tree list empty");
	TreeNode *proot = listGTConvertPtrs[0]->GetRoot();
	YW_ASSERT_INFO(treesNodeLabelsUnder.find(proot) != treesNodeLabelsUnder.end(), "Root of first tree not in map");
	multiset<int> listSpecies;
	GetSpeciesUnder(proot, listSpecies);
	numAllelesSpecies.clear();
	numAllelesSpecies.resize(this->numSpecies);
	for(int i=0; i<(int)numAllelesSpecies.size(); ++i)
	{
		numAllelesSpecies[i] = 0;
	}
	for(multiset<int> :: iterator it = listSpecies.begin(); it != listSpecies.end(); ++it)
	{
		YW_ASSERT_INFO( *it < this->numSpecies && *it >= 0, "Species id wrong" );
		// 
		numAllelesSpecies[*it] ++;
	}
//cout << "InitAlleleNums: numAllelesSpecies: ";
//DumpIntVec( numAllelesSpecies );
}

//void HeuSpeciesTreeSampler :: InitMinLinsNumClusters()
//{
//	// test each cluster and 
//}

int HeuSpeciesTreeSampler :: GetMinLinsNumAt(int tr, const set<int> &cluster)
{
	// if it is not in map, find it
	YW_ASSERT_INFO((int)listClusterMinLinsNumPerTree.size() > tr, "Failure1");
	if( listClusterMinLinsNumPerTree[tr].find( cluster) == listClusterMinLinsNumPerTree[tr].end() )
	{
		// search for it
		set<TreeNode *> setNodesPar;
		FindLCAClusterInGT(tr, cluster, setNodesPar);
		listClusterMinLinsNumPerTree[tr].insert( map<set<int>, int> :: value_type(cluster, setNodesPar.size() ) );
	}
	YW_ASSERT_INFO( listClusterMinLinsNumPerTree[tr].find(cluster) != listClusterMinLinsNumPerTree[tr].end(), "Failure 2" );
	return listClusterMinLinsNumPerTree[tr][cluster];
}



int HeuSpeciesTreeSampler :: GetMaxLinsNumAt(int tr, const set<int> &cluster)
{
	// if it is not in map, find it
	YW_ASSERT_INFO((int)listClusterMaxLinsNumPerTree.size() > tr, "Failure1");
	if( listClusterMaxLinsNumPerTree[tr].find( cluster) == listClusterMaxLinsNumPerTree[tr].end() )
	{
		// search for it
		int numTotLins = 0;
		for(  set<int> :: iterator it = cluster.begin(); it != cluster.end(); ++it )
		{
			numTotLins += GetNumAllelesForSpeciesInGT(tr, *it);
		}
		listClusterMaxLinsNumPerTree[tr].insert( map<set<int>, int> :: value_type(cluster,numTotLins ) );
	}
	YW_ASSERT_INFO( listClusterMaxLinsNumPerTree[tr].find(cluster) != listClusterMaxLinsNumPerTree[tr].end(), "Failure 2" );
	return listClusterMaxLinsNumPerTree[tr][cluster];
}



#if 0


void HeuSpeciesTreeSampler :: ProcNodeAt(int tr, TreeNode *pn)
{
	TBD
}

double HeuSpeciesTreeSampler :: ProcNodeRearrange( int tr, TreeNode *pnCur, const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattach )
{
}

// the rearrangement induces a local gene and species tree, which will determine how likely the rearrangement will be
// caution: the rearrangement nodes should move accross the current node
void HeuSpeciesTreeSampler :: ProcNodeRearrangeNewTrees( int tr, TreeNode *pnCur, const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattach, 
	MarginalTree &sTreeLocal, PhylogenyTree &gTreeLocal )
{
}

bool HeuSpeciesTreeSampler :: FitSpeciesCluster(int tr, TreeNode *pnCur, const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattach)
{
	// does the rearrangement make the nodes having to partition?
	// that is, two branches have different sets of descendents (disjoint)
}

bool HeuSpeciesTreeSampler :: FitSpeciesCluster(int tr, const vector<TreeNode *> &listPnLeft const vector<TreeNode *> &listPnRight, 
												const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattachFromLeft,
												const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattachFromRight )
{
	// does the rearrangement make the nodes having to partition?
	// that is, two branches have different sets of descendents (disjoint)
	multiset<int> speciesLeft, speciesRight;

	// 
	set<TreeNode *> removedLeft;
	for(int i=0; i<(int)listNodeReattachFromLeft.size(); ++i )
	{
		removedLeft.insert( listNodeReattachFromLeft[i].first );
	}
	multiset<int> msetLeft;
	CollectSpeciesAt(listPnLeft, removedLeft, msetLeft);
	// collect the nodes
	set<TreeNode *> removedRight;
	for(int i=0; i<(int)listNodeReattachFromRight.size(); ++i )
	{
		removedRight.insert( listNodeReattachFromRight[i].first );
	}
	multiset<int> msetRight;
	CollectSpeciesAt(listPnRight, removedRight, msetRight);

	// are these two disjoint
	multiset<int> msetJoin;
	JoinMultiset( msetLeft, msetRight, msetJoin);
	if( msetJoin.size() == 0 )
	{
		// there is no overlap between the species
		return true;
	}
	else
	{
		return false;
	}
}

bool HeuSpeciesTreeSampler :: FitSpeciesCluster(int tr, const set<TreeNode *> &listPnLeft, const set<TreeNode *> &listPnRight )
{
	vector<TreeNode *> vecPhLeft, vecPhRight;
	for(set<TreeNode *> :: iterator it=listPhLeft.begin(); it != listPhLeft.end(); ++it)
	{
		vecPhLeft.push_back( *it );
	}
	for(set<TreeNode *> :: iterator it=listPhRight.begin(); it != listPhRight.end(); ++it)
	{
		vecPhRight.push_back( *it );
	}
	set<TreeNode *> dummy;

	// does the rearrangement make the nodes having to partition?
	// that is, two branches have different sets of descendents (disjoint)
	multiset<int> speciesLeft, speciesRight;

	// 

	multiset<int> msetLeft;
	CollectSpeciesAt(vecPnLeft, dummy, msetLeft);

	multiset<int> msetRight;
	CollectSpeciesAt(vecPnRight, dummy, msetRight);

	// are these two disjoint
	multiset<int> msetJoin;
	JoinMultiset( msetLeft, msetRight, msetJoin);
	if( msetJoin.size() == 0 )
	{
		// there is no overlap between the species
		return true;
	}
	else
	{
		return false;
	}
}


void HeuSpeciesTreeSampler :: CollectSpeciesAt( const vector<TreeNode *>  &listPnLeft, const set<TreeNode *> &removedLeft, multiset<int> &msetLeft)
{
	for(int i=0; i<(int)listPnLeft.size(); ++i)
	{
		if( removedLeft.find( listPhLeft[i] ) == removedLeft.end() )
		{
			// add it
			multiset<int> listSpecies;
			GetSpeciesUnder(listPhLeft[i], listSpecies);
			UnionMultiset( msetLeft, listSpecies );
		}
	}
}


bool HeuSpeciesTreeSampler :: FindSubtreeProb(const set<int> &species, double &probSubtree)
{
	// return false if not found
}

void HeuSpeciesTreeSampler :: ProcNodesTwoSides(int tr, TreeNode *pnCur, const set<TreeNode *> &setOrigNodesLeft, 
												const set<TreeNode *> &setOrigNodesRight,
		const set<TreeNode *> &setNodesLeftActive, const set<TreeNode *> &setNodesRightActive)
{
	// we have to put a limit on how much we can proceed
	const int MAX_NUM_NODES = 6;
	if( setOrigNodesLeft.size() > MAX_NUM_NODES || setOrigNodesRight.size() > MAX_NUM_NODES )
	{
		// too large
		return;
	}

	// handle left and right side nodes
	// note, only active nodes can be re-arranged (moved) to the other side
	// also, this is recursive
	vector<TreeNode *> vecNodesLeftActive, vecNodesRightActive;
	for( set<TreeNode *> :: iterator it = setNodesLeftActive.begin(); it != setNodesLeftActive.end(); ++it )
	{
		vecNodesLeftActive.push_back(*it);
	}
	for( set<TreeNode *> :: iterator it = setNodesRightActive.begin(); it != setNodesRightActive.end(); ++it )
	{
		vecNodesRightActive.push_back(*it);
	}

	const int MAX_SS_SIZE = 2;		// limit on num of branches to move
	int szLeftMove = 0;
	while(szLeftMove <= MAX_SS_SIZE && szLeftMove <= (int)setNodesLeftActive.size())
	{
		// select
		vector<int> posvecLeft;
		GetFirstCombo( szLeftMove, setNodesLeftActive.size(), posvecLeft );
		while(true)
		{
			// get the moved set
			int szRightMove = 0;
			while(szRightMove <= MAX_SS_SIZE && szRightMove <= (int)setNodesRightActive.size())
			{
				// select
				vector<int> posvecRight;
				GetFirstCombo( szRightMove, setNodesRightActive.size(), posvecRight );
				while(true)
				{
					// get the moved set on left and right
					set<TreeNode *> nodeLeftNew = setOrigNodesLeft, nodeRightNew=setOrigNodesRight;
					set<TreeNode *> nodeLeftNewAdd;
					for( int i3=0; i3<(int)posvecLeft.size(); ++i3 )
					{
						nodeRightNew.insert( vecNodesLeft[i3] );
						nodeLeftNewAdd.push_back( vecNodesLeft[i3] );
					}
					// put the rest into left
					for(set<TreeNode *>:: iterator it3 = setNodesLeftActive.begin(); it3 != setNodesLeftActive.end(); ++it3 )
					{
						// add if not already in
						if( nodeLeftNewAdd.find( *it3 ) != nodeLeftNewAdd.end() )
						{
							nodeLeftNew.insert( *it3 );
						}
					}

					set<TreeNode *> nodeRightNewAdd;
					for( int i3=0; i3<(int)posvecRight.size(); ++i3 )
					{
						nodeLeftNew.insert( vecNodesRight[i3] );
						nodeRightNewAdd.push_back( vecNodesRight[i3] );
					}
					// put the rest into left
					for(set<TreeNode *>:: iterator it3 = setNodesRightActive.begin(); it3 != setNodesRightActive.end(); ++it3 )
					{
						// add if not already in
						if( nodeRightNewAdd.find( *it3 ) != nodeRightNewAdd.end() )
						{
							nodeRightNew.insert( *it3 );
						}
					}

					// does this form a legal partition
					if( FitSpeciesCluster(tr, nodesLeft, nodesRight) == true)
					{
						// record it
						double wtSubtrees = CalcClusterWt( tr,  setOrigNodesLeft, setOrigNodesRight, 
							setNodesLeftActive, setNodesRightActive,  szLeftMove, szRightMove );
						// add to record
						RecordSubtree( tr, wtSubtrees, nodeLeftNew, nodeRightNew);

						// recursion to go from here by checking each current node, if they are internal, remove it and add its two descendent to 
						// active list
						set<set<TreeNode *> > setLeftRec, setRightRec;
						// add self (but be careful not to consider the identical left/right
						setLeftRec.insert( nodeLeftNew );
						setRightRec.insert( nodeRightNew );

						for( set<TreeNode *> :: iterator itg1=nodeLeftNew.begin(); itg1 != nodeLeftNew.end(); ++itg1 )
						{
							//
							if( (*itg1)->IsLeaf() == false)
							{
								set<TreeNode *> nodesLeftRec = nodeLeftNew;
								nodesLeftRec.erase( *itg1 );
								// add its children
								for(int tt3=0; tt3<(*itg1)->GetChildrenNum(); ++tt3)
								{
									nodesLeftRec.insert( (*itg1)->GetChild(tt3)  );
								}
								setLeftRec.insert( nodesLeftRec );
							}
						}
						// try right
						for( set<TreeNode *> :: iterator itg2=nodeRightNew.begin(); itg2 != nodeRightNew.end(); ++itg2 )
						{
							//
							if( (*itg2)->IsLeaf() == false)
							{
								set<TreeNode *> nodesRightRec = nodeRightNew;
								nodesRightRec.erase( *itg2 );
								// add its children
								for(int tt4=0; tt4<(*itg2)->GetChildrenNum(); ++tt4)
								{
									nodesRightRec.insert( (*itg2)->GetChild(tt4)  );
								}
								setRightRec.insert( nodesRightRec );
							}
						}
						// consider both
						for( set< set<TreeNode *> > :: itg3= setLeftRec.begin(); itg3 != setLeftRec.end(); ++itg3)
						{
							for( set< set<TreeNode *> > :: itg4= setRightRec.begin(); itg4 != setRightRec.end(); ++itg4)
							{
								if( *itg3 !=  nodeLeftNew || *itg4 != nodeRightNew )
								{
									// recurse
									ProcNodesTwoSides( tr, pnCur, const set<TreeNode *> &setOrigNodesLeft, 
												const set<TreeNode *> &setOrigNodesRight,
												const set<TreeNode *> &setNodesLeftActive, const set<TreeNode *> &setNodesRightActive)
								}
							}
						}
					}




					// move to next
					if( GetNextCombo( szRightMove, setNodesRightActive.size(), posvecRight ) == false )
					{
						break;
					}
				}

				// 
				szRightMove ++;
			}


			// move to next
			if( GetNextCombo( szLeftMove, setNodesLeftActive.size(), posvecLeft ) == false )
			{
				break;
			}
		}

		// 
		szLeftMove ++;
	}
}

void HeuSpeciesTreeSampler :: SplitNodesLeftRight( TreeNode *pnCur,  const set<TreeNode *> &setOrigNodes, 
						 set<TreeNode *> &setNodesLeftActive, set<TreeNode *> &setNodesRightActive )
{
	// split the nodes into left and right from the curent node
	// do this by tracing backwards, until the ancestor is only of size 2
	//while(true)
	//{
	//	set<TreeNode *> nodesPar;
	//	for(  )
	//	{
	//	}
	//}
	YW_ASSERT_INFO( pnCur != NULL && pnCur->IsLeaf() == false, "Can not process leaf" );
	YW_ASSERT_INFO( pnCur->GetChildrenNum() == 2, "Only work with binary tree for now" );
	TreeNode *pnLeft = pnCur->GetChild(0);
	TreeNode *pnRight = pnCur->GetChild(1);
	setNodesLeftActive.clear();
	setNodesRightActive.clear();
	for( set<TreeNode *> :: iterator it= setOrigNodes.begin(); it != setOrigNodes.end(); ++it )
	{
		int dummy;
		if( pnLeft->IsAncesterOf(*it, dummy) == true )
		{
			setNodesLeftActive.insert( *it );
		}
		else
		{
			setNodesRightActive.insert( *it );
		}
	}
}

#endif


#if 0
void HeuSpeciesTreeSampler :: BuildCNMap()
{
	// make sure size works
	listClusterNumLinsProbPerTree.resize(listGTConvertPtrs.size());
	// ???


	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		BuildCNMapFor(tr);
	}
}

void HeuSpeciesTreeSampler :: BuildCNMapFor(int tr)
{
//cout << "BuildCNMapFor: " << tr << endl;
	// enumerate over all subset of species
	for(int nr = 1; nr <= numSpecies; ++nr)
	{
//cout << "nr = " << nr << endl;
		// Now, we enumerate all combinations of nr rows
		// We do this by first get the position vector of each such cases
		vector<int> posvec;
		GetFirstCombo( nr, numSpecies, posvec );
		while(true)
		{
//cout << "Now treat cell for: " ;
//DumpIntVec( posvec );
			// Create a vector, and set the index vector
			//vector<int> subsetIndex;
			vector<int> subsetRows;
			//GetIntVec(numRows, posvec, subsetIndex );
			subsetRows = posvec;
			set<int> setRows;
			PopulateSetByVec( setRows, subsetRows );
//cout << "setRows = ";
//DumpIntSet( setRows );
			// Initize the size
			PrepareTableAt( tr, setRows );

			if( nr == 1)
			{
				int spCurr = *( setRows.begin() );
				// for a single species, only set the current num of allels to be 1.0
				int numAllelesCurSp = GetNumAllelesForSpeciesInGT(tr, spCurr);
				AddCNMapProb(tr, setRows, numAllelesCurSp, 1.0 );
			}
			else
			{

				// consider all subset of it
				for(int nrsub = 0; nrsub < (int)setRows.size()-1; ++nrsub)
				{
					vector<int> posvecsub;
					GetFirstCombo( nrsub, setRows.size()-1, posvecsub );
					while(true)
					{
						// 
						set<int> subsetRows;
						for(int i=0; i<(int)posvecsub.size(); ++i)
						{
							// 
							YW_ASSERT_INFO( posvecsub[i] < (int)posvec.size(), "Out of bound" );
							int index = posvec[ posvecsub[i] ];
							subsetRows.insert( index );
						}
						// add the last item in
						YW_ASSERT_INFO( setRows.size() == posvec.size(), "setRows and posvec wrong" );
						subsetRows.insert( posvec[ setRows.size()-1 ] );
						set<int> subsetRowsOther = setRows;
						SubtractSets(subsetRowsOther, subsetRows);

						// 
						//CLUSTER_INFO_GT cigLeft, cigRight;
						//FindClusterInfoInGT(tr, subsetRows, cigLeft);
						//FindClusterInfoInGT(tr, subsetRowsOther, cigRight);
						// try all ways of merging left and right
						MergeLeftRightClusters( tr, setRows, subsetRows, subsetRowsOther );


						// Get the next position
						if( GetNextCombo( nrsub, setRows.size()-1, posvecsub ) == false )
						{
							break;
						}
					}

				}
			}


			// Get the next position
			if( GetNextCombo( nr, numSpecies, posvec ) == false )
			{
				break;
			}
		}

	}

}
#endif


// utility
double HeuSpeciesTreeSampler :: CalcDefaultProb(const set<int> &species)
{
	double res = 1.0;
	for(int tr=0; tr<(int)GetNumGTrees(); ++tr)
	{
		// 
		//int minLins = GetMinLinsNumAt(tr, species);
		//int maxLins = GetMaxLinsNumAt(tr, species);
		//res *= CalcCoalProb(maxLins, minLins);
		res *= CalcDefaultProb(tr, species);
	}
	return res;
}

double HeuSpeciesTreeSampler :: CalcDefaultProb(int tr, const set<int> &species)
{
	static vector<map< set<int>, double> > listDefSpeciesProbs( GetNumGTrees() );

	YW_ASSERT_INFO( tr<(int)GetNumGTrees(), "Wrong" );

	if( listDefSpeciesProbs[tr].find( species ) != listDefSpeciesProbs[tr].end() )
	{
		return listDefSpeciesProbs[tr][species];
	}

	// 
	int minLins = GetMinLinsNumAt(tr, species);
	int maxLins = GetMaxLinsNumAt(tr, species);
	double res = CalcCoalProb(maxLins, minLins);
	listDefSpeciesProbs[tr].insert( map< set<int>, double> :: value_type(species, res) );
	return res;
}

void HeuSpeciesTreeSampler :: FindClusterInfoInGT(int tr, const set<int> &cluster, CLUSTER_INFO_GT &cig)
{
	// max = union of all lineages of each species
	int numTotLins = 0;
	for(  set<int> :: iterator it = cluster.begin(); it != cluster.end(); ++it )
	{
		numTotLins += GetNumAllelesForSpeciesInGT(tr, *it);
	}
	cig.maxNumLins = numTotLins;
	// now the lower bound: but how
	//set<TreeNode *> setNodesPar;
	//FindLCAClusterInGT(tr, cluster, setNodesPar);
	//cig.minNumLins = setNodesPar.size();
	int minNumLins = GetMinLinsNumAt(tr, cluster);
	cig.minNumLins = minNumLins;
}

void HeuSpeciesTreeSampler :: FindLCAClusterInGT(int tr, const set<int> &cluster, set<TreeNode *> &setNodesPar)
{
	// move its way up if it only contains nodes in 
	setNodesPar.clear();
	//set<TreeNode *> nodesProcessed;
	stack<TreeNode *> stackNodes;
	stackNodes.push( listGTConvertPtrs[tr]->GetRoot() );
	while( stackNodes.empty() == false)
	{
		TreeNode *pncurr = stackNodes.top();
		stackNodes.pop();

		if(pncurr->IsLeaf() == true)
		{
			multiset<int> msTaxa;
			GetSpeciesUnder(pncurr, msTaxa);
			set<int> smsTaxa;
			ConvMSetToSet( msTaxa, smsTaxa);
			if(  IsSetContainer(cluster, smsTaxa) == true  )
			{
				// add it if the taxa is contained
				setNodesPar.insert( pncurr );
			}
		}
		else
		{
			// get descendents
			vector< multiset<int> > listChildTaxa;
			bool fIns = true;
			for(int i=0; i<pncurr->GetChildrenNum(); ++i)
			{
				multiset<int> msTaxa;
				GetSpeciesUnder(pncurr->GetChild(i), msTaxa );
				set<int> smsTaxa;
				ConvMSetToSet( msTaxa, smsTaxa);
				if(  IsSetContainer(cluster, smsTaxa) == false  )
				{
					fIns = false;
				}
			}
			if( fIns == true )
			{
				// 
				setNodesPar.insert( pncurr );
			}
			else
			{
				// queue all the children
				for(int i=0; i<pncurr->GetChildrenNum(); ++i)
				{
					stackNodes.push(pncurr->GetChild(i) );
				}
			}
		}
	}
}


// return the num of lineages
void HeuSpeciesTreeSampler :: FindSpeciesInGT()
{
	listSpeciesAlleleNum.resize(listGTConvertPtrs.size() );
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		// 
		listSpeciesAlleleNum[tr].resize(numSpecies);
		for(int sp = 0; sp < numSpecies; ++sp)
		{
			// 
			listSpeciesAlleleNum[tr][sp] = 0;
		}
		// treat each tree
		set<int> speciesStep;
		GetLeavesSpeciesFromGT( *listGTConvertPtrs[tr], speciesStep );
		for(set<int> :: iterator itt = speciesStep.begin(); itt != speciesStep.end(); ++itt)
		{
			YW_ASSERT_INFO( *itt < numSpecies, "Speices out of range" );
			listSpeciesAlleleNum[tr][*itt] ++;
		}
		//vector<string> listLeafLabels;
		//TreeNode *proot = listGTConvertPtrs[tr]->GetRoot();
		//proot->GetAllLeafLabeles(listLeafLabels);
		//// convert to int
		//for(int i=0; i<(int)listLeafLabels.size(); ++i)
		//{
		//	int id;
		//	sscanf( listLeafLabels[i].c_str(), "%d", &id );
		//	YW_ASSERT_INFO( id < numSpecies, "Speices out of range" );
		//	listSpeciesAlleleNum[tr][id] ++;
//cout << "Tree " << tr << ", species " << id << " has allele num " << listSpeciesAlleleNum[tr][id] << endl;
		//}
	}
}

int HeuSpeciesTreeSampler :: GetNumAllelesForSpeciesInGT(int tr, int sp)
{
	YW_ASSERT_INFO(sp <(int)listSpeciesAlleleNum[tr].size(), "Fail to find");
	return listSpeciesAlleleNum[tr][sp];
}



#if 0
double HeuSpeciesTreeSampler :: GetCNMapProb( int tr, const set<int> & cluster, int numLins )
{
if( listClusterNumLinsProbPerTree[tr].find( cluster ) == listClusterNumLinsProbPerTree[tr].end() )
{
cout << "Fail to find cluster: ";
DumpIntSet(cluster);
}
	YW_ASSERT_INFO( listClusterNumLinsProbPerTree[tr].find( cluster ) != listClusterNumLinsProbPerTree[tr].end(), "Fail to find cluster1");
if( numLins >= (int) listClusterNumLinsProbPerTree[tr][cluster].size()  )
{
cout << "size mistake: numLins = " << numLins << ", listClusterNumLinsProbPerTree[tr][cluster].size() = " << listClusterNumLinsProbPerTree[tr][cluster].size() << endl;
cout << "tr = " << tr << ", cluster = ";
DumpIntSet(cluster);
}
	YW_ASSERT_INFO( numLins < (int) listClusterNumLinsProbPerTree[tr][cluster].size() , "Size mistake");

	return listClusterNumLinsProbPerTree[tr][cluster][numLins];
}

int HeuSpeciesTreeSampler :: GetCNMapNumLinsMax(int tr,const set<int> & cluster )
{
	YW_ASSERT_INFO( listClusterNumLinsProbPerTree[tr].find( cluster ) != listClusterNumLinsProbPerTree[tr].end(), "Fail to find cluster2");
	return listClusterNumLinsProbPerTree[tr][cluster].size();
}


void HeuSpeciesTreeSampler :: AddCNMapProb( int tr, const set<int> &cluster, int numLins, double prob)
{
	// 
	YW_ASSERT_INFO( listClusterNumLinsProbPerTree[tr].find( cluster ) != listClusterNumLinsProbPerTree[tr].end(), "Fail to find cluster");
	YW_ASSERT_INFO( numLins < (int) listClusterNumLinsProbPerTree[tr][cluster].size() , "Size mistake");
	listClusterNumLinsProbPerTree[tr][cluster][numLins] += prob;
}

void HeuSpeciesTreeSampler :: MergeLeftRightClusters( int tr, const set<int> &setRows, const set<int> &subsetRows, const set<int> &subsetRowsOther )
{
	// 
//cout << "Left: subset rows = ";
//DumpIntSet(subsetRows);
//cout << "Right subset rows = ";
//DumpIntSet(subsetRowsOther);
	CLUSTER_INFO_GT cigLeft, cigRight;
	FindClusterInfoInGT(tr, subsetRows, cigLeft);
	FindClusterInfoInGT(tr, subsetRowsOther, cigRight);
	// 
	for(int nleft = cigLeft.minNumLins; nleft <= cigLeft.maxNumLins; ++nleft)
	{
//cout << "nleft = " << nleft << endl;
		double probLeft = GetCNMapProb(tr, subsetRows, nleft);
//cout << "probLeft = " << probLeft << endl;
		for(int nleftFinal = nleft; nleftFinal >= cigLeft.minNumLins; nleftFinal --)
		{
			double probLeftChange = CalcCoalProb(nleft, nleftFinal);
//cout <<  "nleftFinal = " << nleftFinal << ", probLeftChange = " << probLeftChange << endl;

			for(int nright = cigRight.minNumLins; nright <= cigRight.maxNumLins; ++nright)
			{
//cout << "nright = " << nright << endl; 
				double probRight = GetCNMapProb(tr, subsetRowsOther, nright);
//cout << "proRight = " << probRight << endl;

				for(int nrightFinal = nright; nrightFinal >= cigRight.minNumLins; nrightFinal --)
				{
					double probRightChange = CalcCoalProb(nright, nrightFinal);
//cout <<  "nrightFinal = " << nrightFinal << ", probRightChange = " << probRightChange << endl;

					// 
					int numSubtot = nleftFinal + nrightFinal;
					// 
					double probSubFinal = probLeft*probLeftChange*probRight*probRightChange;
//cout << " probSubFinal = " << probSubFinal << ", for numSubtot = " << numSubtot << endl;
					AddCNMapProb(tr, setRows, numSubtot, probSubFinal );
				}
			}
		}
	}
}

void HeuSpeciesTreeSampler :: PrepareTableAt(int tr, const set<int> & setRows )
{
	// 
	CLUSTER_INFO_GT cig;
	FindClusterInfoInGT(tr, setRows, cig);
//cout << "tr = " << tr << ", numMin = " << cig.minNumLins << ", numMax = " << cig.maxNumLins << ", species = ";
//DumpIntSet( setRows );
	vector<double> vecDD;
	for( int i=0; i<=cig.maxNumLins; ++i )
	{
		vecDD.push_back(0.0);
	}
	listClusterNumLinsProbPerTree[tr].insert( map< set<int>, vector<double> > :: value_type( setRows, vecDD ) );
}
#endif





double HeuSpeciesTreeSampler :: CalcCoalProb(int numSrc, int numDest)
{
	YW_ASSERT_INFO( numSrc >= numDest, "Wrong in CalcCoalProb: src should be at least num dest" );
	return UtilsCalcCoalProbBranch(numSrc, numDest, 1.0);
}

int HeuSpeciesTreeSampler :: GetNumAllelesForSpecies(const set<int> setSps) const
{
	int res = 0;
	for(set<int> :: iterator it = setSps.begin(); it != setSps.end(); ++it )
	{
		res += GetNumAllelesForSpecies(*it);
	}
	return res;
}

#if 0

double HeuSpeciesTreeSampler :: GetProbWeight( const set<int> &species )
{
#if 0
	// prob of the subset of species given all the trees
	// to avoid underflow, multiply by a scaling factor for each tree
	const double SCALE_FACTOR = 1.0;
	int numSrc = GetNumAllelesForSpecies(species);
//cout << "numSrc = " << numSrc << ", for species: ";
//DumpIntSet(species);
	double res = 1.0;
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		double probStep = 0.0;
		for(int k=1; k<GetCNMapNumLinsMax(tr, species); ++k)
		{
			double probTemp = GetCNMapProb(tr, species, k);
			probTemp*= CalcCoalProb(numSrc, k);
			probStep += probTemp;
		}
		res *= probStep * SCALE_FACTOR;
	}
	return res;
#endif

	// we have a double loop for each cluster: one for each possible
	// final lineages and one for each source lin num
	const double SCALE_FACTOR = 1.0;
	//int numSrc = GetNumAllelesForSpecies(species);
//cout << "numSrc = " << numSrc << ", for species: ";
//DumpIntSet(species);
	double res = 1.0;
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		double probStep = 0.0;
		int minNL = GetMinLinsNumAt(tr, species);
		int maxNL = GetCNMapNumLinsMax(tr, species);
		for(int k=minNL; k<maxNL; ++k)
		{
			for(int k2=k; k2<maxNL; ++k2)
			{
				double probTemp = GetCNMapProb(tr, species, k2);
				probTemp*= CalcCoalProb(k2, k);
				probStep += probTemp;
			}
		}
		if( probStep > 1.0)
		{
cout << "Warning: probStep = " << probStep << endl;
cout << "minNL: " << minNL << ", maxNL: " << maxNL << endl;
probStep = 0.0;
for(int k=minNL; k<maxNL; ++k)
{
for(int k2=k; k2<maxNL; ++k2)
{
double probBase = GetCNMapProb(tr, species, k2);
double probTrans = CalcCoalProb(k2, k);
double probTemp = probBase * probTrans;
cout << "probBase = " << probBase << ", probTrans = " << probTrans << ", probTemp = " << probTemp << "**** so far prob = " << probStep << endl;
probStep += probTemp;
}
}
YW_ASSERT_INFO(false, "Stop");
			probStep = 1.0;
		}
		//YW_ASSERT_INFO(probStep < 1.0, "Can not be too large");
		res *= probStep * SCALE_FACTOR;
	}
	return res;
}

#endif



// how frequent each triple shows up in trees 
void HeuSpeciesTreeSampler :: CollectTriples()
{
	for( int tr=0; tr<(int)listGTConvertPtrs.size(); ++tr )
	{
		// 
		map< pair<pair<int,int>,int>, double> mapCurrTree;
		int numAlleles = listGTConvertPtrs[tr]->GetNumLeaves();
		YW_ASSERT_INFO(numAlleles >= 3, "Tree too small");
		int numTotTriple = numAlleles*(numAlleles-1)*(numAlleles-2)/6;
		listTotTriplesNum.push_back(numTotTriple);

		// get all leaves
		vector< TreeNode *> listLeafNodes;
		listGTConvertPtrs[tr]->GetAllLeafNodes( listLeafNodes);

		// collect species label for each node
		//vector<int> listLeafSpeciesIds(listLeafNodes.size());
		map<TreeNode*, int> mapNodeToId;
		for(int i=0; i<(int)listLeafNodes.size(); ++i)
		{
			multiset<int> listSpecies;
			GetSpeciesUnder(listLeafNodes[i], listSpecies);
			YW_ASSERT_INFO(listSpecies.size() == 1, "Leaf can not be labeled multiple times");
			//listLeafSpeciesIds[i] = *(listSpecies.begin());
			mapNodeToId.insert( map<TreeNode*, int> :: value_type(listLeafNodes[i], *(listSpecies.begin())) );
		}

		// consider all triples
		for(int i=0; i<(int)listLeafNodes.size(); ++i)
		{
			for(int j=i+1; j<(int)listLeafNodes.size(); ++j)
			{
				for(int k=j+1; k<(int)listLeafNodes.size(); ++k)
				{
					// 
					pair<pair<TreeNode *, TreeNode *>, TreeNode *> triple;
					bool fValid = GetTripleType( listLeafNodes[i],  listLeafNodes[j], listLeafNodes[k], triple );
					YW_ASSERT_INFO(fValid == true, "We assume gene trees to be binary");

					// 
					int lb1 = mapNodeToId[ triple.first.first ];
					int lb2 = mapNodeToId[ triple.first.second ];
					int lb3 = mapNodeToId[ triple.second ];
					pair<int,int> pp3(lb1,lb2);
					OrderInt(pp3.first, pp3.second);
					pair<pair<int,int>,int> pp4(pp3, lb3);
					if( mapCurrTree.find( pp4 ) == mapCurrTree.end() )
					{
						mapCurrTree.insert( map< pair<pair<int,int>,int>, double> :: value_type(pp4, 0.0)  );
					}
					mapCurrTree[pp4]+= 1.0;
				}
			}
		}
		// normailize
		for( map< pair<pair<int,int>,int>, double> :: iterator itt = mapCurrTree.begin(); itt != mapCurrTree.end(); ++itt )
		{
			itt->second = itt->second/numTotTriple;
		}
// dump
//cout << "Tree " << tr << ", list of triple/frequency:\n";
//for( map< pair<pair<int,int>,int>, double> :: iterator itt = mapCurrTree.begin(); itt != mapCurrTree.end(); ++itt )
//{
//cout << "(" << itt->first.first.first << "," <<  itt->first.first.second << "), " <<  itt->first.second  <<  "Frequency: " << itt->second << "\n";
//}

		// finally save it
		listTripleFreqPerTree.push_back(mapCurrTree);
	}
}

// how frequent a triple shows up
double HeuSpeciesTreeSampler :: GetTripleFreq(int tr, int a, int b, int c)
{
	YW_ASSERT_INFO( tr <(int)listTripleFreqPerTree.size(), "Fail in GetTripleFreq" );
	pair<int,int> pp(a,b);
	OrderInt( pp.first, pp.second);
	pair<pair<int,int>,int> pp2(pp,c);
	if( listTripleFreqPerTree[tr].find( pp2) == listTripleFreqPerTree[tr].end() )
	{
		// such triple not in tree, so we just give a background value 1/3
		YW_ASSERT_INFO( tr<(int)listTotTriplesNum.size(), "listTotTriplesNum: out of range" );
		return 1.0/(3*( listTotTriplesNum[tr] ));
	}
	else
	{
		return listTripleFreqPerTree[tr][pp2];
	}
}

// degenerate case: how frequent a pair of taxa becomes twins in each gene tree
double HeuSpeciesTreeSampler :: GetTwinFreq(int tr, int a, int b)
{
	// idea: consider a,b, and each other species c
	// use the average frequency of (a,b),c as the frequency for (a,b)
	YW_ASSERT_INFO( this->numSpecies >= 3, "Must have at least three or more taxa" );
	double freqSum = 0.0;
	for(int c = 0; c<this->numSpecies; ++c)
	{
		if( c != a && c != b)
		{
			freqSum += GetTripleFreq(tr,a,b,c);
		}
	}
	return freqSum/(this->numSpecies-2);
}

double HeuSpeciesTreeSampler :: GetTripleSupport(int tr, const set<int> &sset1, const set<int> &sset2)
{
	// we use average of all triples implied by two sides
	// first consider the degenerate case: both side are leaves
	if( sset1.size() == 1 && sset2.size() == 1)
	{
		int a = *(sset1.begin());
		int b = *(sset2.begin());
		return GetTwinFreq(tr, a, b);
	}
	// consider how many support we have implied by two paritition
	int numTotTriples = 0;
	double totSupport = 0.0;
	vector< const set<int> * > listSetTest1, listSetTest2;
	listSetTest1.push_back( &sset1 );
	listSetTest1.push_back( &sset2 );
	listSetTest2.push_back( &sset2 );
	listSetTest2.push_back( &sset1 );

	for(int ii=0; ii<(int)listSetTest1.size(); ++ii)
	{
		for( set<int> :: iterator it1 = listSetTest1[ii]->begin(); it1 != listSetTest1[ii]->end();  ++it1 )
		{
			set<int> :: iterator it2 = it1;
			it2++;
			for(; it2 != listSetTest1[ii]->end(); ++it2)
			{
				// try all the 
				for( set<int> :: iterator it3 = listSetTest2[ii]->begin(); it3 != listSetTest2[ii]->end(); ++it3)
				{
					// 
					numTotTriples ++;

					// find the support
					totSupport += GetTripleFreq(tr, *it1, *it2, *it3);
				}
			}
		}
	}
	YW_ASSERT_INFO(numTotTriples > 0, "Can not have zero triples");
	return totSupport/numTotTriples;
}


