#ifndef HEU_SPECIES_TREE_FINDER_H
#define HEU_SPECIES_TREE_FINDER_H

#include "GeneSpeciesTreeProb.h"

// Problem: given a set of binary gene trees (which assumes to be indpendent), only topology and ignore branch length
// find the species tree (binary, topology plus branch length) that maximize the product of prob. of obsering each gene
// tree on this species tree
// We perform a fast but heuristic search of a good (but not necessarily the optimum) species tree
// Idea: rely on consensus tree. That is, the species tree should share more topological
// features with as many gene trees as possible


//////////////////////////////////////////////////////////////////////////////////
// Fast but less accurate finding of species tree 

class HeuSpeciesTreeFinder
{
public:
	HeuSpeciesTreeFinder( const vector<PhylogenyTreeBasic *> &listGTreePtrs, int numGrids, double gridWidth, int numSpecies );
	~HeuSpeciesTreeFinder();

	double InferByMinInconsistency( MarginalTree &treeRes );

private:
	void ConvToTreeWithLength( PhylogenyTreeBasic *ptrTreeNoLength, MarginalTree &treeWLen );

	// private data
	//vector<PhylogenyTreeBasic *> listGTreePtrs;
	vector<PhylogenyTreeBasic *> listGTConvertPtrs;
	int numGrids;
	double gridWidth;
	int numSpecies;

};



//////////////////////////////////////////////////////////////////////////////////

typedef struct
{
	set<int> species;		// what species it has
	double weight;			// how much weight does it has?
} SUBTREE_INFO;


typedef struct
{
	int minNumLins;
	int maxNumLins;
} CLUSTER_INFO_GT;


class STSampleLineage
{
	// note we ASSUME no duplicate species set lineages
public:
	STSampleLineage();
	STSampleLineage(int numTrees, const set<int> sps);
    STSampleLineage(const STSampleLineage &rhs) {species = rhs.species; probAtLinNums = rhs.probAtLinNums; wtTot=rhs.wtTot; }
    STSampleLineage&  operator=(const STSampleLineage &rhs) {species = rhs.species; probAtLinNums = rhs.probAtLinNums; wtTot=rhs.wtTot; return *this;}

	bool operator <(const STSampleLineage &lc2) const
	{
		return species < lc2.species;
	}
    bool operator==(const STSampleLineage &rhs) const
	{
		return species == rhs.species;
	}
	void Init(int numTrees,  const set<int> &sps );
	void InitProbTbl(int tr, int minNL, int maxNL);
	void SetProbAt(int tr, int k, double prob);
	double GetProbAt(int tr, int k) const;
	void GetSpecies(set<int> &sps) const;
	void CalcTotWt();
	double GetWtForTree(int tr);
	double GetWtTotal();
	void Dump();

private:

	set<int> species;		// speices id under this lineage (at the leaves of the subtree)
	vector< vector<double> > probAtLinNums;		// prob of this lineage at different lineage number
	vector<double> wtTot;
};




class HeuSpeciesTreeSampler
{
public:
	HeuSpeciesTreeSampler( const vector<PhylogenyTreeBasic *> &listGTreePtrs );
	~HeuSpeciesTreeSampler();

	//void Sample( MarginalTree &treeRes );
	void SampleBU( MarginalTree &treeRes );

private:
	void PreSampling( );	// pre-sampling
	bool SampleSubset( const set< set<int> > &listLinsCur,  set<int> &speciesNew, set<int> &subsetSp1, set<int> &subsetSp2 );
	bool SampleSubset(set< STSampleLineage > & sspeciesToSample,  STSampleLineage &species, STSampleLineage &subsetSp1, STSampleLineage &subsetSp2 );


	// prepare
	void CollectSpeciesInfo();
	void CollectSpecies(TreeNode *pn, multiset<int> &listSpecies);
	void GetSpeciesUnder(TreeNode *pn, multiset<int> &listSpecies);
	void FindLCAClusterInGT(int tr, const set<int> &cluster, set<TreeNode *> &setNodesPar);
	void FindSpeciesInGT();
	int GetNumAllelesForSpeciesInGT(int tr, int sp);
	void InitAlleleNums();
	//void InitMinLinsNumClusters();
	void CollectTriples();

	// build map
	//void BuildCNMap();
	//void BuildCNMapFor(int tr);

	// utility
	void FindClusterInfoInGT(int tr, const set<int> &cluster, CLUSTER_INFO_GT &cig);
	//double GetCNMapProb( int tr, const set<int> & cluster, int numLins );
	//int GetCNMapNumLinsMax(int tr,const set<int> & cluster );
	//void AddCNMapProb( int tr, const set<int> &cluster, int numLins, double prob);
	double CalcCoalProb(int numSrc, int numDest);
	//void MergeLeftRightClusters( int tr, const set<int> &setRows, const set<int> &subsetRows, const set<int> &subsetRowsOther );
	//void PrepareTableAt(int tr, const set<int> & setRows );
	int GetNumAllelesForSpecies(int sp) const {YW_ASSERT_INFO(sp<(int)numAllelesSpecies.size(), "Species id bad"); return numAllelesSpecies[sp]; }
	int GetNumAllelesForSpecies(const set<int> setSps) const;
	//double GetProbWeight( const set<int> &species );
	void FormSpeciesTree(vector< pair<set<int>, pair<set<int>, set<int> > > > &listSPNodeSets, MarginalTree &mTree);
	int GetMinLinsNumAt(int tr, const set<int> &cluster);
	int GetMaxLinsNumAt(int tr, const set<int> &cluster);
	void GenCoalSTLin(const STSampleLineage &subsetSp1, const STSampleLineage &subsetSp2, STSampleLineage &subsetNew  );
	int GetNumGTrees() const { return listGTConvertPtrs.size(); }
	double CalcDefaultProb(const set<int> &species);
	double CalcDefaultProb(int tr, const set<int> &species);
	double GetTripleFreq(int tr, int a, int b, int c);
	double GetTwinFreq(int tr, int a, int b);
	double GetTripleSupport(int tr, const set<int> &sset1, const set<int> &sset2);

	// the prob of a cluster (a subset of species), and number of lineages right at the speciation event, for each tree
	vector<PhylogenyTreeBasic *> listGTConvertPtrs;
	int numSpecies;
	//vector< map< set<int>, vector<double> > > listClusterNumLinsProbPerTree;
	vector< map<set<int>, int> > listClusterMinLinsNumPerTree;
	vector< map<set<int>, int> > listClusterMaxLinsNumPerTree;
	vector< vector<int> > listSpeciesAlleleNum;
	map<TreeNode *, multiset<int> > treesNodeLabelsUnder;
	vector<int> numAllelesSpecies;
	vector< map< pair<pair<int,int>,int>, double> >  listTripleFreqPerTree;
	vector<int> listTotTriplesNum;

#if 0

	void ProcNodeAt(int tr, TreeNode *pn);
	double ProcNodeRearrange( int tr, TreeNode *pnCur, const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattach );
	// the rearrangement induces a local gene and species tree, which will determine how likely the rearrangement will be
	// caution: the rearrangement nodes should move accross the current node
	void ProcNodeRearrangeNewTrees( int tr, TreeNode *pnCur, const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattach, 
		MarginalTree &sTreeLocal, PhylogenyTree &gTreeLocal );
	bool FitSpeciesCluster(int tr, TreeNode *pnCur, const vector<pair<TreeNode* tnSrc, TreeNode *tnDest> > &listNodeReattach);
	bool FindSubtreeProb(const set<int> &species, double &probSubtree);	// return false if not found

	void ProcNodesTwoSides(int tr, const set<TreeNode *> &setOrigNodesLeft, const set<TreeNode *> &setOrigNodesRight,
		const set<TreeNode *> &setNodesLeftActive, const set<TreeNode *> &setNodesRightActive);


	// private data

	// keep track which nodes has which species (leaf labels) under it
	map<int, set<SUBTREE_INFO> > mapSubtreeInfo; 
#endif
};



#endif
