//
//  TreeTriples.cpp
//  
//
//  Created by Yufeng Wu on 11/7/15.
//
//

#include "TreeTriples.h"
#include "Utils3.h"
#include "Utils4.h"

//***********************************************************************

void TestTriples()
{
    // create some test cases
    const int NUM_SPLITS1 = 9;
    multiset<int> ssplits[NUM_SPLITS1];
    ssplits[0].insert( 1 );
    ssplits[1].insert( 1 );
    ssplits[2].insert( 1 );
    ssplits[2].insert( 1 );
    ssplits[3].insert( 2 );
    ssplits[4].insert( 2 );
    ssplits[5].insert( 2 );
    ssplits[5].insert( 2 );
    
    ssplits[6].insert( 1 );
    ssplits[6].insert( 1 );
    ssplits[6].insert( 2 );
    ssplits[6].insert( 2 );
    ssplits[7].insert( 3 );
    ssplits[8].insert( 1 );
    ssplits[8].insert( 1 );
    ssplits[8].insert( 2 );
    ssplits[8].insert( 3 );
    ssplits[8].insert( 2 );
    //ssplits[0].insert( 1 );
    //ssplits[0].insert( 1 );
    //ssplits[1].insert( 2 );
    //ssplits[1].insert( 3 );
    //ssplits[2].insert( 1 );
    //ssplits[2].insert( 1 );
    //ssplits[2].insert( 2 );
    //ssplits[2].insert( 3 );
    //ssplits[3].insert( 1 );
    //ssplits[3].insert( 1 );
    //ssplits[3].insert( 2 );
    //ssplits[3].insert( 3 );
    //ssplits[3].insert( 2 );
    map<int,int> mapMSMap1;
    CountMultiset(ssplits[8], mapMSMap1);
    
    multiset<multiset<int> > setMSs11, setMSs12, setMSs13, setMSs14;
    setMSs11.insert( ssplits[0] );
    setMSs11.insert( ssplits[1] );
    setMSs12.insert( ssplits[3] );
    setMSs12.insert( ssplits[4] );
    setMSs13.insert( ssplits[2] );
    setMSs13.insert( ssplits[5] );
    setMSs14.insert( ssplits[6] );
    setMSs14.insert( ssplits[7] );
    set<PhyloTriple> setTriplesFound;
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs11, mapMSMap1, setTriplesFound );
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs12, mapMSMap1, setTriplesFound );
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs13, mapMSMap1, setTriplesFound );
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs14, mapMSMap1, setTriplesFound );
cout << "(1) Found triples: ";
for(set<PhyloTriple> :: iterator it = setTriplesFound.begin(); it != setTriplesFound.end(); ++it)
{
it->Dump();
}
cout << endl;
    
    const int NUM_SPLITS2 = 7;
    multiset<int> ssplits2[NUM_SPLITS2];
    ssplits2[0].insert( 1 );
    ssplits2[1].insert( 1 );
    ssplits2[2].insert( 1 );
    ssplits2[2].insert( 1 );
    ssplits2[3].insert( 3 );
    ssplits2[4].insert( 4 );
    ssplits2[5].insert( 3 );
    ssplits2[5].insert( 4 );
    ssplits2[6].insert( 1 );
    ssplits2[6].insert( 1 );
    ssplits2[6].insert( 3 );
    ssplits2[6].insert( 4 );
    
    map<int,int> mapMSMap2;
    CountMultiset(ssplits2[6], mapMSMap2);
    //ssplits2[0].insert( 1 );
    //ssplits2[0].insert( 2 );
    //ssplits2[1].insert( 1 );
    //ssplits2[1].insert( 3 );
    //ssplits2[2].insert( 1 );
    //ssplits2[2].insert( 2 );
    //ssplits2[2].insert( 1 );
    //ssplits2[2].insert( 3 );
    multiset<multiset<int> > setMSs21, setMSs22, setMSs23, setMSs24;
    setMSs21.insert( ssplits2[0] );
    setMSs21.insert( ssplits2[1] );
    setMSs22.insert( ssplits2[3] );
    setMSs22.insert( ssplits2[4] );
    setMSs23.insert( ssplits2[2] );
    setMSs23.insert( ssplits2[5] );
    set<PhyloTriple> setTriplesFound2;
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs21, mapMSMap2, setTriplesFound2 );
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs22, mapMSMap2, setTriplesFound2 );
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs23, mapMSMap2, setTriplesFound2 );
    PhyloTripleUtils :: CombineTriples( setTriplesFound, setTriplesFound2 );
cout << "(2) Found triples: ";
for(set<PhyloTriple> :: iterator it = setTriplesFound2.begin(); it != setTriplesFound2.end(); ++it)
{
it->Dump();
}
cout << endl;
    
    
#if 0
    // second group of splits
    const int NUM_SPLITS3 = 4;
    multiset<int> ssplits3[NUM_SPLITS3];
    ssplits3[0].insert( 1 );
    ssplits3[0].insert( 2 );
    ssplits3[1].insert( 4 );
    ssplits3[1].insert( 4 );
    ssplits3[2].insert( 3 );
    ssplits3[2].insert( 4 );
    ssplits3[2].insert( 4 );
    ssplits3[3].insert( 1 );
    ssplits3[3].insert( 2 );
    ssplits3[3].insert( 3 );
    ssplits3[3].insert( 4 );
    ssplits3[3].insert( 4 );
    //ssplits3[0].insert( 1 );
    //ssplits3[0].insert( 3 );
    //ssplits3[1].insert( 1 );
    //ssplits3[1].insert( 3 );
    //ssplits3[1].insert( 1 );
    //ssplits3[2].insert( 1 );
    //ssplits3[2].insert( 3 );
    //ssplits3[2].insert( 1 );
    //ssplits3[2].insert( 4 );
    multiset<multiset<int> > setMSs3;
    setMSs3.insert( ssplits3[0] );
    setMSs3.insert( ssplits3[1] );
    setMSs3.insert( ssplits3[2] );
    setMSs3.insert( ssplits3[3] );
    set<PhyloTriple> setTriplesFound3;
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs3, setTriplesFound3 );
    PhyloTripleUtils :: CombineTriples( setTriplesFound, setTriplesFound3 );
cout << "(3) Found triples: ";
for(set<PhyloTriple> :: iterator it = setTriplesFound3.begin(); it != setTriplesFound3.end(); ++it)
{
it->Dump();
}
cout << endl;
    
    const int NUM_SPLITS4 = 4;
    multiset<int> ssplits4[NUM_SPLITS4];
    ssplits4[0].insert( 1 );
    ssplits4[0].insert( 2 );
    ssplits4[1].insert( 1 );
    ssplits4[1].insert( 2 );
    ssplits4[1].insert( 3 );
    ssplits4[2].insert( 4 );
    ssplits4[2].insert( 4 );
    ssplits4[3].insert( 1 );
    ssplits4[3].insert( 2 );
    ssplits4[3].insert( 3 );
    ssplits4[3].insert( 4 );
    ssplits4[3].insert( 4 );
    //ssplits4[0].insert( 1 );
    //ssplits4[0].insert( 3 );
    //ssplits4[1].insert( 1 );
    //ssplits4[1].insert( 3 );
    //ssplits4[1].insert( 1 );
    //ssplits4[2].insert( 1 );
    //ssplits4[2].insert( 4 );
    //ssplits4[3].insert( 1 );
    //ssplits4[3].insert( 3 );
    //ssplits4[3].insert( 1 );
    //ssplits4[3].insert( 4 );
    //ssplits4[3].insert( 1 );
    multiset<multiset<int> > setMSs4;
    setMSs4.insert( ssplits4[0] );
    setMSs4.insert( ssplits4[1] );
    setMSs4.insert( ssplits4[2] );
    setMSs4.insert( ssplits4[3] );
    set<PhyloTriple> setTriplesFound4;
    PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( setMSs4, setTriplesFound4 );
    PhyloTripleUtils :: CombineTriples( setTriplesFound, setTriplesFound4 );
cout << "(4) Found triples: ";
for(set<PhyloTriple> :: iterator it = setTriplesFound4.begin(); it != setTriplesFound4.end(); ++it)
{
it->Dump();
}
cout << endl;
    
#endif
    
cout << "(Combned) Found triples: ";
for(set<PhyloTriple> :: iterator it = setTriplesFound.begin(); it != setTriplesFound.end(); ++it)
{
it->Dump();
}
cout << endl;
    
    
    set<set<int> > treeClades;
    PhyloTripleUtils :: BuildTreeFromCompatTriples( setTriplesFound, treeClades );
    for( set<set<int> > :: iterator it = treeClades.begin(); it != treeClades.end(); ++it )
    {
        //
        cout << "Constructed clade: ";
        DumpIntSet(*it);
    }
    
//exit(1);
}


//***********************************************************************
// define triples


bool PhyloTriple :: operator<(const PhyloTriple &rhs) const
{
    // don't consider the value (i.e. the one w/ same value will be the same in ordering)
    if( nidSib1 < rhs.nidSib1)
    {
        return true;
    }
    else if( nidSib1 == rhs.nidSib1 )
    {
        if( nidSib2 < rhs.nidSib2 )
        {
            return true;
        }
        if( nidSib2 == rhs.nidSib2 )
        {
            if(nidOther < rhs.nidOther)
            {
                return true;
            }
        }
    }
    return false;
}

//***********************************************************************
// define triples related utillites
// **** KEY ASSUMPTION ****: the rooted clade must contain the largest possible clade: the one with
// all the leaves

void PhyloTripleUtils :: GetLabelFreqFromClades( const multiset< multiset<int> > & cladesDupLabels, map<int,int> &mapTaxonFreqs )
{
    // ASSUME: the largest clade (containing all the leaves) are always present)
    int szMax = 0;
    multiset<int> rootClade;
    for( multiset<multiset<int> > :: iterator it1 = cladesDupLabels.begin(); it1 != cladesDupLabels.end(); ++it1)
    {
        //
        if( (int)it1->size() > szMax )
        {
            szMax = it1->size();
            rootClade = *it1;
        }
    }
    for(multiset<int> :: const_iterator it2 = rootClade.begin(); it2 != rootClade.end(); ++it2)
    {
        if( mapTaxonFreqs.find( *it2) == mapTaxonFreqs.end() )
        {
            mapTaxonFreqs.insert( map<int,int> :: value_type(*it2, 0) );
        }
        ++mapTaxonFreqs[*it2];
    }

    // find the smallest clades that are not contained by other clades
    //for( set<multiset<int> > :: iterator it1 = cladesDupLabels.begin(); it1 != cladesDupLabels.end(); ++it1)
    //{
    //    for(multiset<int> :: const_iterator it2 = it1->begin(); it2 != it1->end(); ++it2)
    //    {
    //        if( mapTaxonFreqs.find( *it2) == mapTaxonFreqs.end() )
    //        {
    //            mapTaxonFreqs.insert( map<int,int> :: value_type(*it2, 0) );
    //        }
    //        ++mapTaxonFreqs[*it2];
    //    }
    //}
}

void PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels(  const multiset< multiset<int> > & cladesDupLabels, const map<int,int> &mapTaxonFreqs, set<PhyloTriple> &setTriplesFound )
{
    // cladesDupLabels: a list of clades under the SAME internal nodes
    // mapTaxonFreqs: frequency of taxon within the overall tree
    //setTriplesFound.clear();
    //map<int,int> mapTaxonFreqs;
    //GetLabelFreqFromClades( cladesDupLabels, mapTaxonFreqs );
    
    // add the single taxon
    //multiset< multiset<int> > cladesDupLabelsUse = cladesDupLabels;
    //for( map<int,int> :: iterator it = mapTaxonFreqs.begin(); it != mapTaxonFreqs.end(); ++it)
    //{
    //    for(int i=0; i<(int) it->second; ++i )
    //    {
    //        multiset<int> ss;
    //        ss.insert(it->first);
    //        cladesDupLabelsUse.insert(ss);
    //    }
    //}
    
    // create clusters of the clades
    //map<multiset<int>, vector<  multiset<int> > >  mapMultisetClusters;
    //CreateClustersFromMultisets( cladesDupLabelsUse, mapMultisetClusters );
    
//cout << "created clsuters: \n";
//for( map<multiset<int>, vector<  multiset<int> > >  :: iterator it = mapMultisetClusters.begin(); it != mapMultisetClusters.end(); ++it)
//{
//cout << "**** ";
//DumpIntMultiset( it->first  );
//for(int i=0; i<(int)it->second.size(); ++i)
//{
//DumpIntMultiset(it->second[i]);
//}
//}
    // create triples from two sibling clades only
    YW_ASSERT_INFO(cladesDupLabels.size() >= 2, "Internal clades must have at least two children");
    for( multiset< multiset<int> > :: const_iterator it1 = cladesDupLabels.begin(); it1 != cladesDupLabels.end(); ++it1 )
    {
        map<int,int> mapCladeOneSideFreq1;
        GetSplitOneSie( *it1, mapCladeOneSideFreq1  );
        
        multiset< multiset<int> > :: const_iterator it2 = it1;
        ++it2;
        
        //YW_ASSERT_INFO(it1->second.size() >= 2, "Internal clades must have at least two children");
        for(; it2 != cladesDupLabels.end(); ++it2  )
        {
            //
            map<int,int> mapCladeOneSideFreq2;
            GetSplitOneSie( *it2, mapCladeOneSideFreq2  );
            
            set<PhyloTriple> setTriplesNew;
            GetAllTriplesTwoSides( mapCladeOneSideFreq1, mapCladeOneSideFreq2, mapTaxonFreqs, setTriplesNew );
            
            // combine the results
            CombineTriples( setTriplesFound, setTriplesNew );
        }
    }
    
  
#if 0
    // consider each clade and
    for( set< multiset<int> > :: iterator it= cladesDupLabels.begin(); it!=cladesDupLabels.end(); ++it  )
    {
        map<int,int> mapCladeOneSideFreq;
        GetSplitOneSie( *it, mapCladeOneSideFreq );
        set<PhyloTriple> setTriplesNew;
        GetAllTriples( mapCladeOneSideFreq, mapTaxonFreqs, setTriplesNew );
        
        // combine the results
        CombineTriples( setTriplesFound, setTriplesNew );
        //for( set<PhyloTriple> :: iterator it2 = setTriplesNew.begin(); it2 != setTriplesNew.end(); ++it2)
        //{
        //    // is this new
        //    if( setTriplesFound.find(*it2) == setTriplesFound.end() )
        //    {
        //        setTriplesFound.insert(*it2);
        //    }
        //    else
        //    {
        //        // combine
        //        PhyloTriple triExist = *( setTriplesFound.find(*it2) );
        //        triExist.Append( *it2 );
        //        setTriplesFound.erase(*it2);
        //        setTriplesFound.insert(triExist);
        //    }
        //}
    }
#endif
}


void PhyloTripleUtils :: CombineTriples( set<PhyloTriple > &setTriplesAddedRes, const set<PhyloTriple> &setTriplesAddeding )
{
    //
    // combine the results
    for( set<PhyloTriple> :: const_iterator it2 = setTriplesAddeding.begin(); it2 != setTriplesAddeding.end(); ++it2)
    {
        // is this new
        if( setTriplesAddedRes.find(*it2) == setTriplesAddedRes.end() )
        {
            setTriplesAddedRes.insert(*it2);
        }
        else
        {
            // combine
            PhyloTriple triExist = *( setTriplesAddedRes.find(*it2) );
            triExist.Append( *it2 );
            setTriplesAddedRes.erase(*it2);
            setTriplesAddedRes.insert(triExist);
        }
    }

}



void PhyloTripleUtils :: BuildTreeFromCompatTriples( const set<PhyloTriple> &setTriplesAll, set< set<int> > &treeClades)
{
//cout << "BuildTreeFromCompatTriples: treeClades: \n";
//for(set<set<int> > :: iterator it = treeClades.begin(); it != treeClades.end(); ++it)
//{
//DumpIntSet( *it );
//}
    
    // approach: recurisvely merging siblings of two taxa that receive
    // the most support of being a sibling
    // first collect taxa
    set<int> setTaxa;
    for(set<PhyloTriple> :: const_iterator it = setTriplesAll.begin(); it != setTriplesAll.end(); ++it)
    {
        //
        setTaxa.insert( it->GetSib1() );
        setTaxa.insert( it->GetSib2() );
        setTaxa.insert( it->GetOther() );
    }
        
    
    set<set<int> > setSubsetTaxaToProc;
    // init to be individual taxa themselves
    for(set<int> :: iterator it = setTaxa.begin(); it != setTaxa.end(); ++it)
    {
        set<int> ss;
        ss.insert(*it);
        setSubsetTaxaToProc.insert(ss);
    }
    
    // repeat until all taxa are merged
    while( setSubsetTaxaToProc.size() > 1 )
    {
//cout << "setSubsetTaxaToProc: ";
//for( set<set<int> > :: iterator it = setSubsetTaxaToProc.begin(); it != setSubsetTaxaToProc.end(); ++it)
//{
//DumpIntSet(*it);
//}
        
        // find two best taxon groups
        set<int> taxonG1, taxonG2;
        FindBestSiblings( setTriplesAll, setSubsetTaxaToProc, taxonG1, taxonG2 );
        YW_ASSERT_INFO( taxonG1.size() > 0 && taxonG2.size() > 0, "Wrong here");
        
        //
        set<set<int> > setSubsetTaxaToProcNew = setSubsetTaxaToProc;
        setSubsetTaxaToProcNew.erase( taxonG1 );
        setSubsetTaxaToProcNew.erase( taxonG2 );
        UnionSets( taxonG1, taxonG2 );
        setSubsetTaxaToProcNew.insert(taxonG1);
        treeClades.insert(taxonG1);
        setSubsetTaxaToProc = setSubsetTaxaToProcNew;
    }
    // add in the overall clade
    treeClades.insert( setTaxa );
}

void PhyloTripleUtils :: GetSplitOneSie( const multiset<int> &clade, map<int,int> &mapCladeOneSideFreq )
{
    //
    mapCladeOneSideFreq.clear();
    for(multiset<int> :: iterator it = clade.begin(); it != clade.end(); ++it)
    {
        if( mapCladeOneSideFreq.find(*it) == mapCladeOneSideFreq.end() )
        {
            mapCladeOneSideFreq.insert( map<int,int> :: value_type(*it, 0) );
        }
        ++mapCladeOneSideFreq[*it];
    }
}

void PhyloTripleUtils :: GetTaxonFromSplit(const map<int,int> &mapClade, set<int> &setTaxon)
{
    //
    setTaxon.clear();
    for(map<int,int> :: const_iterator it = mapClade.begin(); it != mapClade.end(); ++it)
    {
        setTaxon.insert(it->first);
    }
}

void PhyloTripleUtils :: GetAllTriples( const map<int,int> &mapCladeOneSideFreq, const map<int,int> &mapTaxonFreqs, set<PhyloTriple> &setTripleClade )
{
#if 0
cout << "GetAllTriples: mapCladeOneSideFreq: ";
for(map<int,int> :: const_iterator it = mapCladeOneSideFreq.begin(); it != mapCladeOneSideFreq.end(); ++it)
{
cout << "<" << it->first << "," << it->second << ">   ";
}
cout << endl;
cout << "mapTaxonFreqs: ";
for(map<int,int> :: const_iterator it = mapTaxonFreqs.begin(); it != mapTaxonFreqs.end(); ++it)
{
cout << "<" << it->first << "," << it->second << ">   ";
}
cout << endl;
#endif
    
    // collect all triples from the clade taxon info
    set<int> taxonOneSide, taxonAll;
    GetTaxonFromSplit(mapCladeOneSideFreq, taxonOneSide);
    GetTaxonFromSplit(mapTaxonFreqs, taxonAll);
#if 0
cout << "TaxonOneSide: ";
DumpIntSet(taxonOneSide);
cout << "taxonAll: ";
DumpIntSet(taxonAll);
#endif
    
    // a triple should have two coming from one side and one more coming from
    // the other side
    for(set<int> :: iterator it1 = taxonOneSide.begin(); it1 != taxonOneSide.end(); ++it1)
    {
        set<int> :: iterator it2 = it1;
        ++it2;
        for(; it2 != taxonOneSide.end(); ++it2)
        {
            // consider all taxon on the other side
            for( set<int> :: iterator it3 = taxonAll.begin(); it3 != taxonAll.end(); ++it3 )
            {
                //
                if( *it3 != *it1 && *it3 != *it2)
                {
                    YW_ASSERT_INFO( mapTaxonFreqs.find(*it3) != mapTaxonFreqs.end(), "Wrong1" );
                    // this taxon on the other side must have some appearance outside the current split
                    if( mapCladeOneSideFreq.find(*it3) != mapCladeOneSideFreq.end() && mapCladeOneSideFreq.find(*it3)->second == mapTaxonFreqs.find(*it3)->second )
                    {
                        continue;
                    }
                    
                    // this is a valid triple
                    double valTrip = EvalTriple(*it1, *it2, *it3, mapCladeOneSideFreq, mapTaxonFreqs);
                    PhyloTriple tri(*it1,*it2, *it3, valTrip);
                    setTripleClade.insert(tri);
                }
            }
        }
    }
}

void PhyloTripleUtils :: GetAllTriplesTwoSides( const map<int,int> &mapCladeOneSideFreq1, const map<int,int> &mapCladeOneSideFreq2, const map<int,int> &mapTaxonFreqs, set<PhyloTriple> &setTripleClade )
{
    // different from above, get triples s.t. one is from clade1 and another is from clade 2
    // collect all triples from the clade taxon info
    set<int> taxonOneSide, taxonTwoSide, taxonAll;
    GetTaxonFromSplit(mapCladeOneSideFreq1, taxonOneSide);
    GetTaxonFromSplit(mapCladeOneSideFreq2, taxonTwoSide);
    GetTaxonFromSplit(mapTaxonFreqs, taxonAll);
#if 0
cout << "TaxonOneSide: ";
DumpIntSet(taxonOneSide);
cout << "TaxonTwoSide: ";
DumpIntSet(taxonTwoSide);
cout << "taxonAll: ";
DumpIntSet(taxonAll);
#endif
    
    // a triple should have two coming from one side and one more coming from
    // the other side
    for(set<int> :: iterator it1 = taxonOneSide.begin(); it1 != taxonOneSide.end(); ++it1)
    {
        for( set<int> :: iterator it2 = taxonTwoSide.begin(); it2 != taxonTwoSide.end(); ++it2 )
        {
            if( *it1 == *it2 )
            {
                continue;
            }
            // consider all taxon on the other side
            for( set<int> :: iterator it3 = taxonAll.begin(); it3 != taxonAll.end(); ++it3 )
            {
                //
                if( *it3 != *it1 && *it3 != *it2)
                {
                    YW_ASSERT_INFO( mapTaxonFreqs.find(*it3) != mapTaxonFreqs.end(), "Wrong2" );
                    // this taxon on the other side must have some appearance outside the current split
                    //if( mapCladeOneSideFreq.find(*it3) != mapCladeOneSideFreq.end() && mapCladeOneSideFreq.find(*it3)->second == mapTaxonFreqs.find(*it3)->second )
                    //{
                    //    continue;
                    //}
                    
                    // this is a valid triple
                    double valTrip = EvalTriple2(*it1, *it2, *it3, mapCladeOneSideFreq1, mapCladeOneSideFreq2, mapTaxonFreqs);
                    if( valTrip > 0.0 )
                    {
                        PhyloTriple tri(*it1,*it2, *it3, valTrip);
                        setTripleClade.insert(tri);
                    }
                }
            }
        }
    }

}

double PhyloTripleUtils :: EvalTriple(int sid1, int sid2, int sother, const map<int,int> &mapCladeOneSideFreq, const map<int,int> &mapTaxonFreqs )
{
    // score = %id1*%id2 (one side)*%id3 (the other side)
    double res = 1.0;
    YW_ASSERT_INFO(mapTaxonFreqs.find(sid1) != mapTaxonFreqs.end(), "Wrong3");
    YW_ASSERT_INFO(mapTaxonFreqs.find(sid2) != mapTaxonFreqs.end(), "Wrong4");
    YW_ASSERT_INFO(mapTaxonFreqs.find(sother) != mapTaxonFreqs.end(), "Wrong5");
    YW_ASSERT_INFO(mapCladeOneSideFreq.find(sid1) != mapCladeOneSideFreq.end(), "Wrong6");
    YW_ASSERT_INFO(mapCladeOneSideFreq.find(sid2) != mapCladeOneSideFreq.end(), "Wrong7");
    int n1Tot = mapTaxonFreqs.find(sid1)->second;
    int n2Tot = mapTaxonFreqs.find(sid2)->second;
    int n3Tot = mapTaxonFreqs.find(sother)->second;
    int n1Side1 = mapCladeOneSideFreq.find(sid1)->second;
    int n2Side1 = mapCladeOneSideFreq.find(sid2)->second;
    int n3Side1 = 0;
    if( mapCladeOneSideFreq.find(sother) != mapCladeOneSideFreq.end() )
    {
        n3Side1 = mapCladeOneSideFreq.find(sother)->second;
    }
    res = ((1.0*n1Side1)/n1Tot)*((1.0*n2Side1)/n2Tot)*((1.0*( n3Tot - n3Side1))/n3Tot);
//cout << "n1Tot = " << n1Tot << ", n2Tot = " << n2Tot << ", n3Tot: " << n3Tot << ", n1Side1: " << n1Side1 << ", n2Side1 = " << n2Side1 << ", n3Side1 = " << n3Side1 << endl;
//cout << "sid1 = " << sid1 << ", sid2 = " << sid2 << ", sother = " << sother << ": score = " << res << endl;
    return res;
}

double PhyloTripleUtils :: EvalTriple2(int sid1, int sid2, int sother, const map<int,int> &mapCladeOneSideFreq1, const map<int,int> &mapCladeOneSideFreq2, const map<int,int> &mapTaxonFreqs )
{
    // score = %id1*%id2 (one side)*%id3 (the other side)
    double res = 1.0;
    YW_ASSERT_INFO(mapTaxonFreqs.find(sid1) != mapTaxonFreqs.end(), "Wrong8");
    YW_ASSERT_INFO(mapTaxonFreqs.find(sid2) != mapTaxonFreqs.end(), "Wrong9");
    YW_ASSERT_INFO(mapTaxonFreqs.find(sother) != mapTaxonFreqs.end(), "Wrong10");
    YW_ASSERT_INFO(mapCladeOneSideFreq1.find(sid1) != mapCladeOneSideFreq1.end(), "Wrong11");
    YW_ASSERT_INFO(mapCladeOneSideFreq2.find(sid2) != mapCladeOneSideFreq2.end(), "Wrong12");
    int n1Tot = mapTaxonFreqs.find(sid1)->second;
    int n2Tot = mapTaxonFreqs.find(sid2)->second;
    int n3Tot = mapTaxonFreqs.find(sother)->second;
    int n1Side1 = mapCladeOneSideFreq1.find(sid1)->second;
    int n2Side1 = mapCladeOneSideFreq2.find(sid2)->second;
    int n3Side1 = 0;
    if( mapCladeOneSideFreq1.find(sother) != mapCladeOneSideFreq1.end() )
    {
        n3Side1 += mapCladeOneSideFreq1.find(sother)->second;
    }
    if( mapCladeOneSideFreq2.find(sother) != mapCladeOneSideFreq2.end() )
    {
        n3Side1 += mapCladeOneSideFreq2.find(sother)->second;
    }
    res = ((1.0*n1Side1)/n1Tot)*((1.0*n2Side1)/n2Tot)*((1.0*( n3Tot - n3Side1))/n3Tot);
//cout << "n1Tot = " << n1Tot << ", n2Tot = " << n2Tot << ", n3Tot: " << n3Tot << ", n1Side1: " << n1Side1 << ", n2Side1 = " << n2Side1 << ", n3Side1 = " << n3Side1 << endl;
//cout << "sid1 = " << sid1 << ", sid2 = " << sid2 << ", sother = " << sother << ": score = " << res << endl;
    return res;

}

void PhyloTripleUtils :: FindBestSiblings(const set<PhyloTriple> &setTriplesAll, const set<set<int> > &setTaxaGroups, set<int> &taxonG1, set<int> &taxonG2)
{
#if 0
cout << "FindBestSiblings: list of groups: ";
for( set<set<int> >:: const_iterator it= setTaxaGroups.begin(); it != setTaxaGroups.end(); ++it )
{
DumpIntSet(*it);
}
#endif
    // if there is only two groups
    YW_ASSERT_INFO(setTaxaGroups.size() >=2, "FindBestSiblings: must have at least two groups");
    if( setTaxaGroups.size() == 2 )
    {
        taxonG1 = *(setTaxaGroups.begin());
        taxonG2 = *(setTaxaGroups.rbegin());
        return;
    }
    
    if(setTriplesAll.size() == 0 )
    {
        YW_ASSERT_INFO(false, "Nothing to process");
    }
#if 0
cout << "FindBestSiblings: set of all triples given: ";
for( set<PhyloTriple>::const_iterator it=setTriplesAll.begin(); it != setTriplesAll.end(); ++it )
{
//
it->Dump();
}
cout << endl;
#endif
    // find where does each taxon is located in which group
    map<int, const set<int> * > mapTaxonToGroupPtr;
    for( set<set<int> > :: const_iterator it = setTaxaGroups.begin(); it != setTaxaGroups.end(); ++it )
    {
        for(set<int> :: const_iterator it2 = it->begin(); it2 != it->end(); ++it2)
        {
            mapTaxonToGroupPtr.insert( map<int, const set<int> * > :: value_type(*it2, &( *it )) );
        }
    }
    
    
    // find the two sibliings that best fit the current set of pairs
    map<pair<set<int>,set<int> >,  double > mapPairTaxonScore;
    for( set<PhyloTriple> :: const_iterator it = setTriplesAll.begin(); it != setTriplesAll.end(); ++it)
    {
        // the two sibling should not be in the same group
        YW_ASSERT_INFO(mapTaxonToGroupPtr.find(it->GetSib1() ) != mapTaxonToGroupPtr.end(), "Fail to find");
        YW_ASSERT_INFO(mapTaxonToGroupPtr.find(it->GetSib2() ) != mapTaxonToGroupPtr.end(), "Fail to find");
        if( mapTaxonToGroupPtr[it->GetSib1()] == mapTaxonToGroupPtr[ it->GetSib2() ] )
        {
            //
            continue;
        }
        
        //
        set<int> ss1 = *mapTaxonToGroupPtr[ it->GetSib1()];
        set<int> ss2 = *mapTaxonToGroupPtr[ it->GetSib2()];
        if( (ss1 < ss2) == false )
        {
            ss1 = *mapTaxonToGroupPtr[ it->GetSib2()];
            ss2 = *mapTaxonToGroupPtr[ it->GetSib1()];
        }
        pair<set<int>,set<int> > pp( ss1, ss2 );
        if( mapPairTaxonScore.find(pp) == mapPairTaxonScore.end() )
        {
            mapPairTaxonScore.insert( map<pair<set<int>,set<int> >,  double > :: value_type(pp, 0.0) );
        }
        mapPairTaxonScore[pp] += it->GetConfidence();
    }
    
    // now get the one with the largest weight
    const double scoreInit = -HAP_MAX_INT*1.0;
    double scoreMax = scoreInit;
    pair<set<int>,set<int> > ppMax;
    bool fFound = false;
    for( map<pair<set<int>,set<int> >,  double > :: iterator it = mapPairTaxonScore.begin(); it != mapPairTaxonScore.end(); ++it )
    {
        if( it->second > scoreMax)
        {
            scoreMax = it->second;
            ppMax = it->first;
            fFound =true;
        }
    }
    
    // assign the results
    if(fFound)
    {
        taxonG1 = ppMax.first;
        taxonG2 = ppMax.second;
    }
    else
    {
        // if nothing is found, simply take the first and last groups (random choice)
        taxonG1 = *(setTaxaGroups.begin());
        taxonG2 = *(setTaxaGroups.rbegin());
    }
}

