//
//  TreeBuilder.h
//  
//
//  Created by Yufeng Wu on 9/11/15.
//
//

#ifndef ____TreeBuilder__
#define ____TreeBuilder__

#include <iostream>
#include <map>
#include <set>
#include <string>
using namespace std;

//***********************************************************************
void TestNJ();

//***********************************************************************
// implement various methods to build a phylogenetic tree

// define distances between taxa
class PhyloDistance
{
public:
    void SetDistance(int node1, int node2, double dist);
    double GetDistance(int node1, int node2) const;
    void GetAllNodes( set<int> &nodesAll) const;
    double GetDistanceNonNeg( int node1, int node2 ) const;
    void Dump() const;
    
private:
    map< pair<int,int>, double> mapDists;
};

// distance based tree builder
class DistanceTreeBuilder
{
public:
    DistanceTreeBuilder(PhyloDistance &distPairwiseTaxaIn);
    string NJ();
    
private:
    void NJFindNgbrs( int nodeIdNew, set<int> &nodesToSearch, int &ngbr1, int &ngbr2 );
    double NJCalcAveDist(int nodecur, const set<int> &nodesToSearch);
    
    PhyloDistance &distPairwiseTaxa;
};



#endif /* defined(____TreeBuilder__) */
