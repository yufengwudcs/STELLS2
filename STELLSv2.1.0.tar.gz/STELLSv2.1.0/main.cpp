#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <map>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

using namespace std;

#include "Utils2.h"
#include "MarginalTree.h"
#include "UnWeightedGraph.h"
#include "GeneSpeciesTreeProb.h"
#include "PhylogenyTreeBasic.h"
#include "OptSpeciesTreeFinder.h"
#include "STBranchLenFinder.h"
//#include "HeuSpeciesTreeFinder.h"
#include "DeepCoalescence.h"
#include "SpeciesTreeExplorer.h"
#include "FastGeneTreeProb.h"
#include "FixedSTGeneTreeProb.h"
#include "TreeBuilder.h"
#include "TreeInfSubsets.h"
#include "TreeTriples.h"
#include "Utils4.h"
//#include "GSTProbWithLookup.h"
#include "FastSpeciesTreeBuilder.h"
#include "ApproxGeneTreeProb.h"

//*****************************************************************************
// Main driving functions
// ***************************************************************************


// ***************************************************************************
// Main for computing lower bound
// ***************************************************************************
static void Usage()
{
	cout << "Usage: ./stells  <OPTIONS> -g <GeneTreeFile.newick> " << endl;
	exit(1);
}

const double DEF_MIN_BRANCH_LEN = 0.005;
const double DEF_MAX_BRANCH_LEN = 5.0;
const double DEF_MAX_BRANCH_LEN_THRES = 1.0;


// Parameters
static char *fileNameSpecies = NULL;
//static char *fileNameGene = NULL;
static char *fileNameGeneTrees = NULL;
static char *fileNameSeedTrees = NULL;
static bool fTestMode = false;
static bool fBranchLenMode = false;
static int numTreeSamples = 50;
static int numMDCLevels = 5;
static bool fMDCRangeSearch = false;
//static bool fTreeSampling = false;
static bool fOptSearch = false;
static double minBranchLenHillClimb = DEF_MIN_BRANCH_LEN;
static double maxBranchLenHillClimb = DEF_MAX_BRANCH_LEN;
double minRatioHillClimb = -1.0;
static string fileNameTreeProbOut = "treeprobs.out";
static bool fMDCMoreClades = true;
static int maxNumMDCMoreClades = -1;
static bool fExploreNgbrTrees = true;
static bool fBrentMode = true;		// whether to run Brent's mode
static int numNearOptTreesKept = 10;	// how many near optimal trees to keep
static bool fVerbose = false;
static bool fGeneTreeProbOnly = true;	// by default, search for opt branch length when a species tree is given
static bool fFastCoal = false;          // by default, using original algorithm to calc gene tree prob
static int numThreadsToUse = 1;         // how many threads 
static bool fPairwiseMode = false;      // use pairwise distance to infer trees
static bool fDiffTaxaInGTrees = false;  // do gene trees contain different sets of taxa? this may be useful when one want to infer trees from gene trees that have only a subset of all taxa
static int szSubsetTaxa = -1;
static int szMaxSubtreeIdent = -1;
static int szMaxSubtreeSz = -1;
static bool fFastStells = false;
static int fastStellsMaxSubSTSize = -1;
static int fastStellsMaxSubGTSize = -1;
static int fastStellsMaxNumIter = -1;
static int fastStellsSzConsensusPanel = -1;
//static int maxIterationFastSTELLS = 10;
static bool fApproxLikeli = true;

// GLobal variables



// Local functions
static bool CheckArguments(int argc, char **argv) 
{
    if( argc == 1  )
    {
        return false;
    }

    // Check argument one by one
    int argpos = 1;
    while( argpos < argc)
    {
        // 
        if( argv[ argpos ][ 0 ] != '-' )
        {
            // must have this
            return false;
        }
        
        if( argv[argpos][1] == 's' )
        {
            // setup filename
            argpos ++;
            fileNameSpecies = argv[argpos];
            argpos++;
//cout << "Species tree name: " << fileNameSpecies << endl;
        }
        else if( argv[argpos][1] == 'c' )
        {
            // setup filename
            argpos ++;
			int maxNumKeptCfgs;
			sscanf(argv[argpos], "%d", &maxNumKeptCfgs );
			SetMaxLineageCfgKept(maxNumKeptCfgs);
			//
            argpos++;
//cout << "Set maximum number of kept configurations: " << maxNumKeptCfgs << endl;
        }
        else if( argv[argpos][1] == 'C' )
        {
            // setup filename
			cout << "Turn on composite likelihood mode.\n";
            SetCompositeProb(true);
			//
            argpos++;
            //cout << "Set maximum n
        }
        else if( argv[argpos][1] == 'z' )
        {
            // setup filename
            int sl = strlen(argv[argpos]);
            YW_ASSERT_INFO(sl >=2, "Wrong argument");
            if( sl == 2 )
            {
                argpos ++;
                sscanf(argv[argpos], "%d", &szSubsetTaxa );
                YW_ASSERT_INFO(szSubsetTaxa >=2, "Size of subset of taxa: must have be at least two");
                SetSubsetTaxaSize( szSubsetTaxa );
            }
            else
            {
                //
                YW_ASSERT_INFO(argv[argpos][2] == 'z', "Wrong arguments.");
                argpos ++;
                sscanf(argv[argpos], "%d", &szMaxSubtreeIdent );
                YW_ASSERT_INFO(szMaxSubtreeIdent >=1, "Max size of identical subtrees: must have be at least one");
                argpos ++;
                sscanf(argv[argpos], "%d", &szMaxSubtreeSz );
                YW_ASSERT_INFO(szMaxSubtreeSz >=2, "Size of subset of taxa: must have be at least two");
                YW_ASSERT_INFO( szMaxSubtreeSz >= szMaxSubtreeIdent, "-z option: the first number must be no bigger than the second number");
            }
            argpos++;
            //cout << "Set maximum number of kept configurations: " << maxNumKeptCfgs << endl;
        }
        else if( argv[argpos][1] == 'a' )
        {
            // setup filename
            argpos ++;
			int maxNumKeptCfgs1;
			sscanf(argv[argpos], "%d", &maxNumKeptCfgs1 );
			SetMaxLineageAncesCfgKept(maxNumKeptCfgs1);
            ApproxLineageConfigSore :: SetMaxLinCfgNum(maxNumKeptCfgs1);
			//
            argpos++;
//cout << "Set maximum number of kept configurations: " << maxNumKeptCfgs << endl;
        }
        else if( argv[argpos][1] == 'e' )
        {
            // 05/04/16, disable for now, does not quite work
            //YW_ASSERT_INFO(false, "The -e option is disabled for now. This option may be supported again in future releases.");
            SpeciesTreeExplorer :: SetFastNgbrSearch(true);
			//
            argpos++;
            cout << "Enable fast tree topology search." << endl;
        }
        else if( argv[argpos][1] == 'A' )
        {
            // YW: TESTING ONLY...
            cout << "Turn on Approximate likelihood mode" << endl;
            //SetApproxLikelihood( true );
            fApproxLikeli = true;
            argpos++;
        }
        else if( argv[argpos][1] == 'O' )
        {
            // YW: TESTING ONLY...
            cout << "Turn on the original STELLS: compute exact gene tree probability" << endl;
            //SetApproxLikelihood( true );
            fApproxLikeli = false;
            argpos++;
        }
        else if( argv[argpos][1] == 'x' )
        {
            // setup filename
            argpos ++;

			sscanf(argv[argpos], "%d", &maxNumMDCMoreClades);
            argpos++;
			//fMDCMoreClades = false;
//cout << "Limit number of additional clades in MDC to " << maxNumMDCMoreClades << endl;
        }
		else if( argv[argpos][1] == 'h')
		{
			YW_ASSERT_INFO( strlen(argv[argpos]) >= 3, "ERROR: must use either -bm or -bM" );
			if( argv[argpos][2] == 'm'  )
			{
				argpos ++;
				float ftmp;
				sscanf(argv[argpos], "%f", &ftmp );
				minBranchLenHillClimb = ftmp;
				cout << "Set minimum species tree branch length for searching " << minBranchLenHillClimb << endl;
				argpos++;
			}
			else if( argv[argpos][2] == 'M'  )
			{
				argpos ++;
				float ftmp;
				sscanf(argv[argpos], "%f", &ftmp );
                if( ftmp < DEF_MAX_BRANCH_LEN_THRES )
                {
                    cout << "Note: max branch length cannot be set to be too small.\n";
                    maxBranchLenHillClimb = DEF_MAX_BRANCH_LEN_THRES;
                }
                else
                {
                    maxBranchLenHillClimb = ftmp;
                }
				cout << "Set maximum species tree branch length for searching " << maxBranchLenHillClimb << endl;
				argpos++;
			}
			else if( argv[argpos][2] == 't'  )
			{
				argpos ++;
				float ftmp;
				sscanf(argv[argpos], "%f", &ftmp );
				minRatioHillClimb = ftmp;
				cout << "Set hill climbing threshold for searching " << minRatioHillClimb << endl;
				argpos++;
			}
		}
		else  if( argv[argpos][1] == 'g' )
        {
            // setup filename
            argpos ++;
            fileNameGeneTrees = argv[argpos];
            argpos++;
//cout << "Gene tree name: " << fileNameGeneTrees << endl;
        }
		else  if( argv[argpos][1] == 't' )
		{
			//cout << "Turn on test mode\n";
			//fTestMode = true;
            argpos ++;
            sscanf( argv[argpos], "%d", &numThreadsToUse );
			YW_ASSERT_INFO(numThreadsToUse >=2, "Must use at least two threads");
			cout << "Set the number of threads to  " << numThreadsToUse << endl;
            SetNumThreads(numThreadsToUse);
            argpos ++;
		}
		else if( argv[argpos][1] ==  'T')
		{
			YW_ASSERT_INFO( strlen(argv[argpos]) >= 3 || argv[argpos][2] != 'S', "ERROR: must use -TS" );
			cout << "Reminder: TS flag only works with tree local search mode.\n";
			cout << "It has no effect for MDC only mode or when a species tree is given\n";
            argpos ++;
			fileNameSeedTrees = argv[argpos];
            argpos ++;
		}

#if 0
		else  if( argv[argpos][1] == 'B' )
		{
			// the B option is for finding a given species tree topology
			// what is the best species tree branch lengths for the given trees
			// followed by -B (using a hill climbing approach)
			// Caution: -B and -G can not be used together
			cout << "Estimating the optimal branch length for the given set of trees\n";
            //argpos ++;
            //fileNameGeneTrees = argv[argpos];
            argpos++;
			fBranchLenMode = true;
		}
		//else  if( argv[argpos][1] == 'b' )
		//{
		//	// the b option is reduce the search space by limiting the number of kept config at each node
        //    argpos++;
		//	int numMaxNum = 1;
		//	sscanf( argv[argpos], "%d", &numMaxNum );
		//	YW_ASSERT_INFO(numMaxNum >=1, "Must keep at least one cfg at each node");
		//	cout << "Set the maximum number of kept configurations at each search node to be: " << numMaxNum << endl;
		//	SetMaxKeptCfgsLimit(numMaxNum);
        //  //argpos ++;
        //   //fileNameGeneTrees = argv[argpos];
        //   argpos++;
		//	fBranchLenMode = true;
		//}
#endif
		else if( argv[argpos][1] == 'd' )
		{
			// the b option is reduce the search space by limiting the number of kept config at each node
            argpos++;
			sscanf( argv[argpos], "%d", &numMDCLevels );
			YW_ASSERT_INFO(numMDCLevels >=1, "Must keep at least one cfg at each node");
			cout << "Set the near MDC optimal level to  " << numMDCLevels << endl;
            //argpos ++;
            //fileNameGeneTrees = argv[argpos];
            argpos++;
		}
		else if( argv[argpos][1] == 'n'  )
		{
			argpos ++;
			sscanf(argv[argpos], "%d", &numTreeSamples );
			cout << "Number of species tree topologies to evaluate: " << numTreeSamples << endl;
			argpos++;
		}
		else if( argv[argpos][1] == 'S'  )
		{
			fExploreNgbrTrees = false;
			cout << "Turn off tree space neighbourhood search (and evaluate only MDC trees, which can be faster)" << endl;
			argpos++;
		}
		else if( argv[argpos][1] == 'b' )
		{
			fBrentMode = false;
			cout << "Turn off Brent tree branch length search and this usually speedup the computation." << endl;
			argpos++;
		}
		else if( argv[argpos][1] == 'N' )
		{
			argpos++;
			sscanf( argv[argpos], "%d", &numNearOptTreesKept );
			YW_ASSERT_INFO(numNearOptTreesKept >=1, "Must keep at least one cfg at each node");
			cout << "CAUTION: this option only works with the MLE tree search mode\n";
			cout << "Set the number of near optimal trees to keep to " << numNearOptTreesKept << endl;
            //argpos ++;
            //fileNameGeneTrees = argv[argpos];
            argpos++;
		}
		else if( argv[argpos][1] == 'v' )
		{
			argpos++;
			cout << "Turn on verbose mode.\n";
			fVerbose = true;
			SetVerbose(fVerbose);
            AGTPSetVerbose(fVerbose);
		}
        else if( argv[argpos][1] == 'V' )
		{
			argpos++;
            int maxNumConvolvePairs = 1;
            sscanf( argv[argpos], "%d", &maxNumConvolvePairs );
            ++argpos;
			cout << "Set maximum direct convolution pairs to: " << maxNumConvolvePairs << endl;
            ApproxGeneTreeProbHelper :: SetMaxConvolvePairsDirect( maxNumConvolvePairs );
		}
		else if( argv[argpos][1] == 'B' )
		{
			argpos++;
			cout << "Turn off optimal branch length search mode.\n";
			fGeneTreeProbOnly = false;
		}
		else if( argv[argpos][1] == 'f' )
		{
			argpos++;
			cout << "Turn on fixed species coalescent computation mode.\n";
			fFastCoal = true;
            SetFixedCoalCalcMode(true);
		}
        else if( argv[argpos][1] == 'F' )
		{
			argpos++;
			cout << "Run fastSTELLS...\n";
			fFastStells = true;
            
            // if there are argument following it that is not an option, then must be in the format: -F max-size-subtree max-sz-gene-tree
            if( argpos < argc && argv[argpos][0] != '-' )
            {
                //
                YW_ASSERT_INFO(  argc >= argpos +4, "Check input format");
                sscanf(argv[argpos], "%d", &fastStellsMaxSubSTSize );
                ++argpos;
                sscanf(argv[argpos], "%d", &fastStellsMaxSubGTSize );
                ++argpos;
                sscanf(argv[argpos], "%d", &fastStellsMaxNumIter);
                ++argpos;
                sscanf(argv[argpos], "%d", &fastStellsSzConsensusPanel);
                ++argpos;
                YW_ASSERT_INFO( fastStellsSzConsensusPanel >= 1, "Need at least two consensus replicates");
                YW_ASSERT_INFO( fastStellsMaxSubGTSize >= fastStellsMaxSubSTSize, "fastSTELLS: max sub-species tree size must be no larger than the max sub-gene tree size" );
                YW_ASSERT_INFO( fastStellsMaxSubSTSize >=3, "The max size of sub-species tree size must be at least three" );
                YW_ASSERT_INFO( fastStellsMaxNumIter >= 1, "The max number of iteration si too small");
                cout << "Setting fastSTELLS max sub-species tree size to " << fastStellsMaxSubSTSize << ", max sub-gene tree size to " << fastStellsMaxSubGTSize << ", max number of iterations to " << fastStellsMaxNumIter <<", and the size of consensus panel to be " << fastStellsSzConsensusPanel << endl;
            }
		}
        else if( argv[argpos][1] == 'p' )
		{
			// the p option: use pairwise distance
			cout << "Turn on species tree estimate using pairwise distance between taxa (note: only for species tree inference)." << endl;
            fPairwiseMode = true;
            //argpos ++;
            //fileNameGeneTrees = argv[argpos];
            argpos++;
		}
        else if( argv[argpos][1] == 'X' )
        {
            // setup filename
            argpos ++;
            
            int nMaxSS = 5;
			sscanf(argv[argpos], "%d", &nMaxSS);
            
            YW_ASSERT_INFO(nMaxSS >=2, "Maximum gene tree degree must be at least two");
            cout << "Set the maximum gene tree degree to " << nMaxSS << endl;
            SpeciesTreeBuilderPairwiseDists :: SetMaxGTDegree(nMaxSS);
            argpos++;
			//fMDCMoreClades = false;
            //cout << "Limit number of additional clades in MDC to " << maxNumMDCMoreClades << endl;
        }
#if 0
		else if( argv[argpos][1] == 'm' )
		{
			cout << "Turn on MDC-based optimal species tree search full mode\n";
			fMDCRangeSearch = true;
			argpos++;
		}
		else if( argv[argpos][1] == 'o' )
		{
			cout << "Turn on optimal species tree search\n";
			fOptSearch = true;
			argpos++;
		}
#endif
        else
        {
            return false;
        }
    }


    return true;
}


////////////////////////////////////////////////////////////////////////////////////////

static void CheckSTELLSError()
{
    // REPORT.
    if( GetSTELLSProbComputeWarningFlag() == true )
    {
        cout << "Warning: numerical issue detected. \n";
        cout << "Likelihood approximaiton has been applied.\n";
    }
}

static double CalcLogLikeli(MarginalTree &treetestST, vector<PhylogenyTreeBasic *> &listGeneTreePtrs )
{
	double res = 0.0;
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		GeneSpeciesTreeProb gstExplorer( treetestST, *listGeneTreePtrs[tr] );

		//cout << "Then the old code...\n";
		//gstExplorer.EnumStates();

		// first faster version?
		//cout << "*************************************************************************\n";
		//cout << "Try NEW code...\n";
		res += log(gstExplorer.CalcProb() );
	}
	return res;
}

// calc LOG-prob of gene tree for a given species tree using either fast algorithm or original algo
static double CalcLogProbGeneTreeRoutine( MarginalTree &treeST, PhylogenyTreeBasic &treeGene  )
{
    double res = 0.0;
    GenericGeneSpeciesTreeProb *ptrGTP = CreateGeneTreeProbComp( treeST, treeGene );
    res = ptrGTP->CalcLogProb();
    delete ptrGTP;
    
    return res;
}


static void TestGSTTwoTrees()
{
//cout << "TestGSTTwoTrees\n";
	// for now assume binary tree only
	MarginalTree treetestST, treetestGT;

	ifstream inFileST( fileNameSpecies );
	if(!inFileST)
	{
		cout << "Can not open species tree: "<< fileNameSpecies <<endl;
		exit(1);
	}
//cout << "File read OK\n";
	// 
	// we assume only one tree per file
	TaxaMapper mapperTaxaIds;
	vector<MarginalTree> listTrees;
	ReadinMarginalTreesNewickWLen( inFileST, -1, listTrees, &mapperTaxaIds );
	treetestST = listTrees[0];
	inFileST.close();
	listTrees.clear();
	if( fVerbose == true)
	{
		cout << "After re-coding, the species tree is: \n";
		treetestST.Dump();
		cout << "The Newick format of the recoded species tree: ";
//cout << "treetestST = ";
		cout << treetestST.GetNewick() << endl;
treetestST.Dump();
	}
	

cout << "Starting to read in gene trees...\n";
	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	// read in phylogenetic tree
	if( ReadinPhyloTreesNewick( inFileGT, -1, listGeneTreePtrs, &mapperTaxaIds ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have at least one tree" );
	
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		string strNewick1;
		listGeneTreePtrs[tr]->ConsNewick(strNewick1);
		if( fVerbose == true)
		{
			// outpu this gene tree
			cout << "Read in one gene tree. After recoding: \n";
			//listGeneTreePtrs[tr]->Dump();
			cout << "The Newick format of the recoded gene tree = " << strNewick1 << endl;
cout << "Tree: ";
listGeneTreePtrs[tr]->Dump();
		}
	}


	vector<int> listMultiplicity;
	for(int tt=0; tt<(int)listGeneTreePtrs.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}

	// are there multiple trees?
	double res = 0.0;
	if( listGeneTreePtrs.size()==1 )
	{
cout << "************************* Single tree ***********************************\n";
		//PhylogenyTreeBasic phtree;
		//phtree.ConsOnNewickDupLabels(strGTree );
		//phtree.ConsOnParPosList( treetestGT.listParentNodePos, numGTAlleles, true );
		//phtree.UpdateIntLabel(treetestGT.listNodeLabels);
		//string strNewick;
		//phtree.ConsNewick(strNewick);
		//cout << "Gene Tree = " << strNewick << endl;

//TestProbCode(treetestST, *listGeneTreePtrs[0]);
//exit(1);
        
		// test GST
        double probcur = CalcLogProbGeneTreeRoutine( treetestST, *listGeneTreePtrs[0] );
		res = probcur;
		cout.precision(10);
cout << "Log-prob of this tree is " << probcur << endl;
	}
	else
	{
cout << "************************* Multiple trees ***********************************\n";
		res = 0.0;
		for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
		{
//cout << "Working on tree " << tr << endl;
            double logprobcur = CalcLogProbGeneTreeRoutine( treetestST, *listGeneTreePtrs[tr] );
			cout << "Log-prob of Tree "  << tr << " " << logprobcur << endl;
			res += logprobcur;
		}
	}

	// report result
	cout << "*******************************************************************\n";
	cout << "The log-likelihood of the given gene tree(s) for the initial species tree = " << res << endl;
	cout << "*******************************************************************\n";
//exit(1);

	if( fGeneTreeProbOnly == false)
	{
		return;
	}

	cout << "Now, we are to find the best branch length of the given species tree to MAXIMIZE the likelihood...\n";
	// now finding the best branch length maximizing the prob
	//const double MIN_BRANCH_LEN = 0.1;
	//const double MAX_BRANCH_LEN = 5.0;
	MarginalTree treePH1WLen = treetestST;
	//treePH1WLen.InitDefaultEdgeLen();
	STBranchLenFinder blFinder(listGeneTreePtrs, treePH1WLen, minBranchLenHillClimb, maxBranchLenHillClimb );
	blFinder.SetBrentMode(fBrentMode);
	blFinder.SetMultiplictyofTrees(listMultiplicity);
	if( minRatioHillClimb > 0.0 )
	{
		blFinder.SetHillClimbRatioThres(minRatioHillClimb);
	}

	MarginalTree streeBLen;
	double probval = blFinder.HillClimbBranchLen(streeBLen);
	cout << "*******************************************************************\n";
	cout << "Best branch length finder gives: " << probval << endl;
	cout << "*******************************************************************\n";
	//cout << "The resulting tree: ";
	//streeBLen.Dump();
	string nwST = streeBLen.GetNewick();
	string nwSTConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(nwST);
	cout << "The newick format of the inferred species tree with branch length: " << nwSTConv << endl;

    //
    CheckSTELLSError();

	// cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();

    
// profiling result
//DumpProfileInfo();
}

static void EstBranchLen()
{
	// read all the trees from the file
	// for now assume binary tree only
	MarginalTree treetestST;

	YW_ASSERT_INFO( fileNameSpecies != NULL, "Fatal error: species tree topology is not specified" );
	YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );
	ifstream inFileST( fileNameSpecies );
	if(!inFileST)
	{
		cout << "Can not open species tree: "<< fileNameSpecies <<endl;
		exit(1);
	}
cout << "File read OK\n";
	// 
	// we assume only one tree per file
	vector<MarginalTree> listTrees;
	ReadinMarginalTreesNewick( inFileST, -1, listTrees );
	treetestST = listTrees[0];
	inFileST.close();
	listTrees.clear();
cout << "treetestST = ";
treetestST.Dump();

	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
//cout << "pass 1\n";	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	vector<MarginalTree> listTreesMT;
	if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMT  ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
//cout << "pass 2\n";	
	YW_ASSERT_INFO( listTreesMT.size() > 0, "Must have at least one tree" );
	//listTrees.clear();
	int numLeaves = listTreesMT[0].GetNumLeaves();
	for(int tr=0; tr<(int)listTreesMT.size(); ++tr)
	{
// make the tree binary
//listTreesMT[tr].Binarize();
//cout << "Processing gene tree: ";
//listTreesMT[tr].Dump();
		PhylogenyTreeBasic *pphtree = new PhylogenyTreeBasic;
		pphtree->ConsOnParPosList( listTreesMT[tr].listParentNodePos, numLeaves, true );
		pphtree->UpdateIntLabel(listTreesMT[tr].listNodeLabels);
		string strNewick1;
		pphtree->ConsNewick(strNewick1);
		listGeneTreePtrs.push_back(pphtree);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
//		const int ROOT_LABLE = 7;
//TestReroot(pphtree, ROOT_LABLE);
	}
//exit(1);

	//const double MIN_BRANCH_LEN = 0.1;
	//const double MAX_BRANCH_LEN = 5.0;
	MarginalTree treePH1WLen = treetestST;
	// init branch length of every edge to be 1.0
	const double DEFAULT_BRANCH_LEN = 1.0;
	for( int b=0; b<treePH1WLen.GetTotNodesNum()-1; ++b )
	{
		treePH1WLen.SetBranchLen(b, DEFAULT_BRANCH_LEN);
	}
	//treePH1WLen.InitDefaultEdgeLen();
	STBranchLenFinder blFinder(listGeneTreePtrs, treePH1WLen, minBranchLenHillClimb, maxBranchLenHillClimb );
	blFinder.SetBrentMode(fBrentMode);
	if( minRatioHillClimb > 0.0 )
	{
		blFinder.SetHillClimbRatioThres(minRatioHillClimb);
	}
	MarginalTree streeBLen;
	double probval = blFinder.HillClimbBranchLen(streeBLen);
	cout << "Best branch length finder gives: " << probval << endl;
	cout << "The resulting tree: ";
	streeBLen.Dump();
	string nwST = streeBLen.GetNewick();
	cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;

    //
    CheckSTELLSError();
    
	// cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();

}


static void TestSTOptFinder()
{
	//MarginalTree treetestST;

	YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );


	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
//cout << "pass 1\n";	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	vector<MarginalTree> listTreesMT;
	if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMT  ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
//cout << "pass 2\n";	
	YW_ASSERT_INFO( listTreesMT.size() > 0, "Must have at least one tree" );
	//listTrees.clear();
	for(int tr=0; tr<(int)listTreesMT.size(); ++tr)
	{
		int numLeaves = listTreesMT[tr].GetNumLeaves();
// make the tree binary
//listTreesMT[tr].Binarize();
//cout << "Processing gene tree: ";
//listTreesMT[tr].Dump();
		PhylogenyTreeBasic *pphtree = new PhylogenyTreeBasic;
		pphtree->ConsOnParPosList( listTreesMT[tr].listParentNodePos, numLeaves, true );
		pphtree->UpdateIntLabel(listTreesMT[tr].listNodeLabels);
		string strNewick1;
		pphtree->ConsNewick(strNewick1);
		listGeneTreePtrs.push_back(pphtree);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
//		const int ROOT_LABLE = 7;
//TestReroot(pphtree, ROOT_LABLE);
	}

	// test MDC code
#if 0
	const int MDC_NUM_LEVELS = 5;
	DeepCoalescence mdcSolver( listGeneTreePtrs, MDC_NUM_LEVELS);
	int mdcRes = mdcSolver.FindMDC();
	cout << "MDC result = " << mdcRes << endl;
	set<string> listNewickTrees;
	cout << "********Now start outputting the near optimal speicies tree...\n";
	mdcSolver.RetrieveNearOptSTrees( listNewickTrees);
	cout << "Number of total number of trees: " << listNewickTrees.size() << endl;
	for( set<string> :: iterator it = listNewickTrees.begin(); it != listNewickTrees.end(); ++it)
	{
		cout << *it << endl;
	}
//exit(1);
#endif

//cout << "Reading input trees...Done\n";
	// now sample a tree
	OptSpeciesTreeFinder optSTFinder( listGeneTreePtrs );
	optSTFinder.SetApproxFlag(true);		// turn on approximate flag
	MarginalTree mleST;
	double mleLikeli = optSTFinder.FindOptST( mleST );
	cout << "mleLikeli = " << mleLikeli << endl;
	string nwST = mleST.GetNewick();
	cout << "The newick format of the inferred MLE species tree: " << nwST << endl;
	//cout << "Best species tree found: ";
	//mleST.Dump();

	// now, re-calculate the prob here
	double loglikeli = CalcLogLikeli(mleST, listGeneTreePtrs);
	cout << "loglikli of MLE trees = " << loglikeli ;
	cout << ", and likelihood = " << exp(loglikeli) << endl;

    //
    CheckSTELLSError();

	// cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();

}


static void TestSTOptMDCFinder()
{
//cout << "TestSTOptMDCFinder\n";
	//MarginalTree treetestST;

	YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );


	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
//cout << "pass 1\n";	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	TaxaMapper mapperTaxaIds;

	// use new code to read in gene trees
	// read in phylogenetic tree
	if( ReadinPhyloTreesNewick( inFileGT, -1, listGeneTreePtrs, &mapperTaxaIds ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have at least one tree" );
	
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		string strNewick1;
		listGeneTreePtrs[tr]->ConsNewick(strNewick1);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
	}
	vector<int> listMultiplicity;
	for(int tt=0; tt<(int)listGeneTreePtrs.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}
    
//cout << "Taxa mapping: ";
//mapperTaxaIds.Dump();

#if 0
	vector<MarginalTree> listTreesMTDup;
	vector<MarginalTree> listTreesMT;
	// turn on dup leaf flag
	if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMTDup, &mapperTaxaIds, true  ) == false )
	//if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMTDup, NULL  ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
//cout << "I am here\n";
	//vector<MarginalTree> listUniqTrees; 
	vector<int> listMultiplicity;
//#if 0
	CollapseEquivTrees( listTreesMTDup, listTreesMT, listMultiplicity  );
//cout << "There are " << listTreesMT.size() << " distinct trees.\n";
//cout << "List of multiplicities of the trees: ";
//DumpIntVec(listMultiplicity);
//#endif
#if 0
	listTreesMT = listTreesMTDup;
	for(int tt=0; tt<(int)listTreesMT.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}
#endif

//cout << "pass 2\n";	
	YW_ASSERT_INFO( listTreesMT.size() > 0, "Must have at least one tree" );
	//listTrees.clear();
	for(int tr=0; tr<(int)listTreesMT.size(); ++tr)
	{
		int numLeaves = listTreesMT[tr].GetNumLeaves();
// make the tree binary
//listTreesMT[tr].Binarize();
//cout << "Processing gene tree: ";
//listTreesMT[tr].Dump();
		PhylogenyTreeBasic *pphtree = new PhylogenyTreeBasic;
		pphtree->ConsOnParPosList( listTreesMT[tr].listParentNodePos, numLeaves, true );
		pphtree->UpdateIntLabel(listTreesMT[tr].listNodeLabels);
		string strNewick1;
		pphtree->ConsNewick(strNewick1);
		listGeneTreePtrs.push_back(pphtree);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
//		const int ROOT_LABLE = 7;
//TestReroot(pphtree, ROOT_LABLE);
	}

	// dump current trees
#if 0
	cout << "After conversion, list of trees:\n";
	for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
	{
		string strNW;
		listGeneTreePtrs[i]->ConsNewick(strNW);
		cout << strNW << endl;
	}
#endif

#endif

	// Use MDC to find a list of candidate trees
//#if 0
	//const int MDC_NUM_LEVELS = 5;
	//const int MAX_NUM_ST_TREES = ;
	DeepCoalescence mdcSolver( listGeneTreePtrs, numMDCLevels);
	if( maxNumMDCMoreClades > 0 )
	{
		mdcSolver.SetMaxCladeNumLimit(maxNumMDCMoreClades);
	}
	mdcSolver.SetIncMoreCladFlag(fMDCMoreClades);
	mdcSolver.SetMultiplictyofTrees(listMultiplicity);
	int mdcRes = mdcSolver.FindMDCHeu();
	if( mdcRes < 0 )
	{
		// then try full-range search
		mdcRes = mdcSolver.FindMDC();
	}

//	cout << "MDC result = " << mdcRes << endl;
	vector<set<string> > listNewickTrees;
	//cout << "********Now start outputting the near optimal speicies tree...\n";
	int numTreeTot = mdcSolver.RetrieveNearOptSTrees( listNewickTrees, numTreeSamples);
	cout << "Total number of near-parsimonious trees to evaluate: " << numTreeTot << endl;
#if 0
	int lvCur = 1;
	for( vector<set<string> > :: iterator it = listNewickTrees.begin(); it != listNewickTrees.end(); ++it)
	{
		cout << "Level: " << lvCur++ << endl;
		for( set<string> :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
		{
			cout << *it2 << endl;
		}
	}
#endif
//exit(1);
//#endif




	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Tree list is empty" );
	int numSpecies = GetNumSpeciesFromGT(*listGeneTreePtrs[0]);
	double mleTreeSearchProb = 0.0;
	MarginalTree mTreeMLE;

	vector<vector<pair<double, string> > > listTreeProbRes(listNewickTrees.size());

	//map< string, int > setProcessedTreeTopologies;
	//int numSkipped = 0;
	int t=0;
	int lvOptRes = -1;
	for(int lv = 0; lv<(int)listNewickTrees.size(); ++lv)
	{
//cout << "********Processing MDC sub-optimal: " << lv << endl;
		for( set<string> :: iterator ittg = listNewickTrees[lv].begin(); ittg != listNewickTrees[lv].end(); ++ittg)
		{
			++t;
//cout << "Processing TREE " << t << endl;

			MarginalTree mTree;
			ReadinMarginalTreesNewickWLenString( *ittg, numSpecies, mTree );
			//heuSTSampler.SampleBU(mTree);
			MarginalTree treePH1WLen = mTree;
			// init branch length of every edge to be 1.0
			const double DEFAULT_BRANCH_LEN = 1.0;
			for( int b=0; b<treePH1WLen.GetTotNodesNum()-1; ++b )
			{
				treePH1WLen.SetBranchLen(b, DEFAULT_BRANCH_LEN);
			}
			//treePH1WLen.Dump();

			//string strNewick = treePH1WLen.GetNewick();
			////cout << "The newick format: " << strNewick << endl;
			//PhylogenyTreeBasic treePBasic;
			//treePBasic.ConsOnNewick(strNewick);
			//treePBasic.Order();
			//string strOrderTree;
			//treePBasic.ConsNewick(strOrderTree);
			////cout << "After re-ordering, tree becomes: " << strOrderTree << endl;
			//strNewick = strOrderTree;

			//if( setProcessedTreeTopologies.find( strNewick ) != setProcessedTreeTopologies.end() )
			//{
			//	cout << "---Skip this tree topology: already processed before\n";
			//	setProcessedTreeTopologies[strNewick] ++;
			//	numSkipped ++;
			//	continue;
			//}
			//setProcessedTreeTopologies.insert( map< string, int > :: value_type(strNewick,1)  );

			// 
			//const double MIN_BRANCH_LEN = 0.1;
			//const double MAX_BRANCH_LEN = 2.0;
			//treePH1WLen.InitDefaultEdgeLen();
			STBranchLenFinder blFinder(listGeneTreePtrs, treePH1WLen, minBranchLenHillClimb, maxBranchLenHillClimb );
			blFinder.SetBrentMode(fBrentMode);
			blFinder.SetMultiplictyofTrees(listMultiplicity);

			if( minRatioHillClimb > 0.0 )
			{
				blFinder.SetHillClimbRatioThres(minRatioHillClimb);
			}
			
			MarginalTree streeBLen;
			double probval = blFinder.HillClimbBranchLen(streeBLen);
			//cout << "Best branch length finder gives: " << probval << endl;
			//cout << "The resulting tree: ";
			//streeBLen.Dump();
			//string nwST = streeBLen.GetNewick();
			//cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;

			if( t == 1 )
			{
				mleTreeSearchProb = probval;
				mTreeMLE = streeBLen;
				lvOptRes = lv;
cout << "Max log probility updated to " << probval << endl;
			}
			else if( mleTreeSearchProb < probval )
			{
				mleTreeSearchProb = probval;
				mTreeMLE = streeBLen;
				lvOptRes = lv;
cout << "Max log probility updated to " << probval << endl;
			}

			// finally save the probs
			pair<double,string> ppprob(probval, streeBLen.GetNewick() );
			listTreeProbRes[lv].push_back(ppprob);

		}
	}

	cout << "*********************************************************************************\n";
	cout << "Highest prob of the searched tree = " << mleTreeSearchProb << endl;
	string nwST = mTreeMLE.GetNewick();
//cout << "(BEFORE conversion) The newick format of the inferred MLE species tree: \n" << nwST << endl;
	string nwSTConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(nwST);
	cout << "The newick format of the inferred MLE species tree: " << nwSTConv << endl;
//	cout << "SubOptimal MDC level of MLE: " << lvOptRes << endl;
//	cout << "SubOptimal MDC value is " << mdcSolver.GetMDCSolVal(lvOptRes) << endl;
	//cout << "The number of skipped duplicate topologies:  " << numSkipped << endl;
	//cout << "Processed topologies: \n";
	//for( map<string,int> :: iterator it = setProcessedTreeTopologies.begin(); it != setProcessedTreeTopologies.end(); ++it)
	//{
	//	cout << it->first << ": " << it->second << " times" << endl;
	//}

	// also save the probs
	ofstream outFileProbs( fileNameTreeProbOut.c_str() );
	if(!outFileProbs)
	{
		cout << "Can not open probability output file: "<< fileNameTreeProbOut <<endl;
		exit(1);
	}
	int treeInd = 1;
	for(int lv = 0; lv<(int)listTreeProbRes.size(); ++lv)
	{
		// sort the list of prob 
		// TBD
//		outFileProbs << "****MDC level " << lv << endl;
		//int index = 0;
		for(int index=0; index<(int)listTreeProbRes[lv].size(); ++index)
		//for( set<string> :: iterator ittg = listNewickTrees[lv].begin(); ittg != listNewickTrees[lv].end(); ++ittg)
		{
			//outFileProbs << "Tree " << index << ": probability is " << listTreeProbRes[lv][index] << ", topology: " << *ittg << endl;
			outFileProbs << "Tree " << treeInd++ << ": probability is " << listTreeProbRes[lv][index].first << ", tree: " << listTreeProbRes[lv][index].second << endl;
			//index ++;
		}
	}

	outFileProbs.close();

    // report
    CheckSTELLSError();


	// now, re-calculate the prob here
	//double loglikeli = CalcLogLikeli(mleST, listGeneTreePtrs);
	//cout << "loglikli of MLE trees = " << loglikeli ;
	//cout << ", and likelihood = " << exp(loglikeli) << endl;

    

	// cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();

}

// ouput certain number of MDC trees
static void TestSTMDCOnly()
{
//cout << "TestSTOptMDCFinder\n";
	//MarginalTree treetestST;

	YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );


	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
//cout << "pass 1\n";	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	TaxaMapper mapperTaxaIds;

	// use new code to read in gene trees
	// read in phylogenetic tree
	if( ReadinPhyloTreesNewick( inFileGT, -1, listGeneTreePtrs, &mapperTaxaIds ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have at least one tree" );
	
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		string strNewick1;
		listGeneTreePtrs[tr]->ConsNewick(strNewick1);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
	}
	vector<int> listMultiplicity;
	for(int tt=0; tt<(int)listGeneTreePtrs.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}


	// Use MDC to find a list of candidate trees
//#if 0
	//const int MDC_NUM_LEVELS = 5;
	//const int MAX_NUM_ST_TREES = ;
	DeepCoalescence mdcSolver( listGeneTreePtrs, numMDCLevels);
	if( maxNumMDCMoreClades > 0 )
	{
		mdcSolver.SetMaxCladeNumLimit(maxNumMDCMoreClades);
	}
	mdcSolver.SetIncMoreCladFlag(fMDCMoreClades);
	mdcSolver.SetMultiplictyofTrees(listMultiplicity);
	int mdcRes = mdcSolver.FindMDCHeu();
	if( mdcRes < 0 )
	{
		// then try full-range search
		mdcRes = mdcSolver.FindMDC();
	}

//	cout << "MDC result = " << mdcRes << endl;
	vector<set<string> > listNewickTrees;
	//cout << "********Now start outputting the near optimal speicies tree...\n";
	int numTreeTot = mdcSolver.RetrieveNearOptSTrees( listNewickTrees, numTreeSamples);
	cout << "Total number of near-parsimonious trees to evaluate: " << numTreeTot << endl;
//#if 0
	//int lvCur = 1;
	int numTreeOut = 0;
	for( vector<set<string> > :: iterator it = listNewickTrees.begin(); it != listNewickTrees.end(); ++it)
	{
		//cout << "Level: " << lvCur++ << endl;
		for( set<string> :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
		{
			if( ++numTreeOut >  numTreeSamples)
			{
				break;
			}
			string nwtr = *it2;
			string nwtrConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(nwtr);
			cout << nwtrConv << endl;
		}
	}
//#endif
//exit(1);
//#endif


}

#if 0
static void ConsInitTreesFromInputTrees( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMultiplicity, TaxaMapper &mapperTaxaIds, vector<string> &vecNWParsTrees, bool fVerbose )
{
    // in: list of gene tree pointers
    // out: list of seed tree (in Newick)
    if( AreGeneTreesWithSameTaxa( listGeneTreePtrs ) == true )
    {
        // use MDC to find seed tree if all gene trees have same set of taxa
        
        // by default, we use MDC
        // Use MDC to find a list of candidate trees
        //#if 0
        //const int MDC_NUM_LEVELS = 5;
        //const int MAX_NUM_ST_TREES = ;
        DeepCoalescence mdcSolver( listGeneTreePtrs, numMDCLevels);
        if( maxNumMDCMoreClades > 0 )
        {
            mdcSolver.SetMaxCladeNumLimit(maxNumMDCMoreClades);
        }
        mdcSolver.SetIncMoreCladFlag(fMDCMoreClades);
        mdcSolver.SetMultiplictyofTrees(listMultiplicity);
        int mdcRes = mdcSolver.FindMDCHeu();
        if( mdcRes < 0 )
        {
            if( fVerbose )
            {
                cout << "Heuristic MDC search found no candidate species tree. Now apply full MDC...\n";
            }
            // then try full-range search
            mdcRes = mdcSolver.FindMDC();
        }
        
        //	cout << "MDC result = " << mdcRes << endl;
        vector<set<string> > listNewickTrees;
        //cout << "********Now start outputting the near optimal speicies tree...\n";
        int numTreeTot = mdcSolver.RetrieveNearOptSTrees( listNewickTrees, numTreeSamples);
        if( fVerbose )
        {
            cout << "Total number of initial trees to start exploring: " << numTreeTot << endl;
        }
#if 0
        int lvCur = 1;
        for( vector<set<string> > :: iterator it = listNewickTrees.begin(); it != listNewickTrees.end(); ++it)
        {
            cout << "Level: " << lvCur++ << endl;
            for( set<string> :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
            {
                cout << *it2 << endl;
            }
        }
#endif
        
        // merge all the trees. Reverse the order so the parsimonious trees will be explored earlier
        //for( int lv = (int)listNewickTrees.size()-1; lv >=0; lv-- )
        for( int lv = 0; lv < (int)listNewickTrees.size(); lv++ )
        {
            //cout << "Level: " << lvCur++ << endl;
            for( set<string> :: iterator it2 = listNewickTrees[lv].begin(); it2 != listNewickTrees[lv].end(); ++it2)
            {
                vecNWParsTrees.push_back( *it2 );
            }
        }
    }
    else
    {
        //
        fDiffTaxaInGTrees = true;
        int numSpecies = GetNumSpeciesFromGTs(listGeneTreePtrs);
        SpeciesTreeBuilderHeuGTSplits streeExplorer3( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds );
        streeExplorer3.Infer(true);
        string strHeuTree = streeExplorer3.GetNWTreeInfChangedTaxon();
        // YW: in the new version of species tree, do want the original species
        //if( fFastCoal == true )
        //{
        //    strHeuTree = streeExplorer3.GetNWTreeInf();
        //}
        vecNWParsTrees.push_back(strHeuTree);
    }
    
    
}
#endif


// search over tree neighbourhood (e.g. by NNI)
static string MLESTSearchNgbr( bool fOutputTree )
{
	YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );
//cout << "NNI neighbour search\n";

	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
//cout << "pass 1\n";	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	TaxaMapper mapperTaxaIds;
	// read in phylogenetic tree
	if( ReadinPhyloTreesNewick( inFileGT, -1, listGeneTreePtrs, &mapperTaxaIds ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have at least one tree" );
	
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		string strNewick1;
		listGeneTreePtrs[tr]->ConsNewick(strNewick1);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
	}
	vector<int> listMultiplicity;
	for(int tt=0; tt<(int)listGeneTreePtrs.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}

//cout << "Taxa mapping: ";
//mapperTaxaIds.Dump();

#if 0
	vector<MarginalTree> listTreesMTDup;
	vector<MarginalTree> listTreesMT;
	// turn on dup leaf flag
	if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMTDup, &mapperTaxaIds, true  ) == false )
	//if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMTDup, NULL  ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
//cout << "I am here\n";
	//vector<MarginalTree> listUniqTrees; 
	vector<int> listMultiplicity;
//#if 0
	CollapseEquivTrees( listTreesMTDup, listTreesMT, listMultiplicity  );
//cout << "There are " << listTreesMT.size() << " distinct trees.\n";
//cout << "List of multiplicities of the trees: ";
//DumpIntVec(listMultiplicity);
//#endif
#if 0
	listTreesMT = listTreesMTDup;
	for(int tt=0; tt<(int)listTreesMT.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}
#endif

//cout << "pass 2\n";	
	YW_ASSERT_INFO( listTreesMT.size() > 0, "Must have at least one tree" );
	//listTrees.clear();
	for(int tr=0; tr<(int)listTreesMT.size(); ++tr)
	{
		int numLeaves = listTreesMT[tr].GetNumLeaves();
// make the tree binary
//listTreesMT[tr].Binarize();
//cout << "Processing gene tree: ";
//listTreesMT[tr].Dump();
		PhylogenyTreeBasic *pphtree = new PhylogenyTreeBasic;
		pphtree->ConsOnParPosList( listTreesMT[tr].listParentNodePos, numLeaves, true );
		pphtree->UpdateIntLabel(listTreesMT[tr].listNodeLabels);
		string strNewick1;
		pphtree->ConsNewick(strNewick1);
		listGeneTreePtrs.push_back(pphtree);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
//		const int ROOT_LABLE = 7;
//TestReroot(pphtree, ROOT_LABLE);
	}
#endif


	// dump current trees
#if 0
	cout << "After conversion, list of trees:\n";
	for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
	{
		string strNW;
		listGeneTreePtrs[i]->ConsNewick(strNW);
		cout << strNW << endl;
	}
#endif

//const int NUM_TAXA_SUBTREE = 3;
//const char *buffilename = "tmptreeout.trees";
//DumpAllSubtreesWithTaxaSize( listGeneTreePtrs, NUM_TAXA_SUBTREE, buffilename );
//exit(1);

	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Tree list is empty" );
	//int numSpecies = GetNumSpeciesFromGT(*listGeneTreePtrs[0]);
    int numSpecies = GetNumSpeciesFromGTs(listGeneTreePtrs);
	//double mleTreeSearchProb = 0.0;
	//MarginalTree mTreeMLE;
	//vector<vector<pair<double, string> > > listTreeProbRes(listNewickTrees.size());

	// this is the seed trees to use
	vector<string> vecNWParsTrees;

	if( fileNameSeedTrees == NULL )
	{
        ConsInitTreesFromInputTrees(listGeneTreePtrs, listMultiplicity, mapperTaxaIds, vecNWParsTrees, true, numMDCLevels, fMDCMoreClades, maxNumMDCMoreClades, numTreeSamples, fDiffTaxaInGTrees);
	}
	else
	{
		// otherwise, simply read in the seed trees to use as the one (remember to convert by internal mapping)
		vector<PhylogenyTreeBasic *> listSeedTreePtrs;
		
		ifstream inFileSeedTrees( fileNameSeedTrees );
		if(!inFileSeedTrees)
		{
			cout << "Can not open gene tree: "<< fileNameSeedTrees <<endl;
			exit(1);
		}
		// read in phylogenetic tree
		if( ReadinPhyloTreesNewick( inFileSeedTrees, -1, listSeedTreePtrs, &mapperTaxaIds ) == false )
		{
			cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
		}
		inFileSeedTrees.close();
		YW_ASSERT_INFO( listSeedTreePtrs.size() > 0, "Must have at least one tree" );
		
		for(int tr=0; tr<(int)listSeedTreePtrs.size(); ++tr)
		{
//cout << "Now output tr = " << tr << endl;
			string strNewick1;
			listSeedTreePtrs[tr]->ConsNewick(strNewick1);
			vecNWParsTrees.push_back( strNewick1 );
//cout << "Seed tree " << tr << ": " << strNewick1 << endl;
		}

	
	}
    
    // testing
    string resTreeNW;
    if( fPairwiseMode == true )
    {
//SpeciesTreeBuilderHeuGTSplits streeExplorer3( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds );
//streeExplorer3.Infer();
//exit(1);
        YW_ASSERT_INFO(fDiffTaxaInGTrees == false, "This version of STELLS does not allow gene trees with only subsets of all the taxa when running with -p option");
        
        SpeciesTreeBuilderPairwiseDists streeExplorer2( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds );
        streeExplorer2.SetOutputHere( fOutputTree );
        streeExplorer2.Infer();
        resTreeNW = streeExplorer2.GetBestInfSpeicesTreeConv();
//exit(1);
    }
    else
    {
        // run regular mode
        SpeciesTreeExplorer streeExplorer( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds );
        streeExplorer.SetBranchLenRange( minBranchLenHillClimb, maxBranchLenHillClimb );
        streeExplorer.SetSearchNgbrTreesFlag(fExploreNgbrTrees);
        streeExplorer.SetBrentMode(fBrentMode);
        streeExplorer.SetNumNearOptTreesKept(numNearOptTreesKept);
        streeExplorer.SetOutputTreeHere(fOutputTree);
        streeExplorer.ExploreFrom(vecNWParsTrees);
        string fnameInit = fileNameGeneTrees;
        streeExplorer.OutputNearOptTrees(fnameInit);
        
        //
        resTreeNW = streeExplorer.GetBestInfSpeicesTreeConv();
    }
    
	// REPORT.
    CheckSTELLSError();
    
	// cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();
    
    return resTreeNW;
    
// profiling result
//DumpProfileInfo();
}



static void TestSTOptMDCRangeSearchFinder()
{
	//MarginalTree treetestST;
	YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );

	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
//cout << "pass 1\n";	
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	vector<MarginalTree> listTreesMT;
	if( ReadinMarginalTreesNewick(  inFileGT, -1, listTreesMT  ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
//cout << "pass 2\n";	
	YW_ASSERT_INFO( listTreesMT.size() > 0, "Must have at least one tree" );
	//listTrees.clear();
	for(int tr=0; tr<(int)listTreesMT.size(); ++tr)
	{
		int numLeaves = listTreesMT[tr].GetNumLeaves();
// make the tree binary
//listTreesMT[tr].Binarize();
//cout << "Processing gene tree: ";
//listTreesMT[tr].Dump();
		PhylogenyTreeBasic *pphtree = new PhylogenyTreeBasic;
		pphtree->ConsOnParPosList( listTreesMT[tr].listParentNodePos, numLeaves, true );
		pphtree->UpdateIntLabel(listTreesMT[tr].listNodeLabels);
		string strNewick1;
		pphtree->ConsNewick(strNewick1);
		listGeneTreePtrs.push_back(pphtree);
//		cout << "Constructed one gene Tree = " << strNewick1 << endl;
//		const int ROOT_LABLE = 7;
//TestReroot(pphtree, ROOT_LABLE);
	}

	// different from previous one, this code will do a range testing
	// that is, it will not fix a particular level of MDC, but rather, it will 
	// self-adjust the range of tree to search
	const int STEP_MDC_LEVEL = 5;
	const int STEP_MDC_NUM_TREES = 50;

	// info kept
	double mleTreeSearchProb = 0.0;
	MarginalTree mTreeMLE;
	int lvOptRes = -1;

	int mdcLevelCur = numMDCLevels;
	int mdcTreeLimit = numTreeSamples;
	int mdcTreelLast = -1;

	while(true)
	{
		// Use MDC to find a list of candidate trees
	//#if 0
		//const int MDC_NUM_LEVELS = 5;
		//const int MAX_NUM_ST_TREES = ;
		DeepCoalescence mdcSolver( listGeneTreePtrs, mdcLevelCur);
		int mdcRes = mdcSolver.FindMDC();
		cout << "MDC result = " << mdcRes << endl;
		vector<set<string> > listNewickTrees;
		cout << "********Now start outputting the near optimal speicies tree...\n";
		int numTreeTot = mdcSolver.RetrieveNearOptSTrees( listNewickTrees, mdcTreeLimit);
		cout << "Total number of trees: " << numTreeTot << endl;
		int lvCur = 1;
for( vector<set<string> > :: iterator it = listNewickTrees.begin(); it != listNewickTrees.end(); ++it)
{
	cout << "Level: " << lvCur++ << endl;
	for( set<string> :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
	{
		cout << *it2 << endl;
	}
}
	//exit(1);
	//#endif


		YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Tree list is empty" );
		int numSpecies = GetNumSpeciesFromGT(*listGeneTreePtrs[0]);
		//map< string, int > setProcessedTreeTopologies;
		//int numSkipped = 0;
		int t=0;
		bool fMLEUpdate = false;

		for(int lv = 0; lv<(int)listNewickTrees.size(); ++lv)
		{
			// make sure we are doing new trees
cout << "********Processing MDC sub-optimal: " << lv << endl;
			for( set<string> :: iterator ittg = listNewickTrees[lv].begin(); ittg != listNewickTrees[lv].end(); ++ittg)
			{
				if( t <= mdcTreelLast)
				{
					// skipt
					continue;
				}

				mdcTreelLast = t;

//cout << "Processing TREE " << ++t << endl;

				MarginalTree mTree;
				ReadinMarginalTreesNewickWLenString( *ittg, numSpecies, mTree );
				//heuSTSampler.SampleBU(mTree);
				MarginalTree treePH1WLen = mTree;
				// init branch length of every edge to be 1.0
				const double DEFAULT_BRANCH_LEN = 1.0;
				for( int b=0; b<treePH1WLen.GetTotNodesNum()-1; ++b )
				{
					treePH1WLen.SetBranchLen(b, DEFAULT_BRANCH_LEN);
				}
				//treePH1WLen.Dump();

				// 
				//const double MIN_BRANCH_LEN = 0.1;
				//const double MAX_BRANCH_LEN = 2.0;
				//treePH1WLen.InitDefaultEdgeLen();
				STBranchLenFinder blFinder(listGeneTreePtrs, treePH1WLen, minBranchLenHillClimb, maxBranchLenHillClimb );
				blFinder.SetBrentMode(fBrentMode);
				if( minRatioHillClimb > 0.0 )
				{
					blFinder.SetHillClimbRatioThres(minRatioHillClimb);
				}

				MarginalTree streeBLen;
				double probval = blFinder.HillClimbBranchLen(streeBLen);
				//cout << "Best branch length finder gives: " << probval << endl;
				//cout << "The resulting tree: ";
				//streeBLen.Dump();
				//string nwST = streeBLen.GetNewick();
				//cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;

				if( t == 1 )
				{
					mleTreeSearchProb = probval;
					mTreeMLE = streeBLen;
					lvOptRes = lv;
					fMLEUpdate = true;
cout << "Max log-probability updated to " << probval << endl;
				}
				else if( mleTreeSearchProb < probval )
				{
					mleTreeSearchProb = probval;
					mTreeMLE = streeBLen;
					lvOptRes = lv;
					fMLEUpdate = true;
cout << "Max log-probability updated to " << probval << endl;
				}

			}
		}
		// if no update, stop
		if( fMLEUpdate == false )
		{
			break;
		}

		// move on
		mdcLevelCur += STEP_MDC_LEVEL;
		mdcTreeLimit += STEP_MDC_NUM_TREES;
	}

	cout << "*********************************************************************************\n";
	cout << "Highest prob of the searched tree = " << mleTreeSearchProb << endl;
	string nwST = mTreeMLE.GetNewick();
	cout << "The newick format of the inferred MLE species tree: " << nwST << endl;
	cout << "SubOptimal MDC level of MLE: " << lvOptRes << endl;

	// cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();

}


// use subset of trees to infer species tree

void InfSpeciesTreeFromSubtrees()
{
    //const int NUM_TAXA_SUBTREE = 3;
    char buffilename[1000];
    char buffilenameST[1000];
    
    //int szSubsetTaxa = NUM_TAXA_SUBTREE;
    
    // use the same file name but extend it by
    YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );
    if( szSubsetTaxa >= 2 )
    {
        sprintf( buffilename, "%s.subset%d.tmptrees", fileNameGeneTrees, szSubsetTaxa );
    }
    else
    {
        //
        YW_ASSERT_INFO( szMaxSubtreeSz >=2, "Wrong");
        sprintf( buffilename, "%s.sz%d.id%d.tmptrees", fileNameGeneTrees, szMaxSubtreeSz, szMaxSubtreeIdent );
    }
    // read in the gene tree file
	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
    //cout << "pass 1\n";
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	TaxaMapper mapperTaxaIds;
	// read in phylogenetic tree
	if( ReadinPhyloTreesNewick( inFileGT, -1, listGeneTreePtrs, &mapperTaxaIds ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have at least one tree" );
	
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		string strNewick1;
		listGeneTreePtrs[tr]->ConsNewick(strNewick1);
//cout << "Constructed one gene Tree = " << strNewick1 << endl;
	}
	vector<int> listMultiplicity;
	for(int tt=0; tt<(int)listGeneTreePtrs.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}
    
    // construct initial tree if no initial trees are provided
    if(fileNameSeedTrees == NULL)
    {
        vector<string> vecNWParsTrees;
        ConsInitTreesFromInputTrees(listGeneTreePtrs, listMultiplicity, mapperTaxaIds, vecNWParsTrees, true, numMDCLevels, fMDCMoreClades, maxNumMDCMoreClades, numTreeSamples, fDiffTaxaInGTrees);
        
        //
        if( szSubsetTaxa >=2 )
        {
            sprintf(buffilenameST, "%s.subset%d.cons.initst", fileNameGeneTrees, szSubsetTaxa );
        }
        else
        {
            //
            sprintf(buffilenameST, "%s.sz%d.id%d.cons.initst", fileNameGeneTrees, szMaxSubtreeSz, szMaxSubtreeIdent );
        }
        //
        OutputStringsToFile( buffilenameST, vecNWParsTrees );
        
        // set initial tree file to be this artificial one
        fileNameSeedTrees = buffilenameST;
    }
    
    // create subtrees
    if( szSubsetTaxa >=2 )
    {
        DumpAllSubtreesWithTaxaSize( listGeneTreePtrs, szSubsetTaxa, buffilename );
    }
    else
    {
        //
        DumpAllSubtreesWithBoundedSize(listGeneTreePtrs, szMaxSubtreeSz, szMaxSubtreeIdent, buffilename);
    }
    // cleanup
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		delete listGeneTreePtrs[tr];
	}
	listGeneTreePtrs.clear();
    
//cout << "Now invoke tree inference from tree file: " << buffilename << endl;
    // now perform inference from the subtrees
    fileNameGeneTrees = buffilename;
    
    //MLESTSearchNgbr();
    string treeNWRes;
    if( fExploreNgbrTrees == true )
    {
        treeNWRes = MLESTSearchNgbr(false);
    }
    else
    {
        //  TBDDDDDDDDDDDDDD
        cout << "Warning: tree format not converted. This is a known bug that will be fixed later...\n";
        TestSTOptMDCFinder();
    }
    
    cout << "Inferred species tree: ";
    cout << mapperTaxaIds.ConvIdStringWithOrigTaxa(treeNWRes);
    cout << endl;
}

// fastSTELLS: fast inference of species tree
void runFastSTELLS()
{
    YW_ASSERT_INFO( fileNameGeneTrees != NULL, "Fatal error: gene trees file not specified" );
    //cout << "NNI neighbour search\n";
    
	// now read in the set of gene trees
	vector<PhylogenyTreeBasic *> listGeneTreePtrs;
    //cout << "pass 1\n";
	ifstream inFileGT( fileNameGeneTrees );
	if(!inFileGT)
	{
		cout << "Can not open gene tree: "<< fileNameGeneTrees <<endl;
		exit(1);
	}
	TaxaMapper mapperTaxaIds;
	// read in phylogenetic tree
	if( ReadinPhyloTreesNewick( inFileGT, -1, listGeneTreePtrs, &mapperTaxaIds ) == false )
	{
		cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
	}
	inFileGT.close();
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have at least one tree" );
	
	for(int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr)
	{
		string strNewick1;
		listGeneTreePtrs[tr]->ConsNewick(strNewick1);
        //		cout << "Constructed one gene Tree = " << strNewick1 << endl;
	}
	vector<int> listMultiplicity;
	for(int tt=0; tt<(int)listGeneTreePtrs.size(); ++tt)
	{
		listMultiplicity.push_back(1);
	}
    
cout << "Taxa mapping: ";
mapperTaxaIds.Dump();
    
    
	// dump current trees
#if 0
	cout << "After conversion, list of trees:\n";
	for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
	{
		string strNW;
		listGeneTreePtrs[i]->ConsNewick(strNW);
		cout << strNW << endl;
	}
#endif
    
    // test code:
//cout << "Here...\n";
//TestFSTIClusterEval(listGeneTreePtrs, listMultiplicity);
//TestTriplesInf( listGeneTreePtrs, listMultiplicity, mapperTaxaIds );
//exit(1);
    
    
	YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Tree list is empty" );
	//int numSpecies = GetNumSpeciesFromGT(*listGeneTreePtrs[0]);
    int numSpecies = GetNumSpeciesFromGTs(listGeneTreePtrs);
	//double mleTreeSearchProb = 0.0;
	//MarginalTree mTreeMLE;
	//vector<vector<pair<double, string> > > listTreeProbRes(listNewickTrees.size());
    
	// this is the seed trees to use
	vector<string> vecNWParsTrees;
    
	if( fileNameSeedTrees == NULL )
	{
        ConsInitTreesFromInputTrees(listGeneTreePtrs, listMultiplicity, mapperTaxaIds, vecNWParsTrees, true, numMDCLevels, fMDCMoreClades, maxNumMDCMoreClades, numTreeSamples, fDiffTaxaInGTrees);
	}
	else
	{
		// otherwise, simply read in the seed trees to use as the one (remember to convert by internal mapping)
		vector<PhylogenyTreeBasic *> listSeedTreePtrs;
		
		ifstream inFileSeedTrees( fileNameSeedTrees );
		if(!inFileSeedTrees)
		{
			cout << "Can not open gene tree: "<< fileNameSeedTrees <<endl;
			exit(1);
		}
		// read in phylogenetic tree
		if( ReadinPhyloTreesNewick( inFileSeedTrees, -1, listSeedTreePtrs, &mapperTaxaIds ) == false )
		{
			cout << "CAUTION: checking the input file. It seems some part of input may be wrong\n";
		}
		inFileSeedTrees.close();
		YW_ASSERT_INFO( listSeedTreePtrs.size() > 0, "Must have at least one tree" );
		
		for(int tr=0; tr<(int)listSeedTreePtrs.size(); ++tr)
		{
            //cout << "Now output tr = " << tr << endl;
			string strNewick1;
			listSeedTreePtrs[tr]->ConsNewick(strNewick1);
			vecNWParsTrees.push_back( strNewick1 );
            //cout << "Seed tree " << tr << ": " << strNewick1 << endl;
		}
	}
    
// test code
//TestTriplesFromTrees( vecNWParsTrees, numSpecies, mapperTaxaIds );
//exit(1);
    
//#if 0
    
    // simply used the first init tree topology
    YW_ASSERT_INFO( vecNWParsTrees.size() > 0, "Wrong" );
    FastSpeciesTreeInference fstInf( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds, vecNWParsTrees[0] );

    //fstInf.Infer();
    fstInf.InferTriples();
    cout << "The triple-based inferred species tree: " << mapperTaxaIds.ConvIdStringWithOrigTaxa(fstInf.GetInferredTreeNewick()) << endl;
    
    // now use the triple-based inferred tree to infer the tree by convergence
    FastSpeciesTreeInference fstInfConv( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds, fstInf.GetInferredTreeNewick() );
    if( fastStellsMaxSubSTSize > 0 && fastStellsMaxSubGTSize > 0 && fastStellsMaxNumIter > 0)
    {
        fstInfConv.ConfigSearch( fastStellsMaxSubSTSize, fastStellsMaxSubGTSize, fastStellsMaxNumIter, fastStellsSzConsensusPanel );
    }
    //fstInf.Infer();
    bool fConverged = fstInfConv.InfConverge();
    if( fConverged == false )
    {
        cout << "WARNING: convergence is not achieved. You may consider changing the search options or use more gene trees\n";
    }
    else
    {
        cout << "************************************************************************\n";
        cout << "The fastSTELLS INFERRED SPECIES TREE: " << mapperTaxaIds.ConvIdStringWithOrigTaxa( fstInfConv.GetInferredTreeNewick() ) << endl;
    }
    
//#endif
    
#if 0
    bool fConverged = false;
    for(int i=0; i<(int)vecNWParsTrees.size() && i<maxIterationFastSTELLS; ++i)
    {
        FastSpeciesTreeInference fstInf( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds, vecNWParsTrees[i] );
        if( fastStellsMaxSubSTSize > 0 && fastStellsMaxSubGTSize > 0 && fastStellsMaxNumIter > 0)
        {
            fstInf.ConfigSearch( fastStellsMaxSubSTSize, fastStellsMaxSubGTSize, fastStellsMaxNumIter, fastStellsSzConsensusPanel );
        }
        //fstInf.Infer();
        bool fresstep = fstInf.InfConverge();
        if( fresstep == true )
        {
            fConverged = true;
            break;
        }
    }
    if( fConverged == false )
    {
        cout << "WARNING: convergence is not achieved. You may consider changing the search options or use more gene trees\n";
    }
#endif
}


//const char *STELLS_VER_INFO ="*** STELLS ver. 1.1, November 25, 2010 ***";
const char *STELLS_VER_INFO ="*** STELLS ver. 2.1.0, September 23, 2016 ***";



//******************************************************************
int main(int argc, char **argv)
{
//    int seq = 0x001;
//    int seqMut;
//    MutateHCSeqAt(seq, seqMut, 4, 2);
//cout << "mutated seq = " << seqMut << endl;


//TestGSTTemp();
//TestNJ();
//TestTriples();
//TestCalcProbBranch();
//exit(1);
    
	cout << STELLS_VER_INFO << endl << endl;

	// first verify usage
	if( CheckArguments(  argc, argv  ) == false)
	{
		Usage(); 
	}
    
    // run approx mode if nothing being set
    SetApproxLikelihood( fApproxLikeli );
    
//cout << "here0\n";
    long tstart1 = GetCurrentTimeTick();

	if( fTestMode == true )
	{
		//TestSTSampler();
		//TestSTOptFinder();
		//TestSTOptMDCFinder();
		//MLESTSearchNgbr();
		TestSTMDCOnly();

		//TestOptSTSearch();
	    cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;
		return 0;
	}

	if(fOptSearch == true)
	{
//cout << "here\n";
		TestSTOptFinder();
	    cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;
		return 0;
	}

	if( fMDCRangeSearch == true )
	{
		TestSTOptMDCRangeSearchFinder();
	    cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;
		return 0;
	}


	if( fBranchLenMode == true )
	{
		EstBranchLen();
		cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;
		return 0;
	}
    

	// test input of species tree and gene trees
	if( fileNameSpecies != NULL )
	{
//cout << "here\n";
		// species tree is given, so work on it
		TestGSTTwoTrees(  );
	}
	else
	{
        // are we running fastSTELLS?
        if( fFastStells == true )
        {
            runFastSTELLS();
        }
        else
        {
            // are we using subtrees for inference?
            if( szMaxSubtreeSz >= 2)
            //if( szSubsetTaxa >=2 || szMaxSubtreeSz >= 2)
            {
                InfSpeciesTreeFromSubtrees();
            }
            else
            {
                if( fExploreNgbrTrees == true )
                {
                    MLESTSearchNgbr(true);
                }
                else
                {
                    TestSTOptMDCFinder();
                }
            }
        }
	}

    cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;
    
    // dump out stats
    //ApproxGTPStats::Instance().DumpStats();

    return 0;

}

