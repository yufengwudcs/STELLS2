//
//  TreeInfSubsets.cpp
//  
//
//  Created by Yufeng Wu on 9/13/15.
//
//

#include "TreeInfSubsets.h"
#include "SpeciesTreeExplorer.h"
#include "TreeBuilder.h"
#include "TreeTriples.h"
#include "Utils4.h"

const double DEF_MIN_BRANCH_LEN1 = 0.005;
const double DEF_MAX_BRANCH_LEN1 = 5.0;

//////////////////////////////////////////////////////////////////////////////////
// Infer species tree from pairwise distance of species

int SpeciesTreeBuilderPairwiseDists :: maxDegreeGT = HAP_MAX_INT;


SpeciesTreeBuilderPairwiseDists :: SpeciesTreeBuilderPairwiseDists( int numSpeciesIn, vector<PhylogenyTreeBasic *> &listGeneTreePtrsIn, const vector<int> &listMPIn, TaxaMapper &mapperTaxaIdsIn ) : numSpecies(numSpeciesIn), listGeneTreePtrs(listGeneTreePtrsIn), listMP(listMPIn), mapperTaxaIds(mapperTaxaIdsIn)
{
    //
    minBranchLenHillClimb = DEF_MIN_BRANCH_LEN1;
    maxBranchLenHillClimb = DEF_MAX_BRANCH_LEN1;
    fExploreNgbrTrees = true;
    fBrentMode = true;
    numNearOptTreesKept = 100;  // arbitary
}

// change the max-degree
void SpeciesTreeBuilderPairwiseDists :: SetMaxGTDegree(int szMax)
{
    //
    maxDegreeGT = szMax;
}

void SpeciesTreeBuilderPairwiseDists :: Infer()
{
//cout << "TaxaMapper: ";
//mapperTaxaIds.Dump();
    
    map<string,int> mapTaxaIDStrToId;
    set<string> setAllTaxaStrs;
    set<int> setAllTaxaIds;
    mapperTaxaIds.GetAllTaxaIds(setAllTaxaIds);
    for(set<int> :: iterator it = setAllTaxaIds.begin(); it != setAllTaxaIds.end(); ++it)
    {
        char buf[100];
        sprintf(buf, "%d", *it);
        string strId = buf;
        setAllTaxaStrs.insert( strId );
        mapTaxaIDStrToId.insert( map<string,int> :: value_type( strId, *it ) );
    }
    
//for(set<string> :: iterator it = setAllTaxaStrs.begin(); it != setAllTaxaStrs.end(); ++it)
//{
//cout << "Taxa: " << *it << endl;
//}
#if 0
    for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
    {
        cout << "Gene tree: ";
        string strNW;
        listGeneTreePtrs[i]->ConsNewick(strNW);
        cout << "In SpeciesTreeBuilderPairwiseDists :: Infer(): gene tree: " << strNW << endl;
    }
#endif
    
    //
    PhyloDistance distPairSpecies;
    
    // do for all pairs of taxa
    for( set<string> :: iterator it1 = setAllTaxaStrs.begin(); it1 != setAllTaxaStrs.end(); ++it1)
    {
        set<string> :: iterator it2 = it1;
        ++it2;
        for(; it2 != setAllTaxaStrs.end(); ++it2)
        {
            //if( IsVerbose() )
            {
                cout << "Processing taxa " << *it1 << " " << *it2 << endl;
            }
            
            // get subtrees out of it
            set<string> setTwoTaxa;
            setTwoTaxa.insert(*it1);
            setTwoTaxa.insert(*it2);
            
            vector<PhylogenyTreeBasic *> listTreeSubsAll;
            for(int tr=0; tr<(int)listGeneTreePtrs.size();++tr)
            {
                PhylogenyTreeBasic *ptreeNew = new PhylogenyTreeBasic;
                listGeneTreePtrs[tr]->CreatePhyTreeFromLeavesWithLabels( setTwoTaxa, *ptreeNew, false );
                listTreeSubsAll.push_back(ptreeNew);
                
//cout << "SUB-Genetree: ";
//string strNW;
//ptreeNew->ConsNewick(strNW);
//cout << " " << strNW << endl;
            }
            
            // ensure the gene trees pass the degree test; if not, ignore them
            vector<PhylogenyTreeBasic *> listTreeSubsUse;
            vector<int> listMPUse;
            FilterGeneTreeByMaxDegree( listTreeSubsAll, listTreeSubsUse, listMP, listMPUse );
            if( listTreeSubsUse.size() == 0 )
            {
                cout << "Fatal error: the gene trees appear to be very unresolved or you have set the maximum degree bound to be too low. Stop.\n";
                exit(1);
            }
            YW_ASSERT_INFO(listTreeSubsUse.size() == listMPUse.size(), "Wrong.");
//cout << "The number of gene trees to use: " << listTreeSubsUse.size() << endl;
            
            // explore from trivial tree
            //string strNWST = "(" + (*it1) + ":1.0,"+(*it2) + ":1.0)";
            string strNWST = "(0:1.0,1:1.0)";
//cout << "Species tree to start: " << strNWST << endl;
            vector<string> vecNWParsTrees;
            vecNWParsTrees.push_back(strNWST);
            
            // infer the best tree
            int numSpeciesSub = 2;
            SpeciesTreeExplorer streeExplorer( numSpeciesSub, listTreeSubsUse, listMPUse, mapperTaxaIds );
            streeExplorer.SetBranchLenRange( minBranchLenHillClimb, maxBranchLenHillClimb );
            streeExplorer.SetSearchNgbrTreesFlag(fExploreNgbrTrees);
            streeExplorer.SetBrentMode(fBrentMode);
            streeExplorer.SetNumNearOptTreesKept(numNearOptTreesKept);
            streeExplorer.SetOutputTreeHere(false);
            streeExplorer.ExploreFrom(vecNWParsTrees);
            
            // get the inferred tree heights
//cout << "Step inferred species tree: " << streeExplorer.GetBestInfSpeicesTree() << endl;
            vector<double> listBrLensST;
            streeExplorer.GetBestSTBranchLens( listBrLensST );
            if( IsVerbose() )
            {
                cout << "Inferred branch length: ";
                DumpDoubleVec( listBrLensST);
            }
            YW_ASSERT_INFO( listBrLensST.size() >=2, "Wrong" );
            double distTwoTaxa =  listBrLensST[0] + listBrLensST[1] ;
            int idTaxa1 =mapTaxaIDStrToId[*it1];
            int idTaxa2 =mapTaxaIDStrToId[*it2];
            distPairSpecies.SetDistance(idTaxa1, idTaxa2, distTwoTaxa);
            
            // finally clear up
            for(int i=0; i<(int)listTreeSubsUse.size(); ++i)
            {
                delete listTreeSubsUse[i];
            }
            listTreeSubsUse.clear();
        }
    }
    
    // now infer the overall species tre with NJ
    DistanceTreeBuilder builder(distPairSpecies);
    string treeNW = builder.NJ();
    
    if( IsVerbose() )
    {
        cout << "Constructed raw NJ tree: " << treeNW << endl;
        cout << "The set of esimated pairwise distances: ";
        distPairSpecies.Dump();
    }
    
    string nwSTConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(treeNW);
    this->strTreeResConvBack = nwSTConv;
    
    if( fOutputHere == true )
    {
        cout << "The inferred species tree using pairwise distances between taxa: " << nwSTConv << endl;
    }
}

// discard trees with too large degree in order to speedup the computation
void SpeciesTreeBuilderPairwiseDists :: FilterGeneTreeByMaxDegree( vector<PhylogenyTreeBasic *> &listTreeSubsAll, vector<PhylogenyTreeBasic *> &listTreeSubsUse, const vector<int> &listMP, vector<int> & listMPUse )
{
    //
    listTreeSubsUse.clear();
    listMPUse.clear();
    YW_ASSERT_INFO( listTreeSubsAll.size() == listMP.size(), "The number of gene trees does not match the number of tree multiplicity." );
    for(int i=0; i<(int)listTreeSubsAll.size(); ++i )
    {
        //
        if( listTreeSubsAll[i]->GetMaxDegree() <= maxDegreeGT )
        {
            listTreeSubsUse.push_back( listTreeSubsAll[i] );
            listMPUse.push_back( listMP[i] );
        }
        else
        {
            // discard it
            delete listTreeSubsAll[i];
        }
    }
    
    // clear out the old list
    listTreeSubsAll.clear();
}

//////////////////////////////////////////////////////////////////////////////////
// Infer species tree heuristically from gene tree splits
// this code allows subsets of taxa to appear in each gene tree


SpeciesTreeBuilderHeuGTSplits :: SpeciesTreeBuilderHeuGTSplits( int numSpeciesIn, vector<PhylogenyTreeBasic *> &listGeneTreePtrsIn, const vector<int> &listMPIn, TaxaMapper &mapperTaxaIdsIn ) : numSpecies(numSpeciesIn), listGeneTreePtrs(listGeneTreePtrsIn), listMP(listMPIn), mapperTaxaIds(mapperTaxaIdsIn)
{
    //
}

void SpeciesTreeBuilderHeuGTSplits :: Infer(bool fBinTreeOnly)
{
    // fBinTreeOnly: true if only binary tree is desired
    // collect triples from each gene tree; for now, ignore multiplicity
    set<PhyloTriple> setTriplesFound;
    
    for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
    {
        multiset<multiset< multiset<int> > > setCladeGroupsDupLabels;
        multiset<int> rootClade;
        listGeneTreePtrs[i]->GetAllCladeGroupsIntLabel( setCladeGroupsDupLabels, rootClade );
        
        map<int,int> mapMSMap;
        CountMultiset(rootClade, mapMSMap);
        
        for( multiset<multiset< multiset<int> > > :: iterator it= setCladeGroupsDupLabels.begin(); it!=setCladeGroupsDupLabels.end(); ++it )
        {
            //
            set<PhyloTriple> setTriplesFoundStep;
            PhyloTripleUtils :: GetAllTriplesFromCladesWithDupLabels( *it, mapMSMap, setTriplesFoundStep );
            PhyloTripleUtils :: CombineTriples( setTriplesFound, setTriplesFoundStep );
        }
    }
    
    // now build trees from the triples
#if 0
cout << "(Combned) Found triples: ";
for(set<PhyloTriple> :: iterator it = setTriplesFound.begin(); it != setTriplesFound.end(); ++it)
{
it->Dump();
}
cout << endl;
#endif
    
    set<set<int> > treeClades;
    PhyloTripleUtils :: BuildTreeFromCompatTriples( setTriplesFound, treeClades );
#if 0
for( set<set<int> > :: iterator it = treeClades.begin(); it != treeClades.end(); ++it )
{
//
cout << "Constructed clade: ";
DumpIntSet(*it);
}
#endif
    // build a tree from clades
    PhylogenyTreeBasic treeToCons;
    CreatePhyTreeWithRootedSplits( treeToCons, numSpecies, treeClades );
    
    // binaryize if not binary tree and we want only binary trees
    if( fBinTreeOnly == true )
    {
        treeToCons.Binarize();
    }
    
    // assign leaf labels for the species tree
    map<int,string> mapLeafIdToStr;
    for(int i=0; i<numSpecies; ++i)
    {
        char buf[100];
        sprintf(buf, "%d", i);
        string leafStr = buf;
        mapLeafIdToStr.insert( map<int,string> :: value_type(i, leafStr) );
    }
    treeToCons.AssignLeafLabels(mapLeafIdToStr);
    
    
    string nwSTCons;
    treeToCons.ConsNewick( nwSTCons );
    string nwSTConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(nwSTCons);
cout << "The inferred heuristic species tree from gene tree topologiy: " << nwSTConv << endl;
cout << "Before converting, species tree: " << nwSTCons << endl;
    this->treeInfNWRes = nwSTConv;
    this->treeInfNWResChangedTaxon = nwSTCons;
}


