//
//  GSTProbComposite.h
//  
//
//  Created by Yufeng Wu on 1/18/16.
//
//

#ifndef ____GSTProbComposite__
#define ____GSTProbComposite__

#include <vector>
#include <set>
#include <map>
using namespace std;

#include "GeneSpeciesTreeProb.h"

class MarginalTree;
class PhylogenyTreeBasic;
class TaxaMapper;


//////////////////////////////////////////////////////////////////////////////////
// Calc composite tree prob 

class GeneTreeProbComposite : public GenericGeneSpeciesTreeProb
{
public:
    GeneTreeProbComposite( MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene );
    virtual ~GeneTreeProbComposite();
    virtual double CalcProb();
    virtual double CalcLogProb();
    // attempt to change a branch to a new length, and update the prob. Since we may need to recover the original
    // unchanged probs, we just save those changed one (i.e. keep a copy of what was there before)
    virtual double TestNewBranchLenAt( int threadId, int branch, double lenNew, map<int,set< LineageConfig,LTLinCfg > > &origLinCfgs, bool fSetBrlen );
    virtual void SetLinCfgs(map<int,set< LineageConfig,LTLinCfg > > &linCfgsToSet);	// useful when we want to un-do the effect of the previous tweaking of branch length
    virtual void SetSTBranchLen(int br, double brLen);
    virtual void GetSpeciesTree(MarginalTree &spTree) const { spTree = treeSpecies; }
	virtual int GetTaxaAtLeafST(int snid);
	virtual void GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles);
    static void SetSubsetTaxaSize(int sz);
    
    // create list of subtrees to work with
    void GenSubSTreeSets( map<set<int>,MarginalTree> &mapSubSTrees, map<set<int>,map<int,int> > &mapMapOldTaxaToNew );
    void CreateSubGTree( const set<int> &ssTaxa, map<int,int> &mapMapOldTaxaToNew, PhylogenyTreeBasic &phtreeSub );
    
private:
    
    // get the species tree bracn len
    double GetSTBranchLen(int br) { return treeSpecies.GetEdgeLen(br); }
    
    
    // helper on
    MarginalTree &treeSpecies;
    MarginalTree treeSpeciesUse;
	PhylogenyTreeBasic &treeGene;
    PhylogenyTreeBasic treeGeneUse;
    map<int,int> mapNewNodeToOldNode;
    static int szSubsetTaxaSz;
};

#endif /* defined(____GSTProbComposite__) */
