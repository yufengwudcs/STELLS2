//
//  TreeTriples.h
//  
//
//  Created by Yufeng Wu on 11/7/15.
//  For triple related functions
//

#ifndef ____TreeTriples__
#define ____TreeTriples__

#include <iostream>
#include <set>
#include <vector>
#include <map>
using namespace std;

//***********************************************************************
// implement various methods to build a phylogenetic tree
// assume each leaf has a distinct label as integer

void TestTriples();

//***********************************************************************
// define triples

class PhyloTriple
{
public:
    PhyloTriple(int nid1, int nid2, int nid3, double v) : nidSib1(nid1), nidSib2(nid2), nidOther(nid3), levelConfidence(v) { Order(); }
    PhyloTriple(const PhyloTriple &rhs) : nidSib1(rhs.nidSib1), nidSib2(rhs.nidSib2), nidOther(rhs.nidOther), levelConfidence(rhs.levelConfidence)  {}
    bool operator<(const PhyloTriple &rhs) const;
    int GetSib1() const {return nidSib1; }
    int GetSib2() const {return nidSib2; }
    int GetOther() const { return nidOther;}
    double GetConfidence() const { return levelConfidence; }
    void SetConfidence(double v) { levelConfidence = v; }
    void Append(const PhyloTriple &rhs) { levelConfidence += rhs.levelConfidence; }
    void Dump() const { cout << "[" << levelConfidence << "]"  << "(" << nidSib1 << "," << nidSib2 << ")," << nidOther << "  "; }
    
private:
    void Order() { if( nidSib1 > nidSib2) {int tmp=nidSib2; nidSib2 = nidSib1; nidSib1 = tmp;} }
    
    int nidSib1;        // one of the two siblings and one node on the other side
    int nidSib2;
    int nidOther;
    double levelConfidence; // how confident we are about this triple (between 0 to 1)
};

//***********************************************************************
// define triples related utillites

class PhyloTripleUtils
{
public:
    static void GetLabelFreqFromClades( const multiset< multiset<int> > & cladesDupLabels, map<int,int> &mapTaxonFreqs );
    static void GetAllTriplesFromCladesWithDupLabels(  const multiset< multiset<int> > & cladesDupLabels, const map<int,int> &mapTaxonFreqs, set<PhyloTriple> &setTriplesFound );
    static void CombineTriples( set<PhyloTriple > &setTriplesAddedRes, const set<PhyloTriple> &setTriplesAddeding );
    static void BuildTreeFromCompatTriples( const set<PhyloTriple> &setTriplesCompat, set< set<int> > &treeClades);
    
private:
    static void GetSplitOneSie( const multiset<int> &clade, map<int,int> &mapCladeOneSideFreq );
    static void GetAllTriplesTwoSides( const map<int,int> &mapCladeOneSideFreq1, const map<int,int> &mapCladeOneSideFreq2, const map<int,int> &mapTaxonFreqs, set<PhyloTriple> &setTripleClade );
    static void GetTaxonFromSplit(const map<int,int> &mapClade, set<int> &setTaxon);
    static void GetAllTriples( const map<int,int> &mapCladeOneSideFreq, const map<int,int> &mapTaxonFreqs, set<PhyloTriple> &setTripleClade );
    static double EvalTriple(int sid1, int sid2, int sother, const map<int,int> &mapCladeOneSideFreq, const map<int,int> &mapTaxonFreqs );
    static double EvalTriple2(int sid1, int sid2, int sother, const map<int,int> &mapCladeOneSideFreq1, const map<int,int> &mapCladeOneSideFreq2, const map<int,int> &mapTaxonFreqs );
    static void FindBestSiblings(const set<PhyloTriple> &setTriplesAll, const set<set<int> > &setTaxaGroups, set<int> &taxonG1, set<int> &taxonG2);

};


#endif /* defined(____TreeTriples__) */
