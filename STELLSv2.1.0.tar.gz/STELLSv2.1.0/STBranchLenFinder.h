#ifndef ST_BRANCH_LEN_FINDER_H
#define ST_BRANCH_LEN_FINDER_H

#include "GeneSpeciesTreeProb.h"
#include "lbfgs.h"

// Problem: given a tree topology (with initial branch length), use hill climbing
// to find the best branch length that maximize the likelihood of the given trees

void SetNumThreads(int nt);
int GetNumThreads();
//void ChangeToApproxLikelihood(char *filenamePrestoredProbs);
void SetApproxLikelihood(bool f);
bool IsApproxLikelihood();
void SetCompositeProb(bool fComposite);
void SetSubsetTaxaSize(int sz);
GenericGeneSpeciesTreeProb *CreateGeneTreeProbComp(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene);
GenericGeneSpeciesTreeProb * CreateGeneTreeProbCompNoComposite(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene);

//////////////////////////////////////////////////////////////////////////////////
// Finding branch length that makes the likelihood as large as possible
// note: this is a hill-climbing search only (i.e. not necessarily optimal)

class STBranchLenFinder
{
public:
	STBranchLenFinder( const vector<PhylogenyTreeBasic *> &listGTreePtrs, 
		const MarginalTree &stInit, double minBranchLen, double maxBranchLen );
	~STBranchLenFinder();

    void PreHillClimbBranchLenSearch() { Init(); }
	double HillClimbBranchLen( MarginalTree &treeRes );
    double OptBranchLenByBFGS( MarginalTree &treeRes );
	void SetHillClimbRatioThres(double pthres) { YW_ASSERT_INFO( pthres > 0.0, "Hill climbing ratio must be positive" );  logHillClimbRatio = log(pthres); }
	void SetMultiplictyofTrees(const vector<int> &vecMultis) { listGTreeMultiplicty = vecMultis;}
	void SetBrentMode(bool f) { fBrentMode = f; }
	void SetKnownMaxLikeli(double v) {  knownLikeliOtherTree = v; }
    void SetGeneTreeProbComp( vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinderIn ) { listGSTProbFinder = listGSTProbFinderIn; }
    void SetBranchesToExp( const set<int> &ss) { setBranchesToSet = ss; }
    void SetMaxOptRounds(int maxr) { maxBranchOptRounds = maxr; }
    //void SetNumThreads(int nt) { numThreads = nt; }
    double CalcLogProb();
    void JumpStartBy( STBranchLenFinder *pSTBrFinderPrev );
    
private:
	// implementaiton methods
	void Init();
	void TweakEdgeLen(int branch);
	void OptEdgeLenSearchBrent(int branch, int iterationIndex);
	double TempIncEdgeLen(int branch, double lenNew, vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved );;
	void RestoreSavedCfgs( vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved);
	void UpdateSTBranchLen(int br, double lenNew);
	bool CanSkipEdge(int br);
	bool IsEdgeSkipped(int br);
    int GetMaxOptRound() const { return maxBranchOptRounds; }

	// numerical algorithm
	double Func1DMinBrent( int branch, double ax, double bx, double cx, double tol, double *xmin );
	double EvaluateAt(int br, double lenTest);
    
    // speedup code
    double TempIncEdgeLenMultithread(int branch, double lenNew, vector< map<int,set< LineageConfig,LTLinCfg > > >  &listOrigCfgsSaved);
    double CalcLogProbMultithread();
    
    /////////////////////////////////////////////////////////////////////////////
    // BFGS related
    
    static lbfgsfloatval_t _evaluate(
                                     void *instance,
                                     const lbfgsfloatval_t *x,
                                     lbfgsfloatval_t *g,
                                     const int n,
                                     const lbfgsfloatval_t step
                                     )
    {
        return reinterpret_cast<STBranchLenFinder*>(instance)->evaluate(x, g, n, step);
    }
    
    lbfgsfloatval_t evaluate(
                             const lbfgsfloatval_t *x,
                             lbfgsfloatval_t *g,
                             const int n,
                             const lbfgsfloatval_t step
                             );
    
    static int _progress(
                         void *instance,
                         const lbfgsfloatval_t *x,
                         const lbfgsfloatval_t *g,
                         const lbfgsfloatval_t fx,
                         const lbfgsfloatval_t xnorm,
                         const lbfgsfloatval_t gnorm,
                         const lbfgsfloatval_t step,
                         int n,
                         int k,
                         int ls
                         )
    {
        return reinterpret_cast<STBranchLenFinder*>(instance)->progress(x, g, fx, xnorm, gnorm, step, n, k, ls);
    }
    
    int progress(
                 const lbfgsfloatval_t *x,
                 const lbfgsfloatval_t *g,
                 const lbfgsfloatval_t fx,
                 const lbfgsfloatval_t xnorm,
                 const lbfgsfloatval_t gnorm,
                 const lbfgsfloatval_t step,
                 int n,
                 int k,
                 int ls
                 );
    
    void GetEdgesToOpt( vector<int> &listEdgesOpt ) const;

	// private data
	vector<PhylogenyTreeBasic *> listGTreePtrs;
	vector<int> listGTreeMultiplicty;
	MarginalTree speciesTreeBest;
	vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
	double loglikeliCurBest;
	double minBranchLen;
	double maxBranchLen;
	double gridBranchLen;
	double logHillClimbRatio;
    int maxBranchOptRounds;
	vector<bool> listEdgeCheckFlags;
	bool fBrentMode;
	vector< map<int,set< LineageConfig,LTLinCfg > > >  listOrigCfgsSavedBrentSearch;
	double knownLikeliOtherTree;
    set<int> setBranchesToSet;              // if non-empty: will be the set of edges to find opt lengths
    //map<int,bool> mapEdgeSkipFlag;      // [edge, skipOK] used for checking whether we can skip an edge
    //int numThreads;
};



//////////////////////////////////////////////////////////////////////////////////



#endif
