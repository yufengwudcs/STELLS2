#ifndef SPECIES_TREE_EXPLOER_H
#define SPECIES_TREE_EXPLOER_H

#include "GeneSpeciesTreeProb.h"
#include "UtilsNumerical.h"

class STBranchLenFinder;

// Explore the space of species trees (topology only) 
// it takes some starting trees and then explore the neighbors
// in order to find the best species trees


//////////////////////////////////////////////////////////////////////////////////
// Finding candidate trees from a single tree through NNI

class NNINgbrTreesFinder
{
public:
	// take a single tree and explore its NNI trees
	NNINgbrTreesFinder(PhylogenyTreeBasic &speciesTreeCur);

	// find NNI neighbor trees (represented by Newick)
	void Find(set<string> &setNgbrNWTrees);

private:
	void GetTempChangedTreeAt( TreeNode *tnchange1, TreeNode *tnchange2, string & nwtreetmp );

	PhylogenyTreeBasic &speciesTreeCur;
};


//////////////////////////////////////////////////////////////////////////////////
// NNI search history

class NNISearchHelp
{
public:
    NNISearchHelp();
    void AddNNIRecord( const set<int> &origCluster, const set<int> &clusterByNNI, double logLikeliDiff );
    void AddBeatenCluster( const set<int> &clusterBeaten );
    bool CanSkip( const set<int> &origCluster, const set<int> &clusterByNNI );
    void Dump() const;
    
private:
    map< pair< set<int>, set<int>  >, pair<int,int> > mapSetChangeDiffs;  // how did this NNI change fare previously?
    int minNumDecision;         // at least how many previous experience we should start skipping things
    double minFracSkip;         // how bad has been so we should skip it?
    set< set<int> > setBeatenClusters;          // clsuters that have been known to be inferior to others
};


//////////////////////////////////////////////////////////////////////////////////
// Interface ccode


class SpeciesTreeExplorer
{
public:
	SpeciesTreeExplorer( int numSpecies, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP, TaxaMapper &mapperTaxaIds );
    ~SpeciesTreeExplorer();

	// explore from a set of 
	void ExploreFrom( const vector<string> &listNWTreesInit );
	void SetSearchNgbrTreesFlag(bool f) { fExploreNeighorTrees = f; }
	void SetBrentMode(bool f) { fBrentMode = f; }
	void SetNumNearOptTreesKept(int n) { numNearOptTreesKept = n; }
    void SetOutputTreeHere(bool f) { fOutputTreeHere = f; }
    void SetOutputMoreInfo(bool f) { fOutputMoreInfo = f; }
	void OutputNearOptTrees(string fileNameInit);
    void SetBranchLenRange(double minBL, double maxBL);
    void GetBestSTBranchLens(vector<double> &listBrLens) const { bestSpciesMargTree.GetTreeEdgeLen( listBrLens ); }
    string GetBestInfSpeicesTree() const;
    string GetBestInfSpeicesTreeConv() const;
    void GetBestInfSpeicesMargTreeConv( MarginalTree &treeInf ) const;
    static void SetFastNgbrSearch(bool f);
    static bool IsFastNgbrSearch();

private:
    void ReInit();
	void ExploreFromOneTree(const string &treeNWInit, bool fEvaluateInit, double initLogLikeli);
	double EvaluateOneTree(const string &treeNWInit, const MarginalTree *ptreeOptCurr, MarginalTree *ptreeOpt, bool &fOptFound);
    double EvaluateOneTreeWithLen( MarginalTree &treeCurr );
    double EvaluateOneMargTreeNoBrOpt(MarginalTree &mtree);
    double EvaluateOneMargTreeSubsetBrOpt(MarginalTree &mtree, const set<int> &setBrToOpt);

	int GetNumSpecies() { return numSpecies; }
	double GetCurBestLoglikeli() { return curLoglikeli; }
	double GetDummyWorseLoglikeli() { return  MAX_NEG_DOUBLE_VAL; }
    void PreCreateListGTPComp( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder );
    void PreCreateListGTPCompMultithread( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder );
    bool IsTreeOptBefore(const string &strNW);
    void AnalyzeNNIRes( const MarginalTree &mtreeOrig, const MarginalTree &mtreeNNI, double logLikeliOrig, double logLikeliNNI );
    void AnalyzeBeanTrees( const MarginalTree &mtreeOrig, const MarginalTree &mtreeNNI);
    bool CanSkip(const MarginalTree &mtreeOrig, const MarginalTree &mtreeNNI);
    
    // new test code: simulationiously update topology/branch length
    void ExploreFromOneTreeSimBrTopo( const string &treeNWInit, double initLogLikeli );
    void FindAllGoodEdgePairsToSwap( MarginalTree &mtreeCurBeingOpt, double loglikeliCur, map<double, set< pair<int,int> > > &  mapSetPairEdgesToSwap );
    void ApplyGoodEdgePairsSwap( MarginalTree &mtreeCurBeingOpt, const map<double, set< pair<int,int> > > & mapSetPairEdgesToSwap );
    void SetJumpStartHelper( STBranchLenFinder *pBLFinderToSet );
        
    
	// which gene tree to explore
	int numSpecies;
	vector<PhylogenyTreeBasic *> &listGeneTreePtrs;
	vector<int> listMultiplicity;
	TaxaMapper &mapperTaxaIds;
    
	// tree explore properties
	PhylogenyTreeBasic spciesTreeCur;
	MarginalTree bestSpciesMargTree;
	double curLoglikeli;
    
    // last used branch length optimizer
    STBranchLenFinder *pBLFinderLastUsed;

	// tree exploring info
	int numNewTreesExplored;

	// configuration for search
	double minBranchLenHillClimb;
	double maxBranchLenHillClimb;
	bool fExploreNeighorTrees;
	bool fBrentMode;
	int numNearOptTreesKept;
    bool fOutputTreeHere;
    bool fOutputMoreInfo;
    static bool fFastNgbrSearch;


	// act as a cache to avoid re-evaluation: <tree,prob>
	map<string, pair<double,MarginalTree> > processedNWTrees;
    NNISearchHelp helperNNISearch;      // keep track NNI search history
};

//////////////////////////////////////////////////////////////////////////////////
// Utilities

void ConsInitTreesFromInputTrees( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMultiplicity, TaxaMapper &mapperTaxaIds, vector<string> &vecNWParsTrees, bool fVerbose, int numMDCLevels, bool fMDCMoreClades, int maxNumMDCMoreClades, int numTreeSamples, bool &fDiffTaxaInGTrees );


#endif
