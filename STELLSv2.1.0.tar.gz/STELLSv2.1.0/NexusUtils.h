//
//  NexusUtils.h
//  
//
//  Created by Yufeng Wu on 5/7/15.
//  Read in sequence alignment stored in NEXUS format
//

#ifndef ____NexusUtils__
#define ____NexusUtils__

#include <iostream>
#include <vector>
#include <string>
#include <map>
using namespace std;

//*****************************************************************************
// Alignment

class MSAMatrix
{
public:
    MSAMatrix();
    MSAMatrix(const MSAMatrix &rhs);
    void Init(int numSeqs, int numChars);
    void SetCharAt(int seq, int pos, char ch);
    char GetCharAt(int seq, int pos) const;
    void SetSeqName(int seq, const string &name);
    string GetSeqName(int seq) const;
    int GetNumSeqs() const { return listSeqs.size(); }
    int GetNumChars() const { return listSeqs[0].size(); }
    bool IsEmpty() const { return listSeqs.size() == 0;}
    int GetSeqIndex(const string &name) const;
    void Dump() const;
    
private:
    vector<vector<char> > listSeqs;
    vector<string> listSeqNames;
    map<string,int> mapNameToIndices;
};

//*****************************************************************************
// Nexus file reader into an MSAMatrix

class NexusAlignmentIO
{
public:
    NexusAlignmentIO();
    static void ReadFromFileTrimFormat(const char *filename, vector<MSAMatrix> &listMSAs);
};


#endif /* defined(____NexusUtils__) */
