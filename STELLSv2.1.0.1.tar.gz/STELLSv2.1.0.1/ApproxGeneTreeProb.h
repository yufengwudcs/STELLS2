//
//  ApproxGeneTreeProb.h
//  
//
//  Created by Yufeng Wu on 4/14/16.
//  Approximate gene tree probability by dropping the coalescent coefficient terms
//  Designed to handle larger number of trees

#ifndef ____ApproxGeneTreeProb__
#define ____ApproxGeneTreeProb__

#include "GeneSpeciesTreeProb.h"
#include <cmath>

///////////////////////////////////////////////////////////////////////////////////////
void AGTPSetVerbose(bool f);

///////////////////////////////////////////////////////////////////////////////////////
// for benchmark run time

class ApproxGTPStats
{
public:
    static ApproxGTPStats &Instance();
    void DumpStats() const;
    void RecordProbComputeStart();
    void RecordProbComputeEnd();
    void RecordMaxACSize(int szACList);
    void RecordBranchLenOpt();
    
private:
    ApproxGTPStats();
    
    vector<long> listProbCalcTimeStart;
    vector<long> listProbCalcTimeEnd;
    int maxSzACList;
    int brOptNums;
};


///////////////////////////////////////////////////////////////////////////////////////
// supporting multi-threading

class ApproxGTPCache
{
public:
    static ApproxGTPCache &Instance();
    void Init();
    map< pair<int,int>, double> &GetdbValCache(int tid);
    map< pair<int,int>, double> &GetwbValCache(int tid);
    map< pair<pair<int,int>,int>, double > &GetBrProbCache(int tid);
    
private:
    ApproxGTPCache();
    ~ApproxGTPCache();

    vector<map< pair<int,int>, double> *> listMapdbValsThreadSafe;
    vector<map< pair<int,int>, double> * > listMapwbValsThreadSafe;
    vector<map< pair<pair<int,int>,int>, double > *> listCacheBranchProbThreadSafe;
};

///////////////////////////////////////////////////////////////////////////////////////
// AC history: how each config gets its prob

class ApproxGeneTreeProbAncConfig;
class ApproxGeneTreeProbHelper;


// context for prob-recomputing
class AGTPACRecomputeContext
{
public:
    AGTPACRecomputeContext( ApproxGeneTreeProbHelper *pAGTPHelperIn, const set<int> &branchBeingChangedIn );
    // should we recompute the coal coefficient?
    bool IsCoalCoeffFresh( const ApproxGeneTreeProbAncConfig *pCfgBeingCoal );
    // recompute the coalescent coefficient
    double RecomputeCoalCoeff( const ApproxGeneTreeProbAncConfig *pCfgBeingCoal, const ApproxGeneTreeProbAncConfig *pCfgDest );
    
private:
    ApproxGeneTreeProbHelper *pAGTPHelper;
    set<int> branchBeingChanged;
};


// generic history
class ApproxGeneTreeProbAncConfigHist
{
public:
    virtual ~ApproxGeneTreeProbAncConfigHist() {}
    // recompute the probability based on history
    virtual double Recompute(AGTPACRecomputeContext &context, const ApproxGeneTreeProbAncConfig *pCfgDest) = 0;
    virtual ApproxGeneTreeProbAncConfigHist *Copy() = 0;
    virtual void MergeWith( const ApproxGeneTreeProbAncConfigHist &rhs ) = 0;
    virtual void Dump() const = 0;
    //virtual void AttachToCfg( ApproxGeneTreeProbAncConfig *pCfgDestIn ) {}
};

// obtained from another AC (coalesced at the same branch)
class ApproxGeneTreeProbAncConfigHistCoal : public ApproxGeneTreeProbAncConfigHist
{
public:
    ApproxGeneTreeProbAncConfigHistCoal() {}
    virtual double Recompute(AGTPACRecomputeContext &context, const ApproxGeneTreeProbAncConfig *pCfgDest);
    virtual ApproxGeneTreeProbAncConfigHist *Copy();
    virtual void MergeWith( const ApproxGeneTreeProbAncConfigHist &rhs );
    virtual void Dump() const;
    void AddDependent( const ApproxGeneTreeProbAncConfig *pCfgDepend, double coalCoeff );
    //virtual void AttachToCfg( ApproxGeneTreeProbAncConfig *pCfgDestIn ) { pCfgDest = pCfgDestIn; }
    
private:
    //ApproxGeneTreeProbAncConfig *pCfgDest;
    vector< pair<const ApproxGeneTreeProbAncConfig *, double> > listCfgsCoalandCoeffs;
};


// obtained by merging two ACs (no coalescent)
class ApproxGeneTreeProbAncConfigHistMerge : public ApproxGeneTreeProbAncConfigHist
{
public:
    ApproxGeneTreeProbAncConfigHistMerge() {}
    virtual double Recompute(AGTPACRecomputeContext &context, const ApproxGeneTreeProbAncConfig *pCfgDest);
    virtual ApproxGeneTreeProbAncConfigHist *Copy();
    virtual void MergeWith( const ApproxGeneTreeProbAncConfigHist &rhs );
    virtual void Dump() const;
    void AddDependent(const ApproxGeneTreeProbAncConfig *pCfg1, const ApproxGeneTreeProbAncConfig *pCfg2 );
    
private:
    vector< pair< const ApproxGeneTreeProbAncConfig *, const ApproxGeneTreeProbAncConfig * > > listCfgsMergePairs;
};


    
//////////////////////////////////////////////////////////////////////////////////
// Approx gene tree prob AC

class ApproxGeneTreeProbHelper;

class ApproxGeneTreeProbAncConfig
{
public:
    ApproxGeneTreeProbAncConfig(int nodeSTIn);
    ApproxGeneTreeProbAncConfig(int nodeSTIn, const vector<int> &listLinNumsForClustersIn, double probCfgIn, bool fLogMode);
    ApproxGeneTreeProbAncConfig(const ApproxGeneTreeProbAncConfig &rhs);
    ~ApproxGeneTreeProbAncConfig();
    void operator=(const ApproxGeneTreeProbAncConfig &rhs);
    bool operator<(const ApproxGeneTreeProbAncConfig &rhs) const;
    void SetProb(double prob);
    double GetProb() const { return this->probCfg; }
    void SetLogProb(double logprob);
    double GetLogProb() const { return logprobCfg; }
    void SetNodeId(int nid) { nodeST = nid; }
    int GetNodeId() const { return nodeST; }
    void Clear();
    void AddLinCluster( int numAlleles );
    void AddLinClusterAt(int pos, int numAlleles);
    const vector<int> &GetClusCounts() const { return this->listLinNumsForClusters; }
    void FindCoalsableCfgsWithin( ApproxGeneTreeProbHelper &helper, double lenBranch, set< ApproxGeneTreeProbAncConfig > &setCoalCfgs ) const;
    void FindCoalsableCfgsOneEvent( vector<ApproxGeneTreeProbAncConfig *> &listCoalCfgsOneEvt ) const;
    static void FindCoalsableCfgsFrom( ApproxGeneTreeProbHelper &helper, double lenBranch, const set< const ApproxGeneTreeProbAncConfig *> &setActiveCoalCfgs, const set< ApproxGeneTreeProbAncConfig > &setCoalCfgsFoundBefore, set< ApproxGeneTreeProbAncConfig > &setCoalCfgs );
    int GetTotNumLins() const;
    void GetLinCountsBase0( vector<int> &listCounts0 ) const { for(int i=0; i<(int)listLinNumsForClusters.size(); ++i) { listCounts0.push_back( listLinNumsForClusters[i]-1 ); } }
    void AddHist( ApproxGeneTreeProbAncConfigHist *phist);
    ApproxGeneTreeProbAncConfigHist *GetHist() const { return pAGTPACHist; }
    void Dump() const;
    static void SetCountingMode(bool f);
    static bool IsCountingMode();
    
private:
    //void FindCoalsableCfgsOneEvent( set<ApproxGeneTreeProbAncConfig> &setCoalCfgsOneEvt ) const;
    void OffsetLinNumAt( int pos, int offset ) { listLinNumsForClusters[pos] += offset; this->totLins += offset; }
    
    // number of lineages per cluster
    int nodeST;
    vector<int> listLinNumsForClusters;
    double probCfg;
    double logprobCfg;
    int totLins;
    ApproxGeneTreeProbAncConfigHist *pAGTPACHist;
    static bool fOneClusterOnly;
};

//////////////////////////////////////////////////////////////////////////////////
// Approx gene tree prob clustser

class ApproxGeneTreeProbCluster
{
public:
    ApproxGeneTreeProbCluster(TreeNode *proot) : pClusterRoot(proot) {}
    ApproxGeneTreeProbCluster( const ApproxGeneTreeProbCluster &rhs) : pClusterRoot(rhs.pClusterRoot) {}
    
    // the size of this cluster
    //int GetSize() const;
    TreeNode *GetClusterRoot() const { return pClusterRoot; }
    int GetClusterSize() const
    {
        set<TreeNode *> setDescendents;
        pClusterRoot->GetAllLeavesUnder(setDescendents);
        return setDescendents.size();
    }
    
private:
    TreeNode *pClusterRoot;
};

//////////////////////////////////////////////////////////////////////////////////
// Approx gene tree prob helper

class ApproxGeneTreeProbHelper
{
public:
    ApproxGeneTreeProbHelper( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn );
    void GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles);
    void FormLinConfig( int snid, const vector<int> &linsGT, ApproxGeneTreeProbAncConfig &linConfig ) const;
	void FormLinConfig( int snid, const ApproxGeneTreeProbAncConfig &linsGT1, const ApproxGeneTreeProbAncConfig &linsGT2, ApproxGeneTreeProbAncConfig &linConfig ) const;
    void ClearBranchLenCache();
    void FastCollectAncConfig( int nodeId, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew );
	void FastCollectAncConfig( double lenOrig, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew );
    void FastCollectAncConfigHeu( int nodeId, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew );
    void FastCollectAncConfigHeu2( int nodeId, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew );
    double CalcCoalCoeffForTwoCfg( const ApproxGeneTreeProbAncConfig &linCfg1, const ApproxGeneTreeProbAncConfig &linCfg2 ) const;
    double CalcCoalCoeffForTwoCfg( double lenBranch, const ApproxGeneTreeProbAncConfig &linCfg1, const ApproxGeneTreeProbAncConfig &linCfg2 ) const;
    double CalcdbVal(int ub, int cb) const;
    double CalcwbVal( int ub, int cb ) const;
    //double CalcBranchFactorAtFake(int numDupEvts, int numTotLins, int numActiveLins) const;
    int GetTaxaAtLeafST(int snid);
    void GetLeafLinCountsAtSTNode(int nid, vector<int> &listCounts) const;
    int GetThreadId() const { return threadId; }
    void SetThreadId(int tid) { threadId = tid; }
    double CalcCoalProbBranch( int u, int v, double len ) const;
    void ConsLinearArrayOfDescCfgsToParCfgsAt(int nodeST, const set< ApproxGeneTreeProbAncConfig > &cfgDescList, vector<double> &vecProbCfgs) const;
    void ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad(int nodeST, const set< ApproxGeneTreeProbAncConfig > &cfgDescList, vector<double> &vecProbCfgs) const;
    void ConsLinearArrayOfTwoDescCfgsToParCfgsAt(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const;
    //const set<ApproxGeneTreeProbAncConfig> * FindCoalscedCfgsFrom( const ApproxGeneTreeProbAncConfig &cfgToCoal ) const;
    //void AddCoalescedCfgsFrom( const ApproxGeneTreeProbAncConfig &cfgToCoal, set<ApproxGeneTreeProbAncConfig> &setCoalCfgs );
    static void SetMaxConvolvePairsDirect(int valNew);
    const vector<int> &GetCfgBoundsAt(int nodeST) const { return listSTLinClusterSizeList[nodeST]; }
    const vector<int> &GetCfgLowBoundsAt(int nodeST) const { return listSTLinClusterSizeListMin[nodeST]; }
    const vector<int> &GetCfgNetCountsAt(int nodeST) const { return listSTLinClusterSizeListNet[nodeST]; }
    int GetAncClusIndexForClusIndex(int stNode, int clusIndex) const;
    int GetNumAncClusters(int stNode) const { return listSTLinClusterList[stNode].size(); }
    MarginalTree &GetSpeciesTree() const { return treeSpecies; }
    void ConsDescCfgsToParCfgList(int nodeST, const set< ApproxGeneTreeProbAncConfig > &cfgDescList, set< ApproxGeneTreeProbAncConfig > &cfgParList) const;
    
private:
    void Init();
    void ConsClusterInfo();
    void GetGeneAllelesForSpeciesSet( const set<int> &setTaxa, set<int> &geneAlleles);
    void GetNodesForIds(const set<int> &nids, set<TreeNode *> &setNodes) const;
    void CombineTwoACs( int nid, const ApproxGeneTreeProbAncConfig &linsGT1, const ApproxGeneTreeProbAncConfig &linsGT2, ApproxGeneTreeProbAncConfig &linConfig ) const;
    void ConvDescACToParAC( int nid, const ApproxGeneTreeProbAncConfig &linsGT, ApproxGeneTreeProbAncConfig &linConfig ) const;
    bool IsNodeDesc( TreeNode *nodeAnc, TreeNode *nodeDesc ) const;
    int FindClusterFor( int nidDest, TreeNode *pRootDesc ) const;
    int ConvDistToGrid(double dist) const;
    double ConvGridToDist(int grid) const;
    int GetNumCfgsAt(int nodeST) const;
    int GetNumCfgsAtDirect(int nodeST) const;
    //void ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const;
    void ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect2(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const;
    //void ConsLinearArrayOfTwoDescCfgsToParCfgsAtFFT(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const;
    int GetNumSubCluster( int stNode, const ApproxGeneTreeProbCluster &clus) const;
    static int CalcExpectedCoalLinNum(int numOrig, double timeCoal );
    static int GetRangeExpCoal();
    static bool IsCfgTooManyCoalLins( const ApproxGeneTreeProbAncConfig &cfgCoaled, const ApproxGeneTreeProbAncConfig &cfgOrig, double tLen );
    static bool IsCfgTooFewCoalLins( const ApproxGeneTreeProbAncConfig &cfgCoaled, const ApproxGeneTreeProbAncConfig &cfgOrig, double tLen );

    // input ST/GT trees
    MarginalTree &treeSpecies;
	PhylogenyTreeBasic &treeGene;
    
    // for each species tree branch (bottom), the list of clusters; listed in the order of species tree branch
    vector< vector<ApproxGeneTreeProbCluster> > listSTLinClusterList;
    
    // for each species tree branch, max/min number of lineages for each cluster
    vector< vector<int> > listSTLinClusterSizeList;
    vector< vector<int> > listSTLinClusterSizeListMin;
    vector< vector<int> > listSTLinClusterSizeListNet;     // = ub-lb
    
    // quick find cluster based on its root
    vector< map< TreeNode *, int > > listSTLinClusterRootMap;
    
    // quick find absorbed child root
    vector< map< TreeNode *, int> > listAborbedTreeNodes;
    
    // quicking checking whether a node is ancestral to another node
    map<TreeNode *, set<TreeNode *> > mapGTNodeDesc;
    
    // useful info
    map<int, TreeNode*> mapIdNode;				// in GT, which id is for which TreeNode
    
    // various cache to speedup
    map<int, set<int> > mapTaxonGids;           // for each taxon, the set of gene lineages
    map<pair<int,TreeNode *>, int> mapCLusterRoots;  // for each node at a species tree branch, its new cluster root
    vector<int> listNumCfgsAtStNodes;           // at each ST node, the number of configs
    
    // store coalesced cfgs for faster processing
    //map<ApproxGeneTreeProbAncConfig, set<ApproxGeneTreeProbAncConfig> > mapCoalesceCfgs;
    
    // finally thread id
    int threadId;
    double distFactor;                             // when converting distance into integer, this is the factor to multiply
    double minFracInProb;                           // decide whether to continue exploring from a specific AC; it has to contribute to somewhere more than before
    int maxRoundsPerAC;                             // how many rounds an AC is allowed to find ancestral AC
    static int maxNumConvolvePairsDirect;                // for small problem, use direct convolution
};


//////////////////////////////////////////////////////////////////////////////////
// Approx species tree AC store

// store the LineageConfigs
class ApproxLineageConfigSore;
//typedef map<int, set< LineageConfig,LTLinCfg > >  MAP_NUMLINS_LINS;
//typedef map<int, MAP_NUMLINS_LINS >  MAP_ID_LINS;


class ApproxLinCfgSoreIterator
{
public:
	ApproxLinCfgSoreIterator( int nodeId, ApproxLineageConfigSore &lcStore );
	void Init();
	bool IsDone();
	void Next();
	const ApproxGeneTreeProbAncConfig &GetLinCfg() { return *it; }
    
private:
	int nodeId;
	ApproxLineageConfigSore &lcStore;
	set< ApproxGeneTreeProbAncConfig > :: iterator it;
};

class ApproxLineageConfigSore
{
	friend class ApproxLinCfgSoreIterator;
public:
	ApproxLineageConfigSore(MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene, ApproxGeneTreeProbHelper &gstHelper);
    ApproxLineageConfigSore(const ApproxLineageConfigSore &rhs);
    
	// add a record of LinCfg: for the purpose of computing the probablity, need to know which
	// LinCfg it derives from. For leaves, we also support a plain version: with no probility
	void AddLinCfg( int nodeId, const ApproxGeneTreeProbAncConfig &lcNew );
	int GetNumLinCfgsAt(int nodeId);
	double CalcTotProbAt(int nodeId);
	void DumpConfigsAt(int nodeId);
	set< ApproxGeneTreeProbAncConfig > & GetLCSetAt(int node)
	{
        //cout << "GetLCSetAt: node: " << node << endl;
        if( statesDepot.find(node) == statesDepot.end() )
        {
            cout << "FATAL ERROR: this node is not found in statesDepot: " << node  << ". Possibly caused by numerical underflow."<< endl;
        }
		YW_ASSERT_INFO( statesDepot.find(node) != statesDepot.end(), "Fail to find1.2" );
		return statesDepot[node];
	}
    set< ApproxGeneTreeProbAncConfig > & GetLCSetUpperAt(int node)
	{
        //cout << "GetLCSetAt: node: " << node << endl;
        if( statesDepotUpper.find(node) == statesDepotUpper.end() )
        {
            cout << "FATAL ERROR: this node is not found in statesDepotUpper: " << node  << ". Possibly caused by numerical underflow."<< endl;
        }
		YW_ASSERT_INFO( statesDepotUpper.find(node) != statesDepotUpper.end(), "Fail to find1.3" );
		return statesDepotUpper[node];
	}
	void SetLCSetAt(int node, set< ApproxGeneTreeProbAncConfig > &setCfgs)
	{
		if( statesDepot.find(node) == statesDepot.end() )
		{
			statesDepot.insert( map<int, set< ApproxGeneTreeProbAncConfig > > :: value_type( node, setCfgs )  );
		}
		else
		{
			statesDepot[node] = setCfgs;
		}
	}
    void SetLCSetUpperAt(int node, set< ApproxGeneTreeProbAncConfig > &setCfgs)
	{
		if( statesDepotUpper.find(node) == statesDepotUpper.end() )
		{
			statesDepotUpper.insert( map<int, set< ApproxGeneTreeProbAncConfig > > :: value_type( node, setCfgs )  );
		}
		else
		{
			statesDepotUpper[node] = setCfgs;
		}
	}
	//void SetLinCfgProbAt(int nodeId, ApproxGeneTreeProbAncConfig &lcNew, double probNew);
    bool IsComputedBefore(int nodeId) const { return statesDepot.find(nodeId) != statesDepot.end() && statesDepot.find(nodeId)->second.size() > 0 ; }
    bool IsUpperComputedBefore(int nodeId) const { return statesDepotUpper.find(nodeId) != statesDepotUpper.end() && statesDepotUpper.find(nodeId)->second.size() > 0 ; }
	void Reset() { statesDepot.clear(); statesDepotUpper.clear();  }
    void ResetUpperAt(int node)
    {
        statesDepotUpper.erase(node);
    }
	void ResetAt( int node )
	{
		statesDepot.erase(node);
        statesDepotUpper.erase(node);
		YW_ASSERT_INFO( statesDepot.find(node) == statesDepot.end(), "Error in ResetAt" );
	}
    void ResetAtMulti(const set<int> &setNodes);
    void EqualCfgsTo(const ApproxLineageConfigSore &rhs);       // caution: only meant to be identical topology
    void CopyFromAtSTNode( int stNode, ApproxLineageConfigSore &linCfgStorePrev, int stNodePrev  );
    static void SetMaxLinCfgNum(int num);
    static void TrimSetCfgs(set<ApproxGeneTreeProbAncConfig> &setCfgsToTrim);
    
private:
	void Prune(int nodeId);
    
    
	MarginalTree &treeSpecies;
	PhylogenyTreeBasic &treeGene;
	ApproxGeneTreeProbHelper &gstHelper;
	map<int, set< ApproxGeneTreeProbAncConfig > > statesDepot;
    map<int, set< ApproxGeneTreeProbAncConfig > > statesDepotUpper;
    static int maxLinCfgNum;
};

//////////////////////////////////////////////////////////////////////////////////
// Approx species tree prob

class ApproxGeneTreeProb : public GenericGeneSpeciesTreeProb
{
public:
    ApproxGeneTreeProb( MarginalTree &treeSpecies, PhylogenyTreeBasic &treeGene );
    virtual ~ApproxGeneTreeProb();
    virtual double CalcProb();
    virtual double CalcLogProb();
    // attempt to change a branch to a new length, and update the prob. Since we may need to recover the original
    // unchanged probs, we just save those changed one (i.e. keep a copy of what was there before)
    virtual double TestNewBranchLenAt(int threadId, int branch, double lenNew, map<int,set< LineageConfig,LTLinCfg > > &origLinCfgs, bool fSetBrlen );
    virtual void SetLinCfgs(map<int,set< LineageConfig,LTLinCfg > > &linCfgsToSet);	// useful when we want to un-do the effect of the previous tweaking of branch length
    virtual void SetSTBranchLen(int br, double brLen);
    virtual void GetSpeciesTree(MarginalTree &spTree) const { spTree = treeSpecies; }
	virtual int GetTaxaAtLeafST(int snid) { return pgstHelper->GetTaxaAtLeafST(snid); }
	virtual void GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles);
    virtual void JumpStartAtSTNodes( GenericGeneSpeciesTreeProb *pProbPrev, const set<int> &setSTNodesToInit,  map<int,int> &mapSTToPrevST );
    virtual void SetThreadId(int tid) { pgstHelper->SetThreadId(tid); }

private:
    // get the species tree bracn len
    double GetSTBranchLen(int br) { return treeSpecies.GetEdgeLen(br); }
    void OnBrLenUpdate(int brST);
    void ReInit();
    void InitBranchConversion();
    bool IsRecomputeMode() const;
    double RecalculateProb();
    
    
    // helper on
    MarginalTree &treeSpecies;
    MarginalTree treeSpeciesUse;
	PhylogenyTreeBasic &treeGene;
    PhylogenyTreeBasic treeGeneUse;
    ApproxGeneTreeProbHelper *pgstHelper;
    ApproxLineageConfigSore *pstoreLinCfgs;
    map<int,int> mapNewNodeToOldNode;
    map<int,int> mapSTOldNodeToNewNode;
    set<int> setBrLenChanged;
    
    // auxilary
    //ApproxLineageConfigSore *pstoreLinCfgsBackup;
    //bool fRestoreMode;      // are we restoring old prob (so don't update prob)
};




#endif /* defined(____ApproxGeneTreeProb__) */
