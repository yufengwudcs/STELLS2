//
//  FastSpeciesTreeBuilder.h
//  
//
//  Created by Yufeng Wu on 3/27/16.
//
//

#ifndef ____FastSpeciesTreeBuilder__
#define ____FastSpeciesTreeBuilder__

#include "SpeciesTreeExplorer.h"

//////////////////////////////////////////////////////////////////////////////////
// Evaluate clusters of gene trees

void TestFSTIClusterEval( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP  );
void TestTriplesInf( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP, TaxaMapper &mapperTaxaIds );
void TestTriplesFromTrees( vector<string> &listTreeNWs, int numTaxa, TaxaMapper &mapperTaxaIds );

//////////////////////////////////////////////////////////////////////////////////
// Sibling analysis

class FSTISiblingPair
{
public:
    FSTISiblingPair( int tid1, int tid2, double len1, double len2 ) : taxaId1(tid1), taxaId2(tid2), brLen1(len1), brLen2(len2) {}
    FSTISiblingPair(const FSTISiblingPair &rhs) : taxaId1(rhs.taxaId1), taxaId2(rhs.taxaId2), brLen1(rhs.brLen1), brLen2(rhs.brLen2) {}
    //bool operator<(const FSTISiblingPair &rhs) const;
    int GetTaxon1() const { return taxaId1; }
    int GetTaxon2() const { return taxaId2; }
    double GetTaxon1Dist() const { return brLen1; }
    double GetTaxon2Dist() const { return brLen2; }
    bool IsSame( const FSTISiblingPair &rhs ) const;
    bool HasSameTaxa( int t1, int t2) const;
    static bool FindBestSibAlsoIn2ndList( const set<pair<int,int> > &listSibPairs1, const vector<FSTISiblingPair> &listSibPairs2, pair<int,int> &pairToChoose );
    
private:
    int taxaId1;
    int taxaId2;
    double brLen1;
    double brLen2;
};


//////////////////////////////////////////////////////////////////////////////////
// Sibling analysis

class FSTISiblingAnalyzer
{
public:
    FSTISiblingAnalyzer();
    void AnalyzeTree( MarginalTree &mtreeSub );
    bool FindTrustedSibPairs( set<pair<int,int> > &setSibPairs ) const;
    void Dump() const;
    
private:
    map< pair<int,int>, pair<int,int> > mapSibPosNegCounts;
    double minTrustSibRatio;
};



//////////////////////////////////////////////////////////////////////////////////
// Found clusters structure (tree like)

class FSTIClusterEvalCluster
{
public:
    FSTIClusterEvalCluster(const set<int> &clusterIn);
    ~FSTIClusterEvalCluster();
    void AddChild( FSTIClusterEvalCluster *pChild );
    void GetAllClustersBottomup( vector< set<int> > &listClusters );
    void SetScore(int s) { score = s; }
    int GetScore() const { return score; }
    const set<int> *GetClusPtr() const { return &cluster; }
    bool IsGood() const { return score > 0; }
    void Dump() const;
    
private:
    set<int> cluster;
    int score;
    vector< FSTIClusterEvalCluster * > listChildren;
};

//////////////////////////////////////////////////////////////////////////////////
// Evaluate clusters of gene trees

class FSTIClusterEval
{
public:
    FSTIClusterEval();
    void EvaluateTrees( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP );
    FSTIClusterEvalCluster * FindClusterPartitions( const set<int> &cluster ) const;
    void Dump() const;
    
private:
    void CheckSingleTree( PhylogenyTreeBasic *pGTree, int wt );
    void AnalyzeClusters();
    void AnalyzeSingleCluster( const set<int> &cluster );
    bool FindClusterSubPartitions( int maxNumParts, const set<int> &cluster, vector< FSTIClusterEvalCluster *> &listClusInfoSoFar, int listPosStart, vector< FSTIClusterEvalCluster *> &listPartitions, int &scoreRes ) const;
    void EvaluateClustersInfo();
    int EvaluateClustersInfoFromListFor( const set<int> &cluster, vector<FSTIClusterEvalCluster *> &listClusInfoSoFar, vector<FSTIClusterEvalCluster *> &listClusChildren );
    
    map< set<int>, int> mapClusterOcc;
    map< set<int>, int> mapClusterSupport;
    map< int, set< const set< int > * > > mapClusterSupportInv;
    map< int, set<const set<int> *> > mapLeafInClusters;
    map< set<int>, FSTIClusterEvalCluster * > mapClusterToClusInfo;
    int maxNumParts;
};

//////////////////////////////////////////////////////////////////////////////////
// how to collapse subtrees

class STSiblingInfo
{
public:
    STSiblingInfo( MarginalTree *pSTreeIn, int nodePos1In, int nodePos2In );
    STSiblingInfo(const STSiblingInfo &rhs);
    bool operator<(const STSiblingInfo &rhs);
    void GetSubtree( set<int> &stree );
    MarginalTree *GetMargTree() const { return pSTree; }
    int GetPos1() const { return nodePos1; }
    int GetPos2() const { return nodePos2; }
    int GetParPos() const;
    
private:
    MarginalTree *pSTree;
    int nodePos1;
    int nodePos2;
} ;

//////////////////////////////////////////////////////////////////////////////////
// What trees have been inferred before

class FastSpeciesTreeInfHist
{
public:
    FastSpeciesTreeInfHist(int numSpeciesIn);
    FastSpeciesTreeInfHist( const FastSpeciesTreeInfHist &rhs );
    void AddInfTree( const set<int> &setTaxa, MarginalTree &mtree );
    void ExpandContractedSubtrees( MarginalTree &margStree );
    //void FindPairToMerge( const set<int> &setTaxa, const string &strTreeInit, int maxSzSubtree, vector<pair<int,int> > &listPairsToMerge );
    void FindSubtreesToMergeRand(const set<int> &setTaxa, int maxSzSubtree, int numAlreadyMerged, vector< set<int> > &listMergedSTs);
    int MergePair( pair<int,int> &pairToMerge, const pair<double,double> &htsTwoSubchild);
    void MergeSetofTaxa(const set<int> &setTaxa, const pair<double,double> &htsTwoSubchild);
    void CreateTaxaMap( const set<int> &setTaxa, map<int,int> &mapTaxaToMerged );
    int GetNumMergedPairsWithin(const set<int> &setTaxa) const;
    void FindEnclosedSubtrees( const set<int> &setTaxa, set<int> &setTaxaSub1, set<int> &setTaxaSub2  ) const;
    void Dump() const;
    MarginalTree *GetMargTreeForTaxa(const set<int> &setTaxa) const;
    void FindMergableSubtreesFrom( MarginalTree *ptreeCur, const set<int> &setTaxaToUse, vector< STSiblingInfo > &listSubtreesToMerge );
    void GetMergedLinsFrom( const set<int> &setIds, set<int> &setMergedLins ) const;
    void GetMergedSubtrees( const set<int> &setIds, set< set<int> > &setSubtrees ) const;
    void AccumSubtreeDistInfo(const set<int> &setIds, pair<int,double> &pairOccTotDist) const;
    
private:
    void AnalyzeTree( const set<int> &setTaxa, MarginalTree &mtree );
    int FindAncestralLin( int linId );
    void FindUnmergedLins( const set<int> &setTaxa, set<int> &setTaxaUnmerged );
    void GetRecentTree(const set<int> &setTaxa, vector<MarginalTree *> &listMargTrees );
    
    
    map< set<int>, MarginalTree> mapSubsetInfTrees;
    map< pair<int,int>, pair<int,int> > mapPairTaxaSibFreq;
    map< pair<int,int>, pair<int,pair<double,double> > > mapPairTaxaSibLens;
    map<int, pair<int,int> > mapMergedTaxa;
    map<int, pair<int,double> > mapMergedTaxaParent;    // incl. length of the branch
    set< pair<int,int> > setMergedPairs;                // what taxa has been merged
    map< set<int>, int > mapSetofTaxaToId;              // for each merged set of taxa, there is an associated id
    map<int, set<int> > mapIdToSetofTaxa;
    map<set<int>, pair<int,double> > mapSubTrTaxaSibFreq;   // number of times this subtree appeared and the length
    int numSpecies;
    int idMergedNext;
};


//////////////////////////////////////////////////////////////////////////////////
// Fast inference of species tree

class FastSpeciesTreeInference
{
public:
	FastSpeciesTreeInference( int numSpecies, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP, TaxaMapper &mapperTaxaIds, const string &strTreeInit );
    ~FastSpeciesTreeInference();
    void InferTriples();
    string GetInferredTreeNewick() const { return strTreeInferred; }
    bool InfConverge();
    void ConfigSearch( int maxSzSubtreeIn, int maxGTreeSzIn, int maxNumIter, int szConsensusPanelIn ) { maxSzSubtree = maxSzSubtreeIn; maxGTreeSz = maxGTreeSzIn; maxNumIterations = maxNumIter;szConsensusPanel = szConsensusPanelIn; }
    static PhylogenyTreeBasic *CreateSubGenetreeFor( const set<int> &setTaxa, PhylogenyTreeBasic *pgtree );
    
private:
    int GetNumSpecies() const { return numSpecies; }
    void BuildInitST(MarginalTree &initST);
    void GetSubtreesBottomUp( MarginalTree &mtree, vector<set<int> > &listSubtrees );
    void InfSubST( FastSpeciesTreeInfHist &histSTInf, const set<int> &setTaxa, MarginalTree &mtreeSub );
    void CreateSubGenetrees( const set<int> &setTaxa, vector<PhylogenyTreeBasic *> &listSubgtrees );
    void RelabelGenetree( PhylogenyTreeBasic *pgtree, FastSpeciesTreeInfHist &histSTInf, bool fUpdateUserLbl );
    void ReduceSubtrees( vector<PhylogenyTreeBasic *> &listSubgtrees );
    bool InfSiblingPairs( const set<int> &setTaxa, FastSpeciesTreeInfHist &histSTInf, vector<FSTISiblingPair> &setSibPairs, map< set<int>, MarginalTree > &mapSubsetInfTrees );
    bool InfSiblingPairsMDC( int mdcLevel, const set<int> &setTaxa, FastSpeciesTreeInfHist &histSTInf, vector<FSTISiblingPair> &setSibPairs);
    void CreateSubGenetreesForMergedTaxa( FastSpeciesTreeInfHist &histSTInf, vector<PhylogenyTreeBasic *> &listSubgtrees );
    static void EstSibPairDist( map< set<int>, MarginalTree > &mapSubsetInfTrees, int sibId1, int sibId2, double &dist1, double &dist2 );
    
    // inference info
	int numSpecies;
	vector<PhylogenyTreeBasic *> &listGeneTreePtrs;
	vector<int> listMultiplicity;
	TaxaMapper &mapperTaxaIds;
    string strTreeInit;
    string strTreeInferred;
    
    // inference settings
    int minSzSubtree;       // bypass subtrees that are too small
    int maxSzSubtree;       // largest possible subtrees to infer
    int maxIdentSubtreeSz;  // max identical subtree size
    int maxGTreeSz;         // how many gene lineages are allowed (must be at least maxSzSubtree)
    int maxNumIterations;   // how many rounds to allow
    int szConsensusPanel;   // when we need to contract subtrees, the size of panel members to use (by default, it is one, i.e. not using panels)
};


#endif /* defined(____FastSpeciesTreeBuilder__) */
