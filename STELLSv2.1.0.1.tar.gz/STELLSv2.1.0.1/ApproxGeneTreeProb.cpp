//
//  ApproxGeneTreeProb.cpp
//  
//
//  Created by Yufeng Wu on 4/14/16.
//
//

#include "ApproxGeneTreeProb.h"
#include "UtilsNumerical.h"
#include "Utils4.h"
#include "pthread.h"
#include <cmath>
#include <ctime>

extern int GetNumThreads();

static bool fVerboseMode = false;
static bool fVerboseModeExtern = false;
static bool ffastSTELLSProbComputeWarningFlag = false;
static int numBranchLenDigit = 6;

void AGTPSetVerbose(bool f)
{
    fVerboseModeExtern = f;
    //fVerboseMode = f;
}

#define LOG_CFG_PROB 1

///////////////////////////////////////////////////////////////////////////////////////
// supporting multi-threading

ApproxGTPCache & ApproxGTPCache :: Instance()
{
    //
    static ApproxGTPCache inst;
    return inst;
}

ApproxGTPCache :: ApproxGTPCache()
{
    //
    Init();
}
ApproxGTPCache :: ~ApproxGTPCache()
{
    //
    for(int i=0; i<(int)listMapdbValsThreadSafe.size(); ++i )
    {
        delete listMapdbValsThreadSafe[i];
    }
    for(int i=0; i<(int)listMapwbValsThreadSafe.size(); ++i)
    {
        delete listMapwbValsThreadSafe[i];
    }
    for(int i=0; i<(int)listCacheBranchProbThreadSafe.size(); ++i)
    {
        delete listCacheBranchProbThreadSafe[i];
    }
}

void ApproxGTPCache :: Init()
{
    //
    int numThreads = GetNumThreads();
//cout << "ApproxGTPCache Init: Number of threads to use: " << numThreads << endl;
    for(int i=0; i<numThreads; ++i)
    {
        map< pair<int,int>, double> *p1 = new map< pair<int,int>, double>;
        listMapdbValsThreadSafe.push_back( p1 );
        map< pair<int,int>, double> *p2 = new map< pair<int,int>, double>;
        listMapwbValsThreadSafe.push_back( p2 );
        map< pair<pair<int,int>,int>, double > *p3 = new map< pair<pair<int,int>,int>, double >;
        listCacheBranchProbThreadSafe.push_back(p3);
    }
}

map< pair<int,int>, double> & ApproxGTPCache :: GetdbValCache(int tid)
{
    //
    YW_ASSERT_INFO( tid<(int)listMapdbValsThreadSafe.size(), "Overflow" );
    return *listMapdbValsThreadSafe[tid];
}

map< pair<int,int>, double> & ApproxGTPCache :: GetwbValCache(int tid)
{
    //
    YW_ASSERT_INFO( tid<(int)listMapwbValsThreadSafe.size(), "Overflow" );
    return *listMapwbValsThreadSafe[tid];
}

map< pair<pair<int,int>,int>, double > &  ApproxGTPCache :: GetBrProbCache(int tid)
{
    //
    YW_ASSERT_INFO( tid<(int)listCacheBranchProbThreadSafe.size(), "Overflow" );
    return *listCacheBranchProbThreadSafe[tid];
}


///////////////////////////////////////////////////////////////////////////////////////
// for benchmark run time


ApproxGTPStats & ApproxGTPStats :: Instance()
{
    static ApproxGTPStats inst;
    return inst;
}

void ApproxGTPStats :: DumpStats() const
{
    //
    cout << "************************ Execution Statistics **************************\n";
    cout << "      Maximum size of configuration list: " << maxSzACList << endl;
    cout << "      Total number of gene probability computation (for all given input trees): " << listProbCalcTimeEnd.size() << endl;
    cout << "      Total number of branch optimization: " << brOptNums << endl;
    double tmTot = 0.0;
    for(int i=0; i<(int)listProbCalcTimeEnd.size(); ++i )
    {
        tmTot += (listProbCalcTimeEnd[i] - listProbCalcTimeStart[i])/(double)CLOCKS_PER_SEC;
    }
    if( listProbCalcTimeEnd.size() > 0 )
    {
        cout << "     Average time for computing the gene tree probability is " << tmTot/listProbCalcTimeEnd.size() << " seconds\n";
    }
}

void ApproxGTPStats :: RecordProbComputeStart()
{
    //
    //auto duration = now.time_since_epoch();
    //auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
    listProbCalcTimeStart.push_back( GetCurrentTimeTick() );
}

void ApproxGTPStats :: RecordProbComputeEnd()
{
    //
    //auto duration = now.time_since_epoch();
    //auto millis = std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
    listProbCalcTimeEnd.push_back( GetCurrentTimeTick() );
}

void ApproxGTPStats :: RecordMaxACSize(int szACList)
{
    if( szACList > maxSzACList )
    {
        maxSzACList = szACList;
    }
}

void ApproxGTPStats :: RecordBranchLenOpt()
{
    ++brOptNums;
}


ApproxGTPStats :: ApproxGTPStats() : maxSzACList(0), brOptNums(0)
{
    //
}

///////////////////////////////////////////////////////////////////////////////////////
// AC history: how each config gets its prob


// context for prob-recomputing
// should we recompute the coal coefficient?
AGTPACRecomputeContext :: AGTPACRecomputeContext( ApproxGeneTreeProbHelper *pAGTPHelperIn, const set<int> &branchBeingChangedIn ) : pAGTPHelper(pAGTPHelperIn), branchBeingChanged(branchBeingChangedIn)
{
}
bool AGTPACRecomputeContext :: IsCoalCoeffFresh( const ApproxGeneTreeProbAncConfig *pCfgBeingCoal )
{
//return false;
    // recompute if this cfg is one that is right on the changing branch
    YW_ASSERT_INFO( pCfgBeingCoal!=NULL, "null" );
    return branchBeingChanged.find(pCfgBeingCoal->GetNodeId() ) == branchBeingChanged.end();
}
// recompute the coalescent coefficient
double AGTPACRecomputeContext :: RecomputeCoalCoeff( const ApproxGeneTreeProbAncConfig *pCfgBeingCoal, const ApproxGeneTreeProbAncConfig *pCfgDest )
{
    YW_ASSERT_INFO( pCfgBeingCoal!=NULL, "Cannot be null1" );
    YW_ASSERT_INFO( pCfgDest!=NULL, "Cannot be null2" );
    int nodeId = pCfgBeingCoal->GetNodeId();
    double lenBranchNew = pAGTPHelper->GetSpeciesTree().GetEdgeLen( nodeId );
    return pAGTPHelper->CalcCoalCoeffForTwoCfg( lenBranchNew, *pCfgBeingCoal, *pCfgDest );
}



// obtained from another AC (coalesced at the same branch)
double ApproxGeneTreeProbAncConfigHistCoal :: Recompute( AGTPACRecomputeContext &context, const ApproxGeneTreeProbAncConfig *pCfgDest )
{
    //
    YW_ASSERT_INFO( pCfgDest != NULL, "Cannot recompute: no info on dest cfg" );
    double prob = 0.0;
    for(int i=0; i<(int)listCfgsCoalandCoeffs.size(); ++i )
    {
        bool fFresh = context.IsCoalCoeffFresh( listCfgsCoalandCoeffs[i].first );
        double coeff;
        if( fFresh == false )
        {
            coeff = context.RecomputeCoalCoeff( listCfgsCoalandCoeffs[i].first, pCfgDest );
            // update the coefficient
            listCfgsCoalandCoeffs[i].second = coeff;
        }
        else
        {
            coeff = listCfgsCoalandCoeffs[i].second;
        }
#ifndef LOG_CFG_PROB
        prob += listCfgsCoalandCoeffs[i].first->GetProb() * coeff ;
#else
        double logcoeff = MAX_NEG_DOUBLE_VAL;
        if( coeff > 0.0)
        {
            logcoeff = log(coeff);
        }
        double logprobThis = listCfgsCoalandCoeffs[i].first->GetLogProb() + logcoeff;
        if( i == 0 )
        {
            prob = logprobThis;
        }
        else
        {
            prob = GetLogSumOfTwo( prob, logprobThis );
        }
#endif
    }
    return prob;
}
ApproxGeneTreeProbAncConfigHist * ApproxGeneTreeProbAncConfigHistCoal :: Copy()
{
    ApproxGeneTreeProbAncConfigHistCoal *pcopy = new ApproxGeneTreeProbAncConfigHistCoal();
    pcopy->listCfgsCoalandCoeffs = this->listCfgsCoalandCoeffs;
    return pcopy;
}
void ApproxGeneTreeProbAncConfigHistCoal :: MergeWith( const ApproxGeneTreeProbAncConfigHist &rhs )
{
    const ApproxGeneTreeProbAncConfigHistCoal *prhs1 = dynamic_cast<const ApproxGeneTreeProbAncConfigHistCoal *>(&rhs);
    YW_ASSERT_INFO(prhs1 != NULL, "Cannot be NULL2");
    for(int i=0; i<(int)prhs1->listCfgsCoalandCoeffs.size(); ++i)
    {
        this->listCfgsCoalandCoeffs.push_back( prhs1->listCfgsCoalandCoeffs[i]  );
    }
}
void ApproxGeneTreeProbAncConfigHistCoal :: Dump() const
{
    //
    cout << "[CoalHistory]: # of coalesced lineages: " << listCfgsCoalandCoeffs.size() << endl;
}
void ApproxGeneTreeProbAncConfigHistCoal :: AddDependent( const ApproxGeneTreeProbAncConfig *pCfgDepend, double coalCoeff )
{
    pair<const ApproxGeneTreeProbAncConfig *, double> pp(pCfgDepend, coalCoeff);
    listCfgsCoalandCoeffs.push_back(pp);
}



// obtained by merging two ACs (no coalescent)
double ApproxGeneTreeProbAncConfigHistMerge :: Recompute( AGTPACRecomputeContext &context, const ApproxGeneTreeProbAncConfig *pCfgDest )
{
    // context is ignored for merging
    double prob = 0.0;
    for(int i=0; i<(int)listCfgsMergePairs.size(); ++i )
    {
#ifndef LOG_CFG_PROB
        prob += listCfgsMergePairs[i].first->GetProb() * listCfgsMergePairs[i].second->GetProb();
#else
        double logprobThis = listCfgsMergePairs[i].first->GetLogProb() + listCfgsMergePairs[i].second->GetLogProb();
        if( i== 0 )
        {
            prob = logprobThis;
        }
        else
        {
            prob = GetLogSumOfTwo( prob, logprobThis );
        }
#endif
    }
    return prob;
}
ApproxGeneTreeProbAncConfigHist * ApproxGeneTreeProbAncConfigHistMerge :: Copy()
{
    ApproxGeneTreeProbAncConfigHistMerge *pcopy = new ApproxGeneTreeProbAncConfigHistMerge;
    pcopy->listCfgsMergePairs = this->listCfgsMergePairs;
    return pcopy;
}
void ApproxGeneTreeProbAncConfigHistMerge :: MergeWith( const ApproxGeneTreeProbAncConfigHist &rhs)
{
    const ApproxGeneTreeProbAncConfigHistMerge *prhs1 = dynamic_cast<const ApproxGeneTreeProbAncConfigHistMerge *>(&rhs);
    YW_ASSERT_INFO(prhs1 != NULL, "null2");
    for(int i=0; i<(int)prhs1->listCfgsMergePairs.size(); ++i)
    {
        this->listCfgsMergePairs.push_back( prhs1->listCfgsMergePairs[i] );
    }
}
void ApproxGeneTreeProbAncConfigHistMerge :: Dump() const
{
    //
    cout << "[MerageHistory]: # of merged lineage pairs: " << listCfgsMergePairs.size() << endl;
}
void ApproxGeneTreeProbAncConfigHistMerge ::  AddDependent( const ApproxGeneTreeProbAncConfig *pCfg1, const ApproxGeneTreeProbAncConfig *pCfg2 )
{
    pair<const ApproxGeneTreeProbAncConfig *, const ApproxGeneTreeProbAncConfig *> pp(pCfg1, pCfg2);
    listCfgsMergePairs.push_back( pp );
}




//////////////////////////////////////////////////////////////////////////////////
// Approx gene tree prob AC

bool ApproxGeneTreeProbAncConfig :: fOneClusterOnly = false;

ApproxGeneTreeProbAncConfig  :: ApproxGeneTreeProbAncConfig(int nodeSTIn) : nodeST(nodeSTIn), probCfg(0.0), logprobCfg(MAX_NEG_DOUBLE_VAL), totLins(-1), pAGTPACHist(NULL)
{
    //
}

ApproxGeneTreeProbAncConfig :: ApproxGeneTreeProbAncConfig(int nodeSTIn, const vector<int> &listLinNumsForClustersIn, double probCfgIn, bool fLogMode) : nodeST(nodeSTIn), listLinNumsForClusters(listLinNumsForClustersIn), totLins(-1), pAGTPACHist(NULL)
{
    if( fLogMode == true )
    {
        SetLogProb( probCfgIn );
    }
    else
    {
        SetProb( probCfgIn );
    }
}

ApproxGeneTreeProbAncConfig  :: ApproxGeneTreeProbAncConfig(const ApproxGeneTreeProbAncConfig &rhs) : nodeST(rhs.nodeST), listLinNumsForClusters(rhs.listLinNumsForClusters), probCfg(rhs.probCfg), logprobCfg(rhs.logprobCfg), totLins(rhs.totLins)
{
    //
    if( rhs.pAGTPACHist != NULL )
    {
        this->pAGTPACHist = rhs.pAGTPACHist->Copy();
    }
    else
    {
        this->pAGTPACHist = NULL;
    }
}

ApproxGeneTreeProbAncConfig :: ~ApproxGeneTreeProbAncConfig()
{
    //
    if( pAGTPACHist != NULL )
    {
        delete pAGTPACHist;
        pAGTPACHist = NULL;
    }
}

void ApproxGeneTreeProbAncConfig :: SetProb(double prob)
{
    //
    this->probCfg = prob;
    //this->logprobCfg = log(prob);
}

void ApproxGeneTreeProbAncConfig :: SetLogProb(double logprob)
{
    //
    this->logprobCfg = logprob;
    //this->probCfg = exp( logprob );
}

void ApproxGeneTreeProbAncConfig :: SetCountingMode(bool f)
{
    //
    fOneClusterOnly = f;
}

bool ApproxGeneTreeProbAncConfig :: IsCountingMode()
{
    return fOneClusterOnly;
}

void ApproxGeneTreeProbAncConfig :: operator=(const ApproxGeneTreeProbAncConfig &rhs)
{
    //
    this->nodeST = rhs.nodeST;
    this->listLinNumsForClusters = rhs.listLinNumsForClusters;
    this->probCfg = rhs.probCfg;
    this->logprobCfg = rhs.logprobCfg;
    if( this->pAGTPACHist != NULL )
    {
        delete this->pAGTPACHist;
        this->pAGTPACHist = NULL;
    }
    if( rhs.pAGTPACHist != NULL )
    {
        AddHist( rhs.pAGTPACHist->Copy() );
    }
}

bool ApproxGeneTreeProbAncConfig  :: operator<(const ApproxGeneTreeProbAncConfig &rhs) const
{
    // don't consider prob
    if( this->nodeST < rhs.nodeST )
    {
        return true;
    }
    else if( this->nodeST == rhs.nodeST)
    {
#if 0
        // if size mismatch, use size smaller
        if( this->listLinNumsForClusters.size() < rhs.listLinNumsForClusters.size() )
        {
            return true;
        }
        else if( this->listLinNumsForClusters.size() == rhs.listLinNumsForClusters.size() )
        {
        
            // start compare from right end to left (matching row-major indices)
            bool fLessThan = false;
            for(int i=(int)this->listLinNumsForClusters.size()-1; i>=0; --i )
            {
                if( this->listLinNumsForClusters[i] < rhs.listLinNumsForClusters[i] )
                {
                    fLessThan = true;
                    break;
                }
                else if( this->listLinNumsForClusters[i] > rhs.listLinNumsForClusters[i] )
                {
                    //
                    break;
                }
            }
            return fLessThan;
        }
#endif
        // then order by the number of lineages
        int nl = GetTotNumLins();
        int nlOther = rhs.GetTotNumLins();
        if( nl < nlOther )
        {
            return true;
        }
        else if( nl == nlOther )
        {
          return this->listLinNumsForClusters < rhs.listLinNumsForClusters;
        }
    }
    
    return false;
}

void ApproxGeneTreeProbAncConfig  :: Clear()
{
    //
    this->listLinNumsForClusters.clear();
}

void ApproxGeneTreeProbAncConfig  :: AddLinCluster( int numAlleles )
{
    //
//#if 0
//    if( IsCountingMode() == false )
//    {
        this->listLinNumsForClusters.push_back( numAlleles );
//    }
#if 0
    else
    {

        //
        if( this->listLinNumsForClusters.size() == 0 )
        {
            this->listLinNumsForClusters.push_back(numAlleles);
        }
        else
        {
            // if there is some lineage, just add it up
            this->listLinNumsForClusters[0] += numAlleles;;
        }
    }
#endif
}

void ApproxGeneTreeProbAncConfig  :: AddLinClusterAt(int pos, int numAlleles)
{
    //
    int posToUse = pos;
#if 0
    if( IsCountingMode() == true )
    {
        posToUse = 0;
    }
#endif
    YW_ASSERT_INFO( posToUse< (int)this->listLinNumsForClusters.size(), "Overflow 3" );
    this->listLinNumsForClusters[posToUse] += numAlleles;
}

void ApproxGeneTreeProbAncConfig  :: FindCoalsableCfgsWithin( ApproxGeneTreeProbHelper &helper, double lenBranch, set< ApproxGeneTreeProbAncConfig > &setCoalCfgs ) const
{
    //
    //const set<ApproxGeneTreeProbAncConfig> *pSetCoalCfgs = helper.FindCoalscedCfgsFrom( *this );
    //if( pSetCoalCfgs != NULL )
    //{
    //    setCoalCfgs = *pSetCoalCfgs;
    //}
    //else
    //{
        set< const ApproxGeneTreeProbAncConfig * > setActiveCfgs;
        setActiveCfgs.insert( this );
        setCoalCfgs.insert( *this );
        
        while( setActiveCfgs.size() > 0 )
        {
            //
            const ApproxGeneTreeProbAncConfig *pcfgActive = *( setActiveCfgs.begin() );
            setActiveCfgs.erase( setActiveCfgs.begin() );
           
            vector<ApproxGeneTreeProbAncConfig *> listCoalCfgsOneEvt;
            pcfgActive->FindCoalsableCfgsOneEvent( listCoalCfgsOneEvt );
            for( int i=0; i<(int)listCoalCfgsOneEvt.size(); ++i )
            {
                if( setCoalCfgs.find( *listCoalCfgsOneEvt[i] ) == setCoalCfgs.end() )
                {
                    setCoalCfgs.insert(*listCoalCfgsOneEvt[i]);
                    setActiveCfgs.insert(  &( *(setCoalCfgs.find( *listCoalCfgsOneEvt[i] )))  );
                    //setActiveCfgs.insert(  &( setCoalCfgs[ setCoalCfgs.size()-1 ])  );
                }
                delete listCoalCfgsOneEvt[i];
            }
            
#if 0
            //
            set<ApproxGeneTreeProbAncConfig> setCoalCfgsOneEvt;
            pcfgActive->FindCoalsableCfgsOneEvent( setCoalCfgsOneEvt );
            for( set<ApproxGeneTreeProbAncConfig> :: iterator it= setCoalCfgsOneEvt.begin(); it != setCoalCfgsOneEvt.end(); ++it )
            {
                if( setCoalCfgs.find( *it ) == setCoalCfgs.end() )
                {
                    setCoalCfgs.insert(*it);
                    setActiveCfgs.insert(  &( *(setCoalCfgs.find( *it)))  );
                //setActiveCfgs.insert(  &( setCoalCfgs[ setCoalCfgs.size()-1 ])  );
                }
            }
#endif
        }
    
        // remember it
        //helper.AddCoalescedCfgsFrom(*this, setCoalCfgs);
    //}
    
    // update prob of these found cfgs
    int numLinsPrior = this->GetTotNumLins();
    for( set<ApproxGeneTreeProbAncConfig> :: iterator it = setCoalCfgs.begin(); it != setCoalCfgs.end(); ++it )
    {
        //
        int numLinsAfter = (*it).GetTotNumLins();
        double probCoal = helper.CalcCoalProbBranch( numLinsPrior, numLinsAfter, lenBranch );
        

        double coeff = 1.0;
        //if( GSTPIsHeuModeOn() == true )
        //{
        //    coeff *= gstHelper->CalcwbValMultiHeu( listEvts, *pSrcConfig, ub, cb );
        //}
        //else
        //{
//#if 0
        int cb = numLinsPrior - numLinsAfter;
        coeff=1.0/ helper.CalcdbVal(numLinsPrior, cb);
        coeff *= helper.CalcwbVal( numLinsPrior, cb );
//#endif
        
        ApproxGeneTreeProbAncConfig &cfgRef = const_cast<ApproxGeneTreeProbAncConfig &>(*it);
#ifndef LOG_CFG_PROB
        cfgRef.SetProb( this->GetProb() * coeff * probCoal );
#else
        double logcoeff = MAX_NEG_DOUBLE_VAL;
        if( coeff > 0.0)
        {
            logcoeff = log(coeff);
        }
        double logprobcoal = MAX_NEG_DOUBLE_VAL;
        if( probCoal > 0.0)
        {
            logprobcoal = log(probCoal);
        }
        cfgRef.SetLogProb( this->GetLogProb() + logcoeff + logprobcoal );
#endif
    }
#if 0
cout << "FindCoalsableCfgsWithin: len=" << lenBranch << ": current cfg: ";
this->Dump();
cout << "list of configurations found: ";
for( set<ApproxGeneTreeProbAncConfig> :: iterator it = setCoalCfgs.begin(); it != setCoalCfgs.end(); ++it )
{
(*it).Dump();
}
#endif
}

void ApproxGeneTreeProbAncConfig :: FindCoalsableCfgsFrom( ApproxGeneTreeProbHelper &helper, double lenBranch, const set< const ApproxGeneTreeProbAncConfig *> &setActiveCoalCfgs, const set< ApproxGeneTreeProbAncConfig > &setCoalCfgsFoundBefore, set< ApproxGeneTreeProbAncConfig > &setCoalCfgs)
{
    // find coalesced config from current step
    for( set<const ApproxGeneTreeProbAncConfig *> :: const_iterator it = setActiveCoalCfgs.begin(); it != setActiveCoalCfgs.end(); ++it )
    {
        //
        const ApproxGeneTreeProbAncConfig *pcfgActive = *it;
        //
        vector<ApproxGeneTreeProbAncConfig *> listCoalCfgsOneEvt;
        pcfgActive->FindCoalsableCfgsOneEvent( listCoalCfgsOneEvt );
        for( int i=0; i<(int)listCoalCfgsOneEvt.size(); ++i)
        {
            if( setCoalCfgsFoundBefore.find( *listCoalCfgsOneEvt[i] ) == setCoalCfgsFoundBefore.end() )
            {
//cout << "In FindCoalsableCfgsFrom: find one new cfg: ";
//listCoalCfgsOneEvt[i]->Dump();
                setCoalCfgs.insert(*listCoalCfgsOneEvt[i]);
            }
            delete listCoalCfgsOneEvt[i];
        }
#if 0
        //
        set<ApproxGeneTreeProbAncConfig> setCoalCfgsOneEvt;
        pcfgActive->FindCoalsableCfgsOneEvent( setCoalCfgsOneEvt );
        for( set<ApproxGeneTreeProbAncConfig> :: iterator it= setCoalCfgsOneEvt.begin(); it != setCoalCfgsOneEvt.end(); ++it )
        {
            if( setCoalCfgsFoundBefore.find( *it ) == setCoalCfgsFoundBefore.end() )
            {
                setCoalCfgs.insert(*it);
            }
        }
#endif
    }
}

void ApproxGeneTreeProbAncConfig  :: Dump() const
{
    //
    cout << "[prob:" << this->GetProb() << "]: [logprob: "<< this->GetLogProb() <<  "]: <node:" << this->GetNodeId() << ">: ";
    DumpIntVec( listLinNumsForClusters);
    if( this->pAGTPACHist != NULL)
    {
        cout << "History: ";
        this->pAGTPACHist->Dump();
    }
    else
    {
        cout << "NO history\n";
    }
}

//void ApproxGeneTreeProbAncConfig :: FindCoalsableCfgsOneEvent( set<ApproxGeneTreeProbAncConfig> &setCoalCfgsOneEvt ) const
void ApproxGeneTreeProbAncConfig :: FindCoalsableCfgsOneEvent( vector<ApproxGeneTreeProbAncConfig *> &listCoalCfgsOneEvt ) const
{
    // from current cfg, find cfgs that can be obtained by one event
    listCoalCfgsOneEvt.clear();
    for(int i=0; i<(int)this->listLinNumsForClusters.size(); ++i )
    {
        if( this->listLinNumsForClusters[i] <= 1 )
        {
            // cannot coalesce
            continue;
        }
        ApproxGeneTreeProbAncConfig *pcfgNew = new ApproxGeneTreeProbAncConfig( *this );
        ApproxGeneTreeProbAncConfigHistCoal *pCoalHist = new ApproxGeneTreeProbAncConfigHistCoal;
        pcfgNew->AddHist(pCoalHist);
        pcfgNew->OffsetLinNumAt(i, -1);
        listCoalCfgsOneEvt.push_back( pcfgNew );
    }
#if 0
    // from current cfg, find cfgs that can be obtained by one event
    setCoalCfgsOneEvt.clear();
    for(int i=0; i<(int)this->listLinNumsForClusters.size(); ++i )
    {
        if( this->listLinNumsForClusters[i] <= 1 )
        {
            // cannot coalesce
            continue;
        }
        ApproxGeneTreeProbAncConfig cfgNew( *this );
        cfgNew.OffsetLinNumAt(i, -1);
        setCoalCfgsOneEvt.insert( cfgNew );
    }
#endif
}

int ApproxGeneTreeProbAncConfig :: GetTotNumLins() const
{
    if( this->totLins < 0 )
    {
        ApproxGeneTreeProbAncConfig *pthis = const_cast<ApproxGeneTreeProbAncConfig *>(this);
        pthis->totLins = 0;
        for( vector<int> :: const_iterator it = listLinNumsForClusters.begin(); it != listLinNumsForClusters.end(); ++it)
        {
            pthis->totLins += *it;
        }
    }
    return this->totLins;
}

void ApproxGeneTreeProbAncConfig :: AddHist( ApproxGeneTreeProbAncConfigHist *phist)
{
    YW_ASSERT_INFO( phist!=NULL, "Cannot be null" );
    if( this->pAGTPACHist != NULL)
    {
        delete this->pAGTPACHist;
    }
    //phist->AttachToCfg(this);
    this->pAGTPACHist = phist;
}


//////////////////////////////////////////////////////////////////////////////////
// Approx gene tree prob helper

const double DEF_MIN_FRAC_INC_PROB = 1.01;
const int DEF_MAX_ROUNDS_AC_ANC = 100;
int ApproxGeneTreeProbHelper :: maxNumConvolvePairsDirect = 100;


ApproxGeneTreeProbHelper :: ApproxGeneTreeProbHelper( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn ) : treeSpecies(treeSpeciesIn), treeGene(treeGeneIn), threadId(0), distFactor( pow(10.0, numBranchLenDigit) ), minFracInProb(DEF_MIN_FRAC_INC_PROB), maxRoundsPerAC(DEF_MAX_ROUNDS_AC_ANC)
{
    Init();
}

void ApproxGeneTreeProbHelper :: SetMaxConvolvePairsDirect(int valNew)
{
    maxNumConvolvePairsDirect = valNew;
}

void  ApproxGeneTreeProbHelper :: Init()
{
    // now traverse the tree and find the MRCA
	// simple approach: traverse the tree; for each node,
	// find its left and right and then set their MRCA to the current one
	PhylogenyTreeIterator itorTree(treeGene);
	itorTree.Init();
	//treeGene.InitPostorderWalk();
	while(itorTree.IsDone() == false )
	{
		TreeNode *pn = itorTree.GetCurrNode( ) ;
		itorTree.Next();
		if( pn == NULL )
		{
			break;      // done with all nodes
		}
		int idSelf = pn->GetID();
        
		// keep track of id-->node info
        //cout << "In Gene tree traversal, find a node idSelf: " << idSelf << endl;
		mapIdNode.insert( map<int, TreeNode*> :: value_type( idSelf, pn )  );
    }
    
    // now construct cluster info
    ConsClusterInfo();
}

void ApproxGeneTreeProbHelper :: ConsClusterInfo()
{
    // YW: 05/18/16: do we really need this?
    this->treeSpecies.BuildDescendantInfo();
#if 0
cout << "ConsClusterInfo: ";
cout << "Current species tree: " << treeSpecies.GetNewick() << endl;
treeSpecies.Dump();
cout << "Current gene tree: ";
string strGT;
treeGene.ConsNewick(strGT);
cout << strGT << endl;
treeGene.Dump();
#endif
    
// print out some info
//for(int sbIndex = 0; sbIndex < treeSpecies.GetTotNodesNum(); ++sbIndex )
//{
//cout << "ST node: " << sbIndex << ", left chilld: " << treeSpecies.GetLeftDescendant(sbIndex) << ", right child: " << treeSpecies.GetRightDescendant(sbIndex) << endl;
//}
    
    //
    listSTLinClusterList.clear();
    listSTLinClusterRootMap.clear();
    listAborbedTreeNodes.clear();
    
    // construct cluster info for species tree branch
    // approach: consider each species tree branch; find their taxa; get the corresponding
    // gene lineages (taxa); find the clusters of them
    vector<set<int> > leafNodeLabels;
    treeSpecies.ConsDecedentLeavesInfoLabels( leafNodeLabels );
    
    listAborbedTreeNodes.resize( treeSpecies.GetTotNodesNum() );
    
    for( int sbIndex = 0; sbIndex < treeSpecies.GetTotNodesNum(); ++sbIndex )
    {
        //
        set<int> setTaxaBelow = leafNodeLabels[sbIndex];
        
        set<int> geneAlleles;
        GetGeneAllelesForSpeciesSet( setTaxaBelow, geneAlleles);
        
        // find all nodes
        set<TreeNode *> setLeaves;
        GetNodesForIds(geneAlleles, setLeaves);
        
        // find all the subtrees clustered
        set< set<TreeNode *> > setSubtreeClades;
        treeGene.FindCladeOfSubsetLeavesExact( setLeaves, setSubtreeClades );
        set< set<TreeNode *> > setSubtreeCladesMaximal;
        PhylogenyTreeBasic :: GroupLeavesToSubtrees( setLeaves,  setSubtreeClades, setSubtreeCladesMaximal);
        
        // collect all roots
        vector<ApproxGeneTreeProbCluster> vecClusters;
        for( set<set<TreeNode *> > :: iterator it = setSubtreeCladesMaximal.begin(); it != setSubtreeCladesMaximal.end(); ++it )
        {
            TreeNode *pp = treeGene.GetSubtreeRootForLeaves( *it );
            // create subtrees
            ApproxGeneTreeProbCluster clus( pp );
            vecClusters.push_back(clus);
        }
        listSTLinClusterList.push_back( vecClusters );
//cout << "For species tree branch: " << sbIndex << ", number of clusters: " << vecClusters.size() << endl;
    }
    
    // also update the other
    listSTLinClusterRootMap.clear();
    listSTLinClusterRootMap.resize( listSTLinClusterList.size() );
    for(int i=0; i<(int)listSTLinClusterRootMap.size(); ++i)
    {
        for(int jj=0; jj<(int)listSTLinClusterList[i].size(); ++jj )
        {
            TreeNode *prootc = listSTLinClusterList[i][jj].GetClusterRoot();
            listSTLinClusterRootMap[i].insert( map<TreeNode *,int> :: value_type( prootc, jj ) );
        }
    }
    
    for( int sbIndex = 0; sbIndex < treeSpecies.GetTotNodesNum(); ++sbIndex )
    {
        // for internal node, also get absorbed nodes
        if( treeSpecies.IsLeaf( sbIndex ) == false )
        {
            //
            int cl = treeSpecies.GetLeftDescendant(sbIndex);
            int cr = treeSpecies.GetRightDescendant(sbIndex);
            // find roots in the children that are not root in the current node
            int cindex[2] = {cl, cr};
            for(int i=0; i<2; ++i)
            {
                int cindexcur = cindex[i];
                for( int jj=0; jj<(int)listSTLinClusterList[ cindexcur ].size(); ++jj )
                {
                    TreeNode *pnc = listSTLinClusterList[cindexcur][jj].GetClusterRoot();
                    if( listSTLinClusterRootMap[sbIndex].find(pnc) == listSTLinClusterRootMap[sbIndex].end() )
                    {
                        //
                        TreeNode *pncAnc = pnc;
                        while( pncAnc != NULL )
                        {
                            //
                            pncAnc = pncAnc->GetParent();
                            if( listSTLinClusterRootMap[sbIndex].find(pncAnc) != listSTLinClusterRootMap[sbIndex].end() )
                            {
                                break;
                            }
                        }
                        YW_ASSERT_INFO( pncAnc != NULL, "Fail111");
                        int indPNCAnc = listSTLinClusterRootMap[sbIndex][pncAnc];
                        listAborbedTreeNodes[sbIndex].insert( map< TreeNode *, int> :: value_type(pnc, indPNCAnc) );
                    }
                }
            }
        }
    }
    
    // also construct desc info for gene tree
    PhylogenyTreeIterator itorTree(treeGene);
    itorTree.Init();
    while( itorTree.IsDone() == false )
    {
        TreeNode *pn = itorTree.GetCurrNode();
        set<TreeNode *> setAllDesc;
        pn->GetAllDescendents( setAllDesc );
        mapGTNodeDesc.insert( map<TreeNode *, set<TreeNode *> > :: value_type(pn, setAllDesc) );
        itorTree.Next();
    }
    
    // find the set of lineage numbers under each ST node
    listSTLinClusterSizeList.resize( listSTLinClusterList.size() );
    for(int i=0; i<(int)this->listSTLinClusterList.size(); ++i)
    {
        for(int j=0; j<(int)listSTLinClusterList[i].size(); ++j)
        {
            TreeNode *pn = listSTLinClusterList[i][j].GetClusterRoot();
            set<TreeNode *> setLeaves;
            pn->GetAllLeavesUnder( setLeaves );
            listSTLinClusterSizeList[i].push_back( setLeaves.size() );
        }
    }
    
    // find out the number of cfgs at each node
    listNumCfgsAtStNodes.clear();
    for(int sbIndex = 0; sbIndex < treeSpecies.GetTotNodesNum(); ++sbIndex)
    {
        listNumCfgsAtStNodes.push_back( GetNumCfgsAtDirect( sbIndex ) );
    }
    
    // find otu the minimum number of lineages at each ST node (note: here is right at the speciation)
    listSTLinClusterSizeListMin.resize( listSTLinClusterList.size() );
    for( int sbIndex = 0; sbIndex < treeSpecies.GetTotNodesNum(); ++sbIndex )
    {
        for(int i=0; i<(int)listSTLinClusterList[sbIndex].size(); ++i )
        {
            int lb = GetNumSubCluster( sbIndex, listSTLinClusterList[sbIndex][i] );
            listSTLinClusterSizeListMin[sbIndex].push_back( lb );
        }
    }
    
    // also save the net bounds for faster access
    listSTLinClusterSizeListNet.resize( listSTLinClusterSizeList.size() );
    for( int sbIndex = 0; sbIndex < treeSpecies.GetTotNodesNum(); ++sbIndex )
    {
        for(int i=0; i<(int)listSTLinClusterList[sbIndex].size(); ++i )
        {
            int netNum = listSTLinClusterSizeList[sbIndex][i] - listSTLinClusterSizeListMin[sbIndex][i];
            YW_ASSERT_INFO( netNum >=0, "Fatal error" );
            listSTLinClusterSizeListNet[sbIndex].push_back( netNum );
        }
    }
    
#if 0
cout << "List of lower bound of lineages: \n";
for(int i=0; i<(int)listSTLinClusterSizeListMin.size(); ++i)
{
cout << "ST ndoe: " << i << ": list of cluster min-sizes: ";
DumpIntVec( listSTLinClusterSizeListMin[i] );
}
#endif
}

void ApproxGeneTreeProbHelper :: GetGeneAllelesForSpeciesSet( const set<int> &setTaxa, set<int> &geneAlleles)
{
    //
    geneAlleles.clear();
    for( set<int> :: const_iterator it = setTaxa.begin(); it != setTaxa.end(); ++it)
    {
        set<int> ss;
        GetGeneAllelesForSpecies( *it, ss );
        UnionSets( geneAlleles, ss );
    }
}

void ApproxGeneTreeProbHelper :: GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles)
{
    map<int,set<int> > :: iterator it = mapTaxonGids.find(taxon);
    if( it != mapTaxonGids.end() )
    {
        geneAlleles = it->second;
        return;
    }
    
	geneAlleles.clear();
    //cout << "GetGeneAllelesForSpecies: taxon = " << taxon << endl;
	// get all alleles in GT for a gene
	char idbuf[100];
	sprintf(idbuf, "%d", taxon);
	string idstr = idbuf;
	// search for each leaf, to find match
	treeGene.GetLeavesIdsWithLabel(  idstr, geneAlleles );
    
    mapTaxonGids.insert( map<int,set<int> > :: value_type( taxon, geneAlleles ) );
}

void ApproxGeneTreeProbHelper :: GetNodesForIds(const set<int> &nids, set<TreeNode *> &setNodes) const
{
    //
    //ApproxGeneTreeProbHelper *pthis = const_cast<ApproxGeneTreeProbHelper *>(this);
    setNodes.clear();
    for(set<int> :: iterator it = nids.begin(); it != nids.end(); ++it)
    {
        map<int, TreeNode*> :: const_iterator it2 = mapIdNode.find(*it);
        YW_ASSERT_INFO(it2 != mapIdNode.end(), "Fail to find");
        TreeNode *pn = it2->second;
        setNodes.insert(pn);
    }
}

void ApproxGeneTreeProbHelper :: FormLinConfig( int snid, const vector<int> &linsGT, ApproxGeneTreeProbAncConfig &linConfig ) const
{
    // snid: must be a leaf
    YW_ASSERT_INFO( treeSpecies.IsLeaf(snid) == true, "Must be a leaf" );
    linConfig.Clear();
    
	// generate trivial lineage cluster of single lineage
	// find whether there are lineages that can be merged
	linConfig.SetNodeId(snid);
    // view all these alleles of same type (and the only type at the leaf taxon)
    for(int i=0; i<(int)linsGT.size(); ++i)
    {
        linConfig.AddLinCluster( linsGT[i] );
    }
}

void ApproxGeneTreeProbHelper :: FormLinConfig( int snid, const ApproxGeneTreeProbAncConfig &linsGT1, const ApproxGeneTreeProbAncConfig &linsGT2, ApproxGeneTreeProbAncConfig &linConfig ) const
{
    //
    // merging two configs into one
	linConfig.Clear();
    
	// generate trivial lineage cluster of single lineage
	// find whether there are lineages that can be merged
	linConfig.SetNodeId(snid);
    CombineTwoACs( snid, linsGT1, linsGT2, linConfig );
}

void ApproxGeneTreeProbHelper :: FastCollectAncConfig( int nodeId, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew )
{
    //
    double lenOrig = treeSpecies.GetEdgeLen(nodeId);
	FastCollectAncConfig(lenOrig, setOrigCfgs, listAncCfgsNew );
}

void ApproxGeneTreeProbHelper :: FastCollectAncConfig( double lenOrig, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew )
{
#if 0
cout << "***FastCollectAncConfig: set of coming lineages\n";
for( set< ApproxGeneTreeProbAncConfig > :: iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
{
(*it).Dump();
}
#endif
    // find all reachable ACs and merge them if needed
    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
    {
        set<ApproxGeneTreeProbAncConfig> setCfgsReached;
        (*it).FindCoalsableCfgsWithin( *this, lenOrig, setCfgsReached );
        for( set<ApproxGeneTreeProbAncConfig> :: iterator it2 = setCfgsReached.begin(); it2 != setCfgsReached.end(); ++it2 )
        {
            // find it already
            if( listAncCfgsNew.find( *it2 ) == listAncCfgsNew.end()  )
            {
                //
                listAncCfgsNew.insert( *it2 );
            }
            else
            {
                // update it
                ApproxGeneTreeProbAncConfig &lcTot = const_cast< ApproxGeneTreeProbAncConfig & >( *listAncCfgsNew.find( *it2 ) );
#ifndef LOG_CFG_PROB
                lcTot.SetProb( lcTot.GetProb()+(*it2).GetProb());
#else
                lcTot.SetLogProb( GetLogSumOfTwo( lcTot.GetLogProb(), (*it2).GetLogProb() ) );
#endif
                //listAncCfgsNew.erase( *it2 );
                //listAncCfgsNew.insert( lcTot );
            }
        }
    }

#if 0
cout << "***After this config, list of ancestral configs so far***\n";
    for( set< ApproxGeneTreeProbAncConfig > :: iterator it = listAncCfgsNew.begin(); it != listAncCfgsNew.end(); ++it )
{
(*it).Dump();
}
cout << "Done: FastCollectAncConfig\n";
#endif
}

void ApproxGeneTreeProbHelper :: FastCollectAncConfigHeu( int nodeId, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew )
{
    //FastCollectAncConfigHeu2(nodeId, setOrigCfgs, listAncCfgsNew);
    //return;
    
    
    
    
    
    
    
    
    
    
    
    
#if 0
cout << "***FastCollectAncConfigHeu: set of coming lineages\n";
for( set< ApproxGeneTreeProbAncConfig > :: iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
{
(*it).Dump();
}
#endif
    // idea: don't consider more configs if the cfgs from current round are not significant comparing to what we have now
    double lenOrig = treeSpecies.GetEdgeLen(nodeId);
    
    // first make all these current cfg to the coalseced target
//#if 0
    
    //** set< ApproxGeneTreeProbAncConfig > listAncCfgsNew;

    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
    {
        double probCoal = CalcCoalCoeffForTwoCfg( lenOrig, *it, *it );
        ApproxGeneTreeProbAncConfig cfgNew = *it;
        ApproxGeneTreeProbAncConfigHistCoal *pCoalHist = new ApproxGeneTreeProbAncConfigHistCoal;
        pCoalHist->AddDependent( &(*it), probCoal );
        cfgNew.AddHist( pCoalHist );
#ifndef LOG_CFG_PROB
        cfgNew.SetProb( it->GetProb()*probCoal );
#else
        double logprobcoal = MAX_NEG_DOUBLE_VAL;
        if( probCoal > 0.0 )
        {
            logprobcoal = log(probCoal);
        }
        cfgNew.SetLogProb( it->GetLogProb() + logprobcoal );
#endif
        listAncCfgsNew.insert(cfgNew);
        
#if 0 //**
        if( IsCfgTooManyCoalLins( cfgNew, cfgNew, lenOrig ) == false )
        {
            listAncCfgsNewRes.insert(cfgNew);
        }
        //else
        //{
        //    //cout << "Skipped1\n";
        //}
#endif //**
    }
//#endif
    
    // find all reachable ACs and merge them if needed
    // start from ones with smaller number of lineages
    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
    {
//cout << "^^^^^^^^^^^^FastCollectAncConfigHeu: processing: ";
//(*it).Dump();
        set<ApproxGeneTreeProbAncConfig> setCfgsReached;
        set<const ApproxGeneTreeProbAncConfig *> setActiveCoalCfgs;
        setActiveCoalCfgs.insert( &(*it) );
        //bool fCont = false;
        //int round = 1;
        while(setActiveCoalCfgs.size() > 0)
        {
//cout << "One iteration.....\n";
            set< ApproxGeneTreeProbAncConfig > setCoalCfgs;
            ApproxGeneTreeProbAncConfig :: FindCoalsableCfgsFrom( *this, lenOrig, setActiveCoalCfgs, setCfgsReached, setCoalCfgs );
            
            // explore from those that have not been see before
            setActiveCoalCfgs.clear();
            for( set<ApproxGeneTreeProbAncConfig> :: iterator it2 = setCoalCfgs.begin(); it2 != setCoalCfgs.end(); ++it2 )
            {
//cout << "++Processing one reachable cfg: \n";
//it2->Dump();
                setCfgsReached.insert( *it2 );
                
                double probCoal = CalcCoalCoeffForTwoCfg( lenOrig, *it, *it2 );
//cout << "probCoal:" << probCoal << ", it2: ";
//(it2)->Dump();
//cout << "it: ";
//it->Dump();
                ApproxGeneTreeProbAncConfig &lc2ref = const_cast< ApproxGeneTreeProbAncConfig & >( *it2 );
#ifndef LOG_CFG_PROB
                lc2ref.SetProb( it->GetProb()*probCoal );
#else
                double logprobcoal = MAX_NEG_DOUBLE_VAL;
                if( probCoal > 0.0 )
                {
                    logprobcoal = log(probCoal);
                }
                lc2ref.SetLogProb( it->GetLogProb() + logprobcoal );
#endif
                
                // recall history
                ApproxGeneTreeProbAncConfig *pcfgcurr = const_cast<ApproxGeneTreeProbAncConfig *>(&(*it2));
                ApproxGeneTreeProbAncConfigHistCoal *pCoalHist = dynamic_cast<ApproxGeneTreeProbAncConfigHistCoal *>(pcfgcurr->GetHist());
                YW_ASSERT_INFO( pCoalHist != NULL, "Cannot be NULL3" );
                pCoalHist->AddDependent( &(*it), probCoal );

                //bool fTooFewLins = IsCfgTooFewCoalLins( *it2, *it, lenOrig );
                
#if 0 //**
                // find it already
                bool fTooManyLins = IsCfgTooManyCoalLins( *it2, *it, lenOrig );
                bool fTooFewLins = IsCfgTooFewCoalLins( *it2, *it, lenOrig );
                if( fTooFewLins == false && fTooManyLins == false )
                {
                    // is this cfg already reached?
                    if( listAncCfgsNewRes.find( *it2 ) == listAncCfgsNewRes.end() )
                    {
                        listAncCfgsNewRes.insert( *it2 );
                    }
                    else
                    {
                        //
                        YW_ASSERT_INFO( listAncCfgsNewRes.find( *it2 ) != listAncCfgsNewRes.end(), "Cannot be null1" );
                        ApproxGeneTreeProbAncConfig &lcTot = const_cast< ApproxGeneTreeProbAncConfig & >( *listAncCfgsNewRes.find( *it2 ) );
                        //double probCur = lcTot.GetProb();
#ifndef LOG_CFG_PROB
                        lcTot.SetProb( lcTot.GetProb()+(*it2).GetProb());
#else
                        lcTot.SetLogProb( GetLogSumOfTwo( lcTot.GetLogProb(), (*it2).GetLogProb() )  );
#endif
                        YW_ASSERT_INFO( lcTot.GetHist() != NULL, "Cannot be NULL4" );
                        lcTot.GetHist()->MergeWith( *((*it2).GetHist()) );
                    }
                }
                else
                {
                    //cout << "Skipped2\n";
                }
#endif  //**
                
                bool fContExpFromThis = false;
                if( listAncCfgsNew.find( *it2 ) == listAncCfgsNew.end()  )
                {
                    //
                    listAncCfgsNew.insert(*it2);
                    
                    // if new config is reached, continue
                    //fCont = true;
                    //**if( fTooFewLins == false )
                    //**{
                    fContExpFromThis = true;
                    //**}
                    //**else
                    //**{
                    //**    //cout << "early stop\n";
                    //**}
                }
//#if 0 // YW: 06/13/16 only allow the first time insertion
                else
                {
                    // update it
                    YW_ASSERT_INFO( listAncCfgsNew.find( *it2 ) != listAncCfgsNew.end(), "Cannot be null2" );
                    ApproxGeneTreeProbAncConfig &lcTot = const_cast< ApproxGeneTreeProbAncConfig & >( *listAncCfgsNew.find( *it2 ) );
                    //double probCur = lcTot.GetProb();
#ifndef LOG_CFG_PROB
                    lcTot.SetProb( lcTot.GetProb()+(*it2).GetProb());
#else
                    lcTot.SetLogProb( GetLogSumOfTwo( lcTot.GetLogProb(), (*it2).GetLogProb() )  );
#endif
                    YW_ASSERT_INFO( lcTot.GetHist() != NULL, "Cannot be NULL4" );
                    lcTot.GetHist()->MergeWith( *((*it2).GetHist()) );
                    //if( lcTot.GetProb() > this->minFracInProb*probCur )
                    //{
                        // YW: 05/02/16, for now don't allow it to go much further
                        //fCont = true;
                        //fContExpFromThis = true;
                    //}
                    //listAncCfgsNew.erase( *it2 );
                    //listAncCfgsNew.insert( lcTot );
//cout << "After updating, it2: ";
//it2->Dump();
                }
//#endif  // YW: 06/13/16
                if( fContExpFromThis == true )
                {
                    YW_ASSERT_INFO( listAncCfgsNew.find( *it2 ) != listAncCfgsNew.end(), "Cannot be null3" );
                    setActiveCoalCfgs.insert( &(*listAncCfgsNew.find(*it2)) );
                }
            }
            
            //if( fCont == false )
            //{
            //     if( setCoalCfgs.size() > 0 )
            //     {
//cout << "****************** EARLY BREAK....\n";
            //   }
            //    break;
            //}
            
            //if( ++round > this->maxRoundsPerAC)
            //{
            //    break;
            //}
        }
    }
#if 0  //**
    if( listAncCfgsNewRes.size() == 0 )
    {
        // if there is nothing found, add the current cfgs that have the largest coalescent events
        int numLinsMin = HAP_MAX_INT;
        for( set< ApproxGeneTreeProbAncConfig > :: iterator it = listAncCfgsNew.begin(); it != listAncCfgsNew.end(); ++it )
        {
            int numLins = it->GetTotNumLins();
            if( numLinsMin > numLins)
            {
                numLinsMin = numLins;
            }
        }
        for( set< ApproxGeneTreeProbAncConfig > :: iterator it = listAncCfgsNew.begin(); it != listAncCfgsNew.end(); ++it )
        {
            int numLins = it->GetTotNumLins();
            if( numLinsMin + GetRangeExpCoal() >= numLins)
            {
                listAncCfgsNewRes.insert(*it);
            }
        }
        YW_ASSERT_INFO( listAncCfgsNewRes.size() > 0, "Cannot be NULL" );
    }
#endif //**
    
    
#if 0
cout << "***After this config, list of ancestral configs so far***\n";
for( set< ApproxGeneTreeProbAncConfig > :: iterator it = listAncCfgsNew.begin(); it != listAncCfgsNew.end(); ++it )
{
(*it).Dump();
}
cout << "Done: FastCollectAncConfigHeu\n";
#endif
}


void ApproxGeneTreeProbHelper :: FastCollectAncConfigHeu2( int nodeId, const set<ApproxGeneTreeProbAncConfig> &setOrigCfgs, set< ApproxGeneTreeProbAncConfig > &listAncCfgsNew )
{
#if 0
    cout << "***FastCollectAncConfigHeu: set of coming lineages\n";
    for( set< ApproxGeneTreeProbAncConfig > :: iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
    {
        (*it).Dump();
    }
#endif
    // idea: don't consider more configs if the cfgs from current round are not significant comparing to what we have now
    double lenOrig = treeSpecies.GetEdgeLen(nodeId);
    
    // first make all these current cfg to the coalseced target
    set<ApproxGeneTreeProbAncConfig> setActiveCfgsToExp;
    map<const ApproxGeneTreeProbAncConfig *, set< const ApproxGeneTreeProbAncConfig * > > mapActiveCfgSrcList;
    
    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = setOrigCfgs.begin(); it != setOrigCfgs.end(); ++it )
    {
        ApproxGeneTreeProbAncConfig cfgNew = *it;
        ApproxGeneTreeProbAncConfigHistCoal *pCoalHist = new ApproxGeneTreeProbAncConfigHistCoal;
        cfgNew.AddHist( pCoalHist );

        setActiveCfgsToExp.insert(cfgNew);
        set< const ApproxGeneTreeProbAncConfig * > ss;
        ss.insert( &(*it) );
        mapActiveCfgSrcList.insert( map<const ApproxGeneTreeProbAncConfig *, set< const ApproxGeneTreeProbAncConfig * > > :: value_type( &( *setActiveCfgsToExp.find(cfgNew)), ss ) );
    }
    
    // explore from the one w/ largest num of lineages (and store it)
    while( setActiveCfgsToExp.size() > 0 )
    {
        // ins (and remove) the active cfg w/ largest num of lins
        set<const ApproxGeneTreeProbAncConfig *> setActiveCfgPtrsStep;
        const ApproxGeneTreeProbAncConfig *pCfgNew = &(*setActiveCfgsToExp.rbegin());
        setActiveCfgPtrsStep.insert( pCfgNew );
        
        //
        set< ApproxGeneTreeProbAncConfig > setCoalCfgs;
        set< ApproxGeneTreeProbAncConfig > setCfgsReached;  // always empty
        ApproxGeneTreeProbAncConfig :: FindCoalsableCfgsFrom( *this, lenOrig, setActiveCfgPtrsStep, setCfgsReached, setCoalCfgs );
        
        // add this cfg to resulting list
        ApproxGeneTreeProbAncConfig *pCfgNewNC = const_cast< ApproxGeneTreeProbAncConfig * >(pCfgNew);
#ifndef LOG_CFG_PROB
        pCfgNewNC->SetProb( 0.0 );
#else
        pCfgNewNC->SetLogProb( MAX_NEG_DOUBLE_VAL);
#endif
        
        YW_ASSERT_INFO( mapActiveCfgSrcList.find(pCfgNew)!=mapActiveCfgSrcList.end(), "Fail" );
        YW_ASSERT_INFO( mapActiveCfgSrcList[pCfgNew].size() >0, "Must have at least one source" );
        set<const ApproxGeneTreeProbAncConfig *> :: const_iterator it2 = mapActiveCfgSrcList[pCfgNew].begin();
        for( ; it2 != mapActiveCfgSrcList[pCfgNew].end(); ++it2 )
        {
            double probCoal = CalcCoalCoeffForTwoCfg( lenOrig, *(*it2), *pCfgNew );
//cout << "probCoal:" << probCoal << ", it2: ";
//(*it2)->Dump();
//cout << "pcfgNew: ";
//pCfgNew->Dump();
            ApproxGeneTreeProbAncConfig &lc2ref = const_cast< ApproxGeneTreeProbAncConfig & >( *pCfgNew );
#ifndef LOG_CFG_PROB
            lc2ref.SetProb( (*it2)->GetProb()*probCoal + lc2ref.GetProb() );
#else
            double logprobcoal = MAX_NEG_DOUBLE_VAL;
            if( probCoal > 0.0 )
            {
                logprobcoal = log(probCoal);
            }
            lc2ref.SetLogProb( GetLogSumOfTwo( (*it2)->GetLogProb() + logprobcoal, lc2ref.GetLogProb() ) );
#endif
            
            ApproxGeneTreeProbAncConfigHistCoal *pCoalHist = dynamic_cast<ApproxGeneTreeProbAncConfigHistCoal *>(pCfgNew->GetHist());
            YW_ASSERT_INFO( pCoalHist != NULL, "Cannot be NULL3" );
            pCoalHist->AddDependent( (*it2), probCoal );
        }
//cout << "After probability computation: pcfgNew: ";
//pCfgNew->Dump();
        listAncCfgsNew.insert( *pCfgNew );
        
        // proc each reached cfg to add to active list if it is new; otherwise add to the src list only
        for( set<ApproxGeneTreeProbAncConfig> :: iterator it = setCoalCfgs.begin(); it != setCoalCfgs.end(); ++it )
        {
            if( setActiveCfgsToExp.find(*it) == setActiveCfgsToExp.end() )
            {
                setActiveCfgsToExp.insert(*it);
            }
            
            if( mapActiveCfgSrcList.find( &(*setActiveCfgsToExp.find(*it) ) ) == mapActiveCfgSrcList.end() )
            {
                set< const ApproxGeneTreeProbAncConfig * > ss = mapActiveCfgSrcList[pCfgNew];
                 mapActiveCfgSrcList.insert( map<const ApproxGeneTreeProbAncConfig *, set< const ApproxGeneTreeProbAncConfig * > > :: value_type( &( *setActiveCfgsToExp.find(*it)), ss ) );
            }
            else
            {
                // union the two sets
                UnionSetsGen(  mapActiveCfgSrcList[  &(*setActiveCfgsToExp.find(*it) ) ], mapActiveCfgSrcList[pCfgNew]  );
            }
        }
        
        // remove the current last
        setActiveCfgsToExp.erase( *setActiveCfgsToExp.rbegin() );
    }
    
#if 0
    cout << "***After this config, list of ancestral configs so far***\n";
    for( set< ApproxGeneTreeProbAncConfig > :: iterator it = listAncCfgsNew.begin(); it != listAncCfgsNew.end(); ++it )
    {
        (*it).Dump();
    }
    cout << "Done: FastCollectAncConfigHeu\n";
#endif
}



void ApproxGeneTreeProbHelper :: ClearBranchLenCache()
{
    // do nothing for now
}

void ApproxGeneTreeProbHelper :: CombineTwoACs( int nid, const ApproxGeneTreeProbAncConfig &linsGT1, const ApproxGeneTreeProbAncConfig &linsGT2, ApproxGeneTreeProbAncConfig &linConfig ) const
{
#if 0
cout << "CombineTwoACs: cfg1: ";
linsGT1.Dump();
cout << "cfg2: ";
linsGT2.Dump();
#endif
    YW_ASSERT_INFO( nid<(int)listSTLinClusterRootMap.size(), "Not init" );
    //
    linConfig.Clear();
    YW_ASSERT_INFO( nid<(int)listSTLinClusterList.size(), "Overflow" );
//cout << "listSTLinClusterList[nid].size(): " << listSTLinClusterList[nid].size() << endl;
    for(int i=0; i<(int) listSTLinClusterList[nid].size(); ++i )
    {
        //
        linConfig.AddLinCluster(0);
    }
    // add the two
    //ApproxGeneTreeProbHelper *pthis=const_cast<ApproxGeneTreeProbHelper *>(this);
    
    const ApproxGeneTreeProbAncConfig *pCfgArray[2] = { &linsGT1, &linsGT2 };
    for(int jj=0; jj<2; ++jj)
    {
        const vector<int> &clusCount1 = pCfgArray[jj]->GetClusCounts();
        int nidChild1 = pCfgArray[jj]->GetNodeId();
//cout << "Round: " << jj << ", nidChild: " << nidChild1 << ", clusCount1: ";
//DumpIntVec(clusCount1);
        for(int i=0; i<(int)clusCount1.size(); ++i )
        {
            YW_ASSERT_INFO( i <(int)this->listSTLinClusterList[ nidChild1 ].size(), "Overflow2" );
            TreeNode *prootc = this->listSTLinClusterList[ nidChild1 ][i].GetClusterRoot();
            //YW_ASSERT_INFO( pthis->listSTLinClusterRootMap[nid].find(prootc) != pthis->listSTLinClusterRootMap[nid].end(), "Fail to find" );
            int pos = FindClusterFor( nid, prootc );
//cout << "Root index: " << pos << ", root: ";
//prootc->Dump();
            linConfig.AddLinClusterAt(pos, clusCount1[i] );
        }
    }
//
//cout << "After merging: the config is: ";
//linConfig.Dump();
}

void ApproxGeneTreeProbHelper :: ConvDescACToParAC( int nidPar, const ApproxGeneTreeProbAncConfig &linsGTDesc, ApproxGeneTreeProbAncConfig &linConfigPar ) const
{
    //
    linConfigPar.Clear();
#ifndef LOG_CFG_PROB
    linConfigPar.SetProb(linsGTDesc.GetProb());
#else
    linConfigPar.SetLogProb( linsGTDesc.GetLogProb() );
#endif
    YW_ASSERT_INFO( nidPar<(int)listSTLinClusterList.size(), "Overflow" );
    //cout << "listSTLinClusterList[nid].size(): " << listSTLinClusterList[nid].size() << endl;
    for(int i=0; i<(int) listSTLinClusterList[nidPar].size(); ++i )
    {
        //
        linConfigPar.AddLinCluster(0);
    }
    const vector<int> &clusCount1 = linsGTDesc.GetClusCounts();
    int nidChild1 = linsGTDesc.GetNodeId();
    for(int i=0; i<(int)clusCount1.size(); ++i )
    {
        YW_ASSERT_INFO( i <(int)this->listSTLinClusterList[ nidChild1 ].size(), "Overflow2" );
        TreeNode *prootc = this->listSTLinClusterList[ nidChild1 ][i].GetClusterRoot();
        //YW_ASSERT_INFO( pthis->listSTLinClusterRootMap[nid].find(prootc) != pthis->listSTLinClusterRootMap[nid].end(), "Fail to find" );
        int pos = FindClusterFor( nidPar, prootc );
        //cout << "Root index: " << pos << ", root: ";
        //prootc->Dump();
        linConfigPar.AddLinClusterAt(pos, clusCount1[i] );
    }
}

int ApproxGeneTreeProbHelper :: FindClusterFor( int nidDest, TreeNode *pRootDesc ) const
{
    
//cout << "FindClusterFor: nidDest: "  << nidDest << ", pRootDesc: ";
//pRootDesc->Dump();
    // nidDest: the species tree we want this cluster to merge into
    // pRootDesc: the cluster to be merged
    // goal: find which lineage cluster this descendent belongs to
    ApproxGeneTreeProbHelper *pthis=const_cast<ApproxGeneTreeProbHelper *>(this);
    
    pair<int,TreeNode *> pp( nidDest, pRootDesc );
    map<pair<int,TreeNode *>, int> :: iterator it2 =  pthis->mapCLusterRoots.find(pp);
    if( it2 != pthis->mapCLusterRoots.end() )
    {
        //
//cout << "FindClusterFor: cache: " << it2->second << endl;
        return it2->second;
    }    
    
    map< TreeNode *, int > :: iterator it = pthis->listSTLinClusterRootMap[nidDest].find(pRootDesc);
    int res = -1;
    if( it != pthis->listSTLinClusterRootMap[nidDest].end() )
    {
//cout << "Belong to this node.\n";
        //
        res = it->second;
    }
    else
    {
//cout << "Absorbed.\n";
        map< TreeNode *, int> :: const_iterator it2 = listAborbedTreeNodes[nidDest].find(pRootDesc);
        YW_ASSERT_INFO( it2 != listAborbedTreeNodes[nidDest].end(), "Fail to find2" );
        res = it2->second;
#if 0
        // find the one which is ancestral this node
        int res = -1;
        for(int i=0; i<(int)listSTLinClusterList[nidDest].size(); ++i )
        {
            //
            TreeNode *prootAnc = listSTLinClusterList[nidDest][i].GetClusterRoot();
            if( IsNodeDesc(prootAnc, pRootDesc) == true )
            {
                //
                res = i;
                break;
            }
        }
        YW_ASSERT_INFO( res >=0, "Fail to find" );
#endif
        //return res;
    }
//cout << "FindCluster: res=" << res << endl;
    pthis->mapCLusterRoots.insert( map<pair<int,TreeNode *>, int> :: value_type( pp, res ));
    return res;
}

bool ApproxGeneTreeProbHelper :: IsNodeDesc( TreeNode *nodeAnc, TreeNode *nodeDesc ) const
{
    //
    YW_ASSERT_INFO( mapGTNodeDesc.find(nodeAnc) != mapGTNodeDesc.end(), "Fail22" );
    const set<TreeNode *> &setNodesRef = mapGTNodeDesc.find(nodeAnc)->second;
    return setNodesRef.find( nodeDesc ) != setNodesRef.end();
}

double ApproxGeneTreeProbHelper :: CalcCoalCoeffForTwoCfg( const ApproxGeneTreeProbAncConfig &linCfgSrc, const ApproxGeneTreeProbAncConfig &linCfgDest ) const
{
    if( fVerboseMode == true )
    {
        cout << "CalcCoalCoeffForTwoCfg: src cfg = ";
        linCfgSrc.Dump();
        cout << "CalcCoalCoeffForTwoCfg: dest cfg = ";
        linCfgDest.Dump();
    }
    YW_ASSERT_INFO(linCfgSrc.GetNodeId() == linCfgDest.GetNodeId(), "Must be from the same species tree node");
    
	// given two configurations, what is the coefficient term for the combinatorial factor
	// used in probability computation (see Degnan's paper)
	// first get the set of events
    int ub = linCfgSrc.GetTotNumLins();
	int cb = ub-linCfgDest.GetTotNumLins();
	//double res = 1.0/CalcdbVal(ub, cb);
	double res = 1.0;
    //double coeff = 1.0;
    //if( GSTPIsHeuModeOn() == true )
    //{
    //    res *= CalcwbValMultiHeu( listEvts, linCfgSrc, ub, cb );
    //}
    //else
    //{
    res = 1.0/CalcdbVal(ub, cb);
//cout << "** coeff after dbVal: " << res << endl;
    res *= CalcwbVal( ub, cb);
    //}
	return res;
}

double ApproxGeneTreeProbHelper :: CalcCoalCoeffForTwoCfg( double lenBranch, const ApproxGeneTreeProbAncConfig &linCfgSrc, const ApproxGeneTreeProbAncConfig &linCfgDest ) const
{
    //
    double coeff = CalcCoalCoeffForTwoCfg( linCfgSrc, linCfgDest );
    int numLinsPrior = linCfgSrc.GetTotNumLins();
    int numLinsAfter = linCfgDest.GetTotNumLins();
    double probCoal = CalcCoalProbBranch( numLinsPrior, numLinsAfter, lenBranch );
    return probCoal * coeff;
}

double ApproxGeneTreeProbHelper :: CalcdbVal(int ub, int cb) const
{
    //if( ub < cb + 1)
    //{
    //cout << "CalcdbVal: ub=" << ub << ", cb=" << cb << endl;
    //}
	YW_ASSERT_INFO(  ub >= cb+1, "Can not coalescent more than the number of lineages" );
    
    //return ApproxGeneTreeProbPreCompute :: Instance().CalcdbVal(ub,cb);
    
//#if 0
	// cahce to avoid redundnet computation
#if 0
    static pthread_mutex_t mutdbVal;
    static bool fInitMut = false;
    if( fInitMut == false )
    {
        pthread_mutex_init(&mutdbVal, NULL);
        fInitMut = true;
    }
#endif
    
    map< pair<int,int>, double> &mapdbValsUse = ApproxGTPCache :: Instance().GetdbValCache( GetThreadId() );
    
	//static map< pair<int,int>, double> mapdbVals;
	pair<int,int> pp(ub,cb);
    double res;
    //pthread_mutex_lock(&mutdbVal);
    map< pair<int,int>, double> :: iterator it = mapdbValsUse.find( pp);
	if( it != mapdbValsUse.end() )
	{
		res = it->second;
        //pthread_mutex_unlock(&mutdbVal);
        return res;
	}
    
	// this is the number of all possible coalescents for ub lineages that will undergo cb coalescents
    res = 1.0;
	for( int i=0; i<cb; ++i )
	{
		res *= 0.5*(ub-i)*(ub-i-1);
	}

	mapdbValsUse.insert( map< pair<int,int>, double> :: value_type(pp, res) );
    //pthread_mutex_unlock(&mutdbVal);
	return res;
//#endif
}


double ApproxGeneTreeProbHelper :: CalcwbVal( int ub, int cb ) const
{
    //cout << "CalcwbVal: num events = " << listEvts.size() << endl;
    //for(int i=0; i<(int)listEvts.size();++i)
    //{
    //listEvts[i].Dump();
    //}
    //return ApproxGeneTreeProbPreCompute :: Instance().CalcwbVal( ub, cb );
//#if 0
    //static map< pair<int,int>, double> mapwbVals;
#if 0
    static pthread_mutex_t mutwbval;
    static bool fInitMut = false;
    if( fInitMut == false )
    {
        pthread_mutex_init(&mutwbval, NULL);
        fInitMut = true;
    }
#endif
    
    map< pair<int,int>, double> &mapwbValsUse = ApproxGTPCache :: Instance().GetwbValCache( GetThreadId() );
    
	pair<int,int> pp(ub,cb);
    map< pair<int,int>, double> :: iterator it = mapwbValsUse.find( pp);
    //pthread_mutex_lock(&mutwbval);
	if( it != mapwbValsUse.end() )
	{
		double res = it->second;
        //pthread_mutex_unlock(&mutwbval);
        return res;
	}
    //pthread_mutex_unlock(&mutwbval);
    
	double res = 1.0;
	int numEvts = cb;
	for(int i=1; i<=numEvts; ++i)
	{
		res *= i;
	}
	if( ub >= 0 && cb >= 0)
	{
		for( int i=0; i<cb; ++i )
		{
			res *= 2.0/((ub-i)*(ub-i-1) );
		}
	}
    
    // now include the fake branch factors
    // simplifying assumption: all cb events involves ub-cb+1 lineages
    int vb = ub-cb;
    int numLinsNotUsed = vb-1;
    //res *= CalcBranchFactorAtFake( 1, ub-numLinsNotUsed, ub-numLinsNotUsed );
    for(int i=0; i<cb; ++i)
    {
        res *= 1.0/( ub-numLinsNotUsed-i-1 );
    }
    
    //cout << "*************Final results = " << res << endl;
    //pthread_mutex_lock(&mutwbval);
    mapwbValsUse.insert( map< pair<int,int>, double> :: value_type(pp, res) );
    //pthread_mutex_unlock(&mutwbval);
	return res;
//#endif
}

#if 0
double ApproxGeneTreeProbHelper :: CalcBranchFactorAtFake(int numDupEvts, int numDescLins, int numActiveLins) const
{
    // compute a fake gene tree branching factor since we don't really
    // know the exact topology we are dealing here
    // calculate the coalescent coefficient for a set of coalescent evets
    // YW: 

    //cout << "***CalcBranchFactorAt: numDupEves = " << numDupEvts  << ", numActiveLins = " << numActiveLins << ", sDescs = ";
    //DumpIntSet( sDescs );
    
    YW_ASSERT_INFO( numDupEvts == 1, "For now only allow exactly one event" );
    YW_ASSERT_INFO( numActiveLins >= 2, "Must have at least two lineages in coalescents" );
    
    // for now simply return a simple product
    double res = 1.0;
    for(int i=0; i<numActiveLins; ++i)
    {
        res *= 1.0/( numDescLins-i );
    }
    return res;
}
#endif

int ApproxGeneTreeProbHelper :: GetTaxaAtLeafST(int snid)
{
    if( treeSpecies.IsLeaf(snid) == false )
    {
        return -1;
    }
    //cout << "GetTaxaAtLeafST: " << snid << endl;
	// get the taxa id from a particular leaf node of species tree
	// treat the species tree label
	//YW_ASSERT_INFO( treeSpecies.IsLeaf(snid) == true, "Must be a leaf1" );
	return treeSpecies.GetLabel(snid);
}

void ApproxGeneTreeProbHelper :: GetLeafLinCountsAtSTNode(int nid, vector<int> &listCounts) const
{
    listCounts = this->listSTLinClusterSizeList[nid];
}

double ApproxGeneTreeProbHelper :: CalcCoalProbBranch( int u, int v, double len ) const
{
    //return ApproxGeneTreeProbPreCompute :: Instance().CalcCoalProbBranch( u, v, len);
//#if 0
    
    map< pair<pair<int,int>,int>, double > &mapBrProbsUse = ApproxGTPCache :: Instance().GetBrProbCache( GetThreadId() );
    
    int grid = ConvDistToGrid(len);
    
	// have we computed it already?
	pair<int, int> puv(u,v);
	pair< pair<int,int>, int> ppp(puv,grid);
    //static map< pair<pair<int,int>,double>, double > cacheBranchProb;
    double res;
    map< pair<pair<int,int>,int>, double > :: iterator it =  mapBrProbsUse.find( ppp);
	if( it != mapBrProbsUse.end()  )
	{
        //cout << "Cache hit\n";
		// done
        res = it->second;
	}
    else
    {
        res = UtilsCalcCoalProbBranch(u, v, len);
    	// save to cache
        mapBrProbsUse.insert( map< pair<pair<int,int>,int>, double > :: value_type(ppp, res) );
    }
    
    //cout << ": prob = " << res << endl;
	return res;
//#endif
}

int ApproxGeneTreeProbHelper :: ConvDistToGrid(double dist) const
{
    //
    return (int)(dist*distFactor);
}

double ApproxGeneTreeProbHelper :: ConvGridToDist(int grid) const
{
    //
    return (double)grid/distFactor;
}

void ApproxGeneTreeProbHelper :: ConsLinearArrayOfDescCfgsToParCfgsAt(int nodeSTDesc, const set< ApproxGeneTreeProbAncConfig > &cfgDescList, vector<double> &vecProbCfgs) const
{
#if 0
cout << "***ConsLinearArrayOfDescCfgsToParCfgsAt: set of cfgs:\n";
for( set< ApproxGeneTreeProbAncConfig > :: iterator it = cfgDescList.begin(); it != cfgDescList.end(); ++it )
{
(*it).Dump();
}
#endif
    // given list of cfgs collected at a descendent ST branch (marked as nodeSTDesc)
    // construct a linear array of cfg probs that are in parent node's lineage settings
    vecProbCfgs.clear();
    int nodeSTPar = treeSpecies.GetParent( nodeSTDesc );
    int szCfgArray = GetNumCfgsAt( nodeSTPar );
    vecProbCfgs.resize( szCfgArray );
    for(int i=0; i<szCfgArray; ++i)
    {
#ifndef LOG_CFG_PROB
        vecProbCfgs[i] = 0.0;
#else
        vecProbCfgs[i] = MAX_NEG_DOUBLE_VAL;
#endif
    }
    //
    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = cfgDescList.begin(); it != cfgDescList.end(); ++it )
    {
        //
        ApproxGeneTreeProbAncConfig cfgPar(nodeSTPar);
        ConvDescACToParAC( nodeSTPar, *it, cfgPar );
        const vector<int> &listCounts0 = cfgPar.GetClusCounts();
        //cfgPar.GetLinCountsBase0( listCounts0 );
#if 0
//cout << "listCounts0: ";
//DumpIntVec( listCounts0 );
cout << "bound: ";
DumpIntVec(GetCfgBoundsAt(nodeSTPar));
#endif
        
        int posCfgPar = ConvVecToIntGenBounds(listCounts0, GetCfgBoundsAt(nodeSTPar) );
#if 0
vector<int> vecTest;
ConvIntToVecGen( posCfgPar, GetCfgBoundsAt(nodeSTPar), vecTest );
cout << "posCfgPar: " << posCfgPar << ": listCounts0: ";
DumpIntVec( listCounts0 );
cout << "vecTest: ";
DumpIntVec(vecTest);
#endif
        YW_ASSERT_INFO( posCfgPar < szCfgArray, "Overflow" );
#ifndef LOG_CFG_PROB
        vecProbCfgs[posCfgPar] += it->GetProb();
#else
        vecProbCfgs[posCfgPar] = GetLogSumOfTwo( vecProbCfgs[posCfgPar], it->GetLogProb() );
#endif
    }
//cout << "ConsLinearArrayOfDescCfgsToParCfgsAt: list of probablity: ";
//DumpDoubleVec( vecProbCfgs );
}


#if 0
void ApproxGeneTreeProbHelper :: ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad(int nodeST, const set< ApproxGeneTreeProbAncConfig > &cfgDescList, vector<double> &vecProbCfgs) const
{
    // different from above, we use longer vector for zero-padding; useful for FFT based convolution
//#if 0
cout << "***ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad: set of cfgs:\n";
for( set< ApproxGeneTreeProbAncConfig > :: iterator it = cfgDescList.begin(); it != cfgDescList.end(); ++it )
{
    (*it).Dump();
}
//#endif
    // given list of cfgs collected at a descendent ST branch (marked as nodeSTDesc)
    // construct a linear array of cfg probs that are in parent node's lineage settings
    vecProbCfgs.clear();
    int nodeSTPar = treeSpecies.GetParent( nodeST );
    // add each dimension by 1
    vector<int> boundsCfg = GetCfgBoundsAt(nodeSTPar);
    for(int i=0; i<(int)boundsCfg.size(); ++i)
    {
        ++boundsCfg[i];
    }
    vector<int> boundsPad;
    GetMDCZeroPadDims( boundsCfg, boundsPad );
//cout << "original bounds: ";
//DumpIntVec( boundsCfg );
//cout << "boundsPad: ";
//DumpIntVec( boundsPad );
    int szCfgArray = CalcProductOfVec( boundsPad );
    vecProbCfgs.resize( szCfgArray );
    for(int i=0; i<szCfgArray; ++i)
    {
        vecProbCfgs[i] = 0.0;
    }
    //
    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = cfgDescList.begin(); it != cfgDescList.end(); ++it )
    {
        //
        ApproxGeneTreeProbAncConfig cfgPar(nodeSTPar);
        ConvDescACToParAC( nodeSTPar, *it, cfgPar );
        const vector<int> &listCounts0 = cfgPar.GetClusCounts();
        
        int posCfgPar = ConvRowMajorPosVecToIntGenBounds(listCounts0, boundsPad );
        //#if 0
        //vector<int> vecTest;
        //ConvIntToVecGen( posCfgPar, GetCfgBoundsAt(nodeSTPar), vecTest );
//cout << "posCfgPar: " << posCfgPar << ": listCounts0: ";
//DumpIntVec( listCounts0 );
        //cout << "vecTest: ";
        //DumpIntVec(vecTest);
        //#endif
        YW_ASSERT_INFO( posCfgPar < szCfgArray, "Overflow" );
        vecProbCfgs[posCfgPar] += it->GetProb();
    }
//cout << "ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad: list of probablity: ";
//DumpDoubleVec( vecProbCfgs );
}
#endif

int ApproxGeneTreeProbHelper :: GetNumCfgsAt(int nodeST) const
{
    //
    //int res = 1;
    //for(int i=0; i<(int)listSTLinClusterSizeList[nodeST].size(); ++i )
    //{
    //    res *= listSTLinClusterSizeList[nodeST][i] + 1;
    //}
    return this->listNumCfgsAtStNodes[nodeST];
}

int ApproxGeneTreeProbHelper :: GetNumCfgsAtDirect(int nodeST) const
{
    //
    int res = 1;
    for(int i=0; i<(int)listSTLinClusterSizeList[nodeST].size(); ++i )
    {
        res *= listSTLinClusterSizeList[nodeST][i] + 1;
    }
    return res;
}

//#define FFT_CONVOLUTION 1

void ApproxGeneTreeProbHelper :: ConsLinearArrayOfTwoDescCfgsToParCfgsAt(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const
{
    ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect2(nodeSTPar, cfgListDescLeft, cfgListDescRight, setCfgsMerged);
    
#if 0
    // when there is a single cfg on either side (or the convolution problem is small), use direct computation
    // YW: try FFT only for one dimensional problems
    //const int SMALL_NUM_CFG_MULTI = 100;
    if( cfgListDescLeft.size() == 1 || cfgListDescRight.size() == 1 || GetCfgBoundsAt(nodeSTPar).size() > 1 || (int)(cfgListDescLeft.size()*cfgListDescRight.size()) <= maxNumConvolvePairsDirect  )
    {
        // use direct computation
        ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect2( nodeSTPar, cfgListDescLeft, cfgListDescRight, setCfgsMerged );
    }
    else
    {
        // use FFT
        ConsLinearArrayOfTwoDescCfgsToParCfgsAtFFT( nodeSTPar, cfgListDescLeft, cfgListDescRight, setCfgsMerged );
    }
#endif
    
    
#if 0
    //
    vector<double> listProbsDescLeft, listProbsDescRight;
    int nodeLeft = treeSpecies.GetLeftDescendant(nodeSTPar);
    int nodeRight = treeSpecies.GetRightDescendant(nodeSTPar);
#ifdef FFT_CONVOLUTION
    ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad( nodeLeft, cfgListDescLeft, listProbsDescLeft );
    ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad( nodeRight, cfgListDescRight, listProbsDescRight );
    // get bounds
    vector<int> dimsFFT = GetCfgBoundsAt(nodeSTPar);
    // add each dimension by 1
    for(int i=0; i<(int)dimsFFT.size(); ++i)
    {
        ++dimsFFT[i];
    }
#else
    ConsLinearArrayOfDescCfgsToParCfgsAt( nodeLeft, cfgListDescLeft, listProbsDescLeft );
    ConsLinearArrayOfDescCfgsToParCfgsAt( nodeRight, cfgListDescRight, listProbsDescRight );
#endif

    
#if 0
cout << "ConsLinearArrayOfDescCfgsToParCfgsAt: prob vec1: ";
DumpDoubleVec( listProbsDescLeft );
cout << "prob vec2: ";
DumpDoubleVec( listProbsDescRight );
cout << "Bounds at this node: " << nodeSTPar << ": ";
//DumpIntVec( GetCfgBoundsAt(nodeSTPar) );
DumpIntVec( dimsFFT );
#endif
    // do a direct convolution
    vector<double> listProbsConvolute;
    
#ifdef FFT_CONVOLUTION
    MultiDimConvolution(dimsFFT, listProbsDescLeft, listProbsDescRight, listProbsConvolute);
#else
    ///*
    int szCfgsArr = GetNumCfgsAt( nodeSTPar ) + 1;
    listProbsConvolute.resize( szCfgsArr );
    for(int i=0; i<szCfgsArr; ++i)
    {
        listProbsConvolute[i] = 0.0;
    }
    // now add all pairs of values
    for(int i=0; i<(int)listProbsDescLeft.size(); ++i)
    {
        if( listProbsDescLeft[i] <= MIN_POS_VAL )
        //if( listProbsDescLeft[i] <= 0.0 )
        {
            continue;
        }
        vector<int> vecIndexi;
        ConvIntToVecGen( i, GetCfgBoundsAt(nodeSTPar), vecIndexi );
        
        for(int j=0; j<(int)listProbsDescRight.size(); ++j)
        {
            //
            if( listProbsDescRight[j] <= MIN_POS_VAL )
            //if( listProbsDescRight[j] <= 0.0 )
            {
                continue;
            }
            //
            vector<int> vecIndexj;
            ConvIntToVecGen( j, GetCfgBoundsAt(nodeSTPar), vecIndexj );
            
            // add them up
            vector<int> vecIndexij = vecIndexi;
            AddIntVec( vecIndexij, vecIndexj );
            int indexij = ConvVecToIntGenBounds( vecIndexij, GetCfgBoundsAt(nodeSTPar) );
            YW_ASSERT_INFO( indexij < szCfgsArr, "Overflow111" );
            listProbsConvolute[indexij] += listProbsDescLeft[i]*listProbsDescRight[j];
        }
    }
#endif
    //*/
//#if 0
cout << "Results of convolution: ";
DumpDoubleVec( listProbsConvolute );
//#endif
    // now create cfg
    for(int i=0; i<(int)listProbsConvolute.size(); ++i )
    {
        //if( listProbsConvolute[i] > 0.0 )
        if( listProbsConvolute[i] > MIN_POS_VAL )
        {
            //
            vector<int> vecIndex;
#ifdef FFT_CONVOLUTION
            ConvRowMajorIntPosToVecGen( i, dimsFFT, vecIndex );
            // ensure all indices are positive
            bool fZeroFound = false;
            for(int jjj=0; jjj<(int)vecIndex.size(); ++jjj)
            {
                if( vecIndex[jjj] == 0 )
                {
                    fZeroFound = true;
                    break;
                }
            }
            if( fZeroFound ==false )
            {
                ApproxGeneTreeProbAncConfig cfg( nodeSTPar, vecIndex, listProbsConvolute[i] );
                setCfgsMerged.insert( cfg );
            }
#else
            ConvIntToVecGen( i, GetCfgBoundsAt(nodeSTPar), vecIndex );

            ApproxGeneTreeProbAncConfig cfg( nodeSTPar, vecIndex, listProbsConvolute[i] );
            setCfgsMerged.insert( cfg );

#endif


        }
    }
#endif
}

#if 0
void ApproxGeneTreeProbHelper :: ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const
{
    //
    vector<double> listProbsDescLeft, listProbsDescRight;
    int nodeLeft = treeSpecies.GetLeftDescendant(nodeSTPar);
    int nodeRight = treeSpecies.GetRightDescendant(nodeSTPar);
#ifdef FFT_CONVOLUTION
    ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad( nodeLeft, cfgListDescLeft, listProbsDescLeft );
    ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad( nodeRight, cfgListDescRight, listProbsDescRight );
    // get bounds
    vector<int> dimsFFT = GetCfgBoundsAt(nodeSTPar);
    // add each dimension by 1
    for(int i=0; i<(int)dimsFFT.size(); ++i)
    {
        ++dimsFFT[i];
    }
#else
    ConsLinearArrayOfDescCfgsToParCfgsAt( nodeLeft, cfgListDescLeft, listProbsDescLeft );
    ConsLinearArrayOfDescCfgsToParCfgsAt( nodeRight, cfgListDescRight, listProbsDescRight );
#endif
    
    
#if 0
    cout << "ConsLinearArrayOfDescCfgsToParCfgsAt: prob vec1: ";
    DumpDoubleVec( listProbsDescLeft );
    cout << "prob vec2: ";
    DumpDoubleVec( listProbsDescRight );
    cout << "Bounds at this node: " << nodeSTPar << ": ";
    //DumpIntVec( GetCfgBoundsAt(nodeSTPar) );
    DumpIntVec( dimsFFT );
#endif
    // do a direct convolution
    vector<double> listProbsConvolute;
    
#ifdef FFT_CONVOLUTION
    MultiDimConvolution(dimsFFT, listProbsDescLeft, listProbsDescRight, listProbsConvolute);
#else
    ///*
    int szCfgsArr = GetNumCfgsAt( nodeSTPar ) + 1;
    listProbsConvolute.resize( szCfgsArr );
    for(int i=0; i<szCfgsArr; ++i)
    {
        listProbsConvolute[i] = 0.0;
    }
    // now add all pairs of values
    for(int i=0; i<(int)listProbsDescLeft.size(); ++i)
    {
        if( listProbsDescLeft[i] <= MIN_POS_VAL )
            //if( listProbsDescLeft[i] <= 0.0 )
        {
            continue;
        }
        vector<int> vecIndexi;
        ConvIntToVecGen( i, GetCfgBoundsAt(nodeSTPar), vecIndexi );
        
        for(int j=0; j<(int)listProbsDescRight.size(); ++j)
        {
            //
            if( listProbsDescRight[j] <= MIN_POS_VAL )
                //if( listProbsDescRight[j] <= 0.0 )
            {
                continue;
            }
            //
            vector<int> vecIndexj;
            ConvIntToVecGen( j, GetCfgBoundsAt(nodeSTPar), vecIndexj );
            
            // add them up
            vector<int> vecIndexij = vecIndexi;
            AddIntVec( vecIndexij, vecIndexj );
            int indexij = ConvVecToIntGenBounds( vecIndexij, GetCfgBoundsAt(nodeSTPar) );
            YW_ASSERT_INFO( indexij < szCfgsArr, "Overflow111" );
            listProbsConvolute[indexij] += listProbsDescLeft[i]*listProbsDescRight[j];
        }
    }
#endif
    //*/
#if 0
    cout << "Results of convolution: ";
    DumpDoubleVec( listProbsConvolute );
#endif
    // now create cfg
    for(int i=0; i<(int)listProbsConvolute.size(); ++i )
    {
        //if( listProbsConvolute[i] > 0.0 )
        if( listProbsConvolute[i] > MIN_POS_VAL )
        {
            //
            vector<int> vecIndex;
#ifdef FFT_CONVOLUTION
            ConvRowMajorIntPosToVecGen( i, dimsFFT, vecIndex );
            // ensure all indices are positive
            bool fZeroFound = false;
            for(int jjj=0; jjj<(int)vecIndex.size(); ++jjj)
            {
                if( vecIndex[jjj] == 0 )
                {
                    fZeroFound = true;
                    break;
                }
            }
            if( fZeroFound ==false )
            {
                ApproxGeneTreeProbAncConfig cfg( nodeSTPar, vecIndex, listProbsConvolute[i] );
                setCfgsMerged.insert( cfg );
            }
#else
            ConvIntToVecGen( i, GetCfgBoundsAt(nodeSTPar), vecIndex );
            
            ApproxGeneTreeProbAncConfig cfg( nodeSTPar, vecIndex, listProbsConvolute[i] );
            setCfgsMerged.insert( cfg );
            
#endif
            
            
        }
    }

    
    
    
#if 0
    //
    vector<double> listProbsDescLeft, listProbsDescRight;
    int nodeLeft = treeSpecies.GetLeftDescendant(nodeSTPar);
    int nodeRight = treeSpecies.GetRightDescendant(nodeSTPar);
    ConsLinearArrayOfDescCfgsToParCfgsAt( nodeLeft, cfgListDescLeft, listProbsDescLeft );
    ConsLinearArrayOfDescCfgsToParCfgsAt( nodeRight, cfgListDescRight, listProbsDescRight );
    
#if 0
    cout << "ConsLinearArrayOfDescCfgsToParCfgsAt: prob vec1: ";
    DumpDoubleVec( listProbsDescLeft );
    cout << "prob vec2: ";
    DumpDoubleVec( listProbsDescRight );
    cout << "Bounds at this node: " << nodeSTPar << ": ";
    DumpIntVec( GetCfgBoundsAt(nodeSTPar) );
#endif
    // do a direct convolution
    vector<double> listProbsConvolute;
    
    int szCfgsArr = GetNumCfgsAt( nodeSTPar ) + 1;
    listProbsConvolute.resize( szCfgsArr );
    for(int i=0; i<szCfgsArr; ++i)
    {
        listProbsConvolute[i] = 0.0;
    }
    // now add all pairs of values
    for(int i=0; i<(int)listProbsDescLeft.size(); ++i)
    {
        //if( listProbsDescLeft[i] <= MIN_POS_VAL )
        if( listProbsDescLeft[i] <= 0.0 )
        {
            continue;
        }
        vector<int> vecIndexi;
        ConvIntToVecGen( i, GetCfgBoundsAt(nodeSTPar), vecIndexi );
        
        for(int j=0; j<(int)listProbsDescRight.size(); ++j)
        {
            //
            //if( listProbsDescRight[j] <= MIN_POS_VAL )
            if( listProbsDescRight[j] <= 0.0 )
            {
                continue;
            }
            //
            vector<int> vecIndexj;
            ConvIntToVecGen( j, GetCfgBoundsAt(nodeSTPar), vecIndexj );
            
            // add them up
            vector<int> vecIndexij = vecIndexi;
            AddIntVec( vecIndexij, vecIndexj );
            int indexij = ConvVecToIntGenBounds( vecIndexij, GetCfgBoundsAt(nodeSTPar) );
            YW_ASSERT_INFO( indexij < szCfgsArr, "Overflow111" );
            listProbsConvolute[indexij] += listProbsDescLeft[i]*listProbsDescRight[j];
        }
    }

#if 0
    cout << "Results of convolution: ";
    DumpDoubleVec( listProbsConvolute );
#endif
    // now create cfg
    for(int i=0; i<(int)listProbsConvolute.size(); ++i )
    {
        if( listProbsConvolute[i] > 0.0 )
        //if( listProbsConvolute[i] > MIN_POS_VAL )
        {
            //
            vector<int> vecIndex;
            ConvIntToVecGen( i, GetCfgBoundsAt(nodeSTPar), vecIndex );
            
            ApproxGeneTreeProbAncConfig cfg( nodeSTPar, vecIndex, listProbsConvolute[i] );
            setCfgsMerged.insert( cfg );       
            
        }
    }
#endif
}
#endif


void ApproxGeneTreeProbHelper :: ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect2(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const
{
//cout << "ConsLinearArrayOfTwoDescCfgsToParCfgsAtDirect2: \n";
#if 0
    // create mapped cfg and save it
    map<const ApproxGeneTreeProbAncConfig *, ApproxGeneTreeProbAncConfig *> mapDescCfgToParLeft, mapDescCfgToParRight;
    for( set< ApproxGeneTreeProbAncConfig > :: const_iterator it1 = cfgListDescLeft.begin(); it1 != cfgListDescLeft.end(); ++it1  )
    {
        ApproxGeneTreeProbAncConfig *pcfgPar1 = new ApproxGeneTreeProbAncConfig(nodeSTPar);
        ConvDescACToParAC( nodeSTPar, *it1, *pcfgPar1 );
        mapDescCfgToParLeft.insert( map<const ApproxGeneTreeProbAncConfig *, ApproxGeneTreeProbAncConfig *> :: value_type( &(*it1), pcfgPar1 ) );
    }
    for( set< ApproxGeneTreeProbAncConfig > :: const_iterator it1 = cfgListDescRight.begin(); it1 != cfgListDescRight.end(); ++it1  )
    {
        ApproxGeneTreeProbAncConfig *pcfgPar1 = new ApproxGeneTreeProbAncConfig(nodeSTPar);
        ConvDescACToParAC( nodeSTPar, *it1, *pcfgPar1 );
        mapDescCfgToParRight.insert( map<const ApproxGeneTreeProbAncConfig *, ApproxGeneTreeProbAncConfig *> :: value_type( &(*it1), pcfgPar1 ) );
    }
#endif
    // this is the non-convolution version
    // now add all pairs of cfgs
    for(set< ApproxGeneTreeProbAncConfig > :: const_iterator it1 = cfgListDescLeft.begin(); it1 != cfgListDescLeft.end(); ++it1 )
    {
//cout << "Process one cfg on left: ";
//it1->Dump();
        
#if 0 //**
        ApproxGeneTreeProbAncConfig cfgPar1(nodeSTPar);
        ConvDescACToParAC( nodeSTPar, *it1, cfgPar1 );
#endif
        
        const ApproxGeneTreeProbAncConfig &cfgPar1 = *it1;
        //ApproxGeneTreeProbAncConfig *pcfgPar1 = mapDescCfgToParLeft[ &(*it1) ];
        
        for(set< ApproxGeneTreeProbAncConfig > :: const_iterator it2 = cfgListDescRight.begin(); it2 != cfgListDescRight.end(); ++it2)
        {
//cout << "Process one cfg on right: ";
//it2->Dump();
#if 0 //**
            ApproxGeneTreeProbAncConfig cfgPar2(nodeSTPar);
            ConvDescACToParAC( nodeSTPar, *it2, cfgPar2 );
#endif
            const ApproxGeneTreeProbAncConfig &cfgPar2 = *it2;
            //ApproxGeneTreeProbAncConfig *pcfgPar2 = mapDescCfgToParRight[ &(*it2) ];
            
            // append
            //vector<int> vecLinsMerged = pcfgPar1->GetClusCounts();
            vector<int> vecLinsMerged = cfgPar1.GetClusCounts();
            PointwiseAddVectorBy(vecLinsMerged, cfgPar2.GetClusCounts() );
            //PointwiseAddVectorBy(vecLinsMerged, pcfgPar2->GetClusCounts() );
            double probMerged;
            bool fLogMode = false;
#ifndef LOG_CFG_PROB
            probMerged = it1->GetProb() * it2->GetProb();
#else
            probMerged = it1->GetLogProb() + it2->GetLogProb();
            fLogMode = true;
#endif
            ApproxGeneTreeProbAncConfig cfgMerged(nodeSTPar, vecLinsMerged, probMerged, fLogMode);
            ApproxGeneTreeProbAncConfigHistMerge *pHistMerg = new ApproxGeneTreeProbAncConfigHistMerge;
            pHistMerg->AddDependent( &(*it1), &(*it2) );
            cfgMerged.AddHist(pHistMerg);
            set<ApproxGeneTreeProbAncConfig> :: const_iterator itgg=setCfgsMerged.find( cfgMerged );
            if( itgg == setCfgsMerged.end()  )
            {
                setCfgsMerged.insert( cfgMerged );
            }
            else
            {
                // append prob
                ApproxGeneTreeProbAncConfig &cfgExist = const_cast<ApproxGeneTreeProbAncConfig &>( *itgg );
#ifndef LOG_CFG_PROB
                cfgExist.SetProb( cfgExist.GetProb() + cfgMerged.GetProb() );
#else
                cfgExist.SetLogProb( GetLogSumOfTwo( cfgExist.GetLogProb(), cfgMerged.GetLogProb() ) );
#endif
                YW_ASSERT_INFO( cfgExist.GetHist() != NULL, "Cannot be NULL5" );
                cfgExist.GetHist()->MergeWith( *cfgMerged.GetHist() );
            }
        }
    }
//cout << "setCfgsMerged: \n";
//for( set<ApproxGeneTreeProbAncConfig> :: iterator it = setCfgsMerged.begin(); it != setCfgsMerged.end(); ++it)
//{
//it->Dump();
//}
#if 0
    // free spac
    for( map<const ApproxGeneTreeProbAncConfig *, ApproxGeneTreeProbAncConfig *> :: iterator it = mapDescCfgToParLeft.begin(); it != mapDescCfgToParLeft.end(); ++it )
    {
        delete it->second;
    }
    for( map<const ApproxGeneTreeProbAncConfig *, ApproxGeneTreeProbAncConfig *> :: iterator it = mapDescCfgToParRight.begin(); it != mapDescCfgToParRight.end(); ++it )
    {
        delete it->second;
    }
#endif
}


#if 0
void ApproxGeneTreeProbHelper :: ConsLinearArrayOfTwoDescCfgsToParCfgsAtFFT(int nodeSTPar, const set< ApproxGeneTreeProbAncConfig > &cfgListDescLeft, const set< ApproxGeneTreeProbAncConfig > &cfgListDescRight, set< ApproxGeneTreeProbAncConfig > &setCfgsMerged) const
{
    //
    //
    vector<double> listProbsDescLeft, listProbsDescRight;
    int nodeLeft = treeSpecies.GetLeftDescendant(nodeSTPar);
    int nodeRight = treeSpecies.GetRightDescendant(nodeSTPar);

    ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad( nodeLeft, cfgListDescLeft, listProbsDescLeft );
    ConsLinearArrayOfDescCfgsToParCfgsAtZeroPad( nodeRight, cfgListDescRight, listProbsDescRight );
    // get bounds
    vector<int> dimsFFT = GetCfgBoundsAt(nodeSTPar);
    // add each dimension by 1
    for(int i=0; i<(int)dimsFFT.size(); ++i)
    {
        ++dimsFFT[i];
    }    
    
#if 0
    cout << "ConsLinearArrayOfDescCfgsToParCfgsAt: prob vec1: ";
    DumpDoubleVec( listProbsDescLeft );
    cout << "prob vec2: ";
    DumpDoubleVec( listProbsDescRight );
    cout << "Bounds at this node: " << nodeSTPar << ": ";
    DumpIntVec( dimsFFT );
#endif
    // do a direct convolution
    vector<double> listProbsConvolute;
    
    MultiDimConvolution(dimsFFT, listProbsDescLeft, listProbsDescRight, listProbsConvolute);
    //*/
#if 0
    cout << "Results of convolution: ";
    DumpDoubleVec( listProbsConvolute );
#endif
    // now create cfg
    vector<int> vecIndex;
    for(int i=0; i<(int)dimsFFT.size(); ++i)
    {
        //
        vecIndex.push_back(0);
    }
    
    for(int i=0; i<(int)listProbsConvolute.size(); ++i )
    {
        if( listProbsConvolute[i] > 0.0 )
        //if( listProbsConvolute[i] > MIN_POS_VAL )
        {
            //
            //vector<int> vecIndex;
            //ConvRowMajorIntPosToVecGen( i, dimsFFT, vecIndex );
            // ensure all indices are positive
            bool fZeroFound = false;
            for(int jjj=0; jjj<(int)vecIndex.size(); ++jjj)
            {
                if( vecIndex[jjj] == 0 )
                {
                    fZeroFound = true;
                    break;
                }
            }
            if( fZeroFound ==false )
            {
                ApproxGeneTreeProbAncConfig cfg( nodeSTPar, vecIndex, listProbsConvolute[i] );
                setCfgsMerged.insert( cfg );
            }
        }
        
        // get next
        GetNextPosInRowMajorIndices( dimsFFT, vecIndex );
    }
}
#endif

#if 0
const set<ApproxGeneTreeProbAncConfig> * ApproxGeneTreeProbHelper :: FindCoalscedCfgsFrom( const ApproxGeneTreeProbAncConfig &cfgToCoal ) const
{
    //
    map<ApproxGeneTreeProbAncConfig, set<ApproxGeneTreeProbAncConfig> > :: const_iterator it = mapCoalesceCfgs.find( cfgToCoal );
    if( it == mapCoalesceCfgs.end() )
    {
        return NULL;
    }
    else
    {
        return &(it->second);
    }
}

void ApproxGeneTreeProbHelper :: AddCoalescedCfgsFrom( const ApproxGeneTreeProbAncConfig &cfgToCoal, set<ApproxGeneTreeProbAncConfig> &setCoalCfgs )
{
    //
    mapCoalesceCfgs.insert( map<ApproxGeneTreeProbAncConfig, set<ApproxGeneTreeProbAncConfig> > :: value_type( cfgToCoal, setCoalCfgs ) );
}
#endif

int ApproxGeneTreeProbHelper :: GetNumSubCluster( int stNode, const ApproxGeneTreeProbCluster &clus) const
{
    // given a cluster that appears at stNode, find the number of subclusters (i.e. cluster roots that are below this cluster) of it is two descendents)
    int res = 0;
    
    if( this->treeSpecies.IsLeaf(stNode) == true )
    {
        // is simply equal to the cluster size (no coalescent)
        res = clus.GetClusterSize();
    }
    else
    {
        // find the cluster roots of the two desendents
        set<TreeNode *> setDescClusRoots;
        int stDescLeft = this->treeSpecies.GetLeftDescendant(stNode);
        if( stDescLeft >= 0 )
        {
            for(int i=0; i<(int)listSTLinClusterList[stDescLeft].size(); ++i)
            {
                setDescClusRoots.insert( listSTLinClusterList[stDescLeft][i].GetClusterRoot()  );
            }
        }
        int stDescRight = this->treeSpecies.GetRightDescendant(stNode);
        if( stDescRight >= 0 )
        {
            for(int i=0; i<(int)listSTLinClusterList[stDescRight].size(); ++i)
            {
                setDescClusRoots.insert( listSTLinClusterList[stDescRight][i].GetClusterRoot()  );
            }
        }
//cout << "stNode: " << stNode << ", size of setDescClusRoots: " << setDescClusRoots.size() << endl;
//cout << "current cluster: ";
//clus.GetClusterRoot()->Dump();
        stack<TreeNode *> stackClusRoots;
        stackClusRoots.push( clus.GetClusterRoot() );
        
        while( stackClusRoots.empty() == false )
        {
            //
            TreeNode *pnc = stackClusRoots.top();
            stackClusRoots.pop();
            
            if( setDescClusRoots.find(pnc) != setDescClusRoots.end() )
            {
                ++res;
            }
            else
            {
                // consider all the descendents
                for(int i=0; i<pnc->GetChildrenNum(); ++i)
                {
                    stackClusRoots.push( pnc->GetChild(i) );
                }
            }
        }
//cout << "lb=" << res << endl;
    }
    
    return res;
}

int ApproxGeneTreeProbHelper :: GetAncClusIndexForClusIndex(int stNode, int clusIndex) const
{
//cout << "GetAncClusIndexForClusIndex: stNode: " << stNode << ", clusIndex: " << clusIndex << endl;
    //
    TreeNode *pnr = listSTLinClusterList[stNode][clusIndex].GetClusterRoot();
    int stNodePar = this->treeSpecies.GetParent( stNode );
    return FindClusterFor( stNodePar, pnr );
}

int ApproxGeneTreeProbHelper :: CalcExpectedCoalLinNum(int numOrig, double timeCoal )
{
    //
    double res = ((double)numOrig)/( (double)numOrig-(numOrig-1.0)*exp(-timeCoal/2) );
    return RoundToInt(res);
}

//const int DEF_NUM_OFFSET_COAL_LIN_NUM = 3;
const int DEF_MIN_COAL_LIN_CONDITION = 6;
const double DEF_FRAC_OFFSET_COAL_LIN_NUM = 0.1;

int ApproxGeneTreeProbHelper :: GetRangeExpCoal()
{
    return DEF_FRAC_OFFSET_COAL_LIN_NUM;
}

bool ApproxGeneTreeProbHelper :: IsCfgTooManyCoalLins( const ApproxGeneTreeProbAncConfig &cfgCoaled, const ApproxGeneTreeProbAncConfig &cfgOrig, double tLen )
{
//return false;
    
    // when we deal with
    int numLinsCoaled = cfgCoaled.GetTotNumLins();
    int numLinsOrig = cfgOrig.GetTotNumLins();
    if( numLinsOrig < DEF_MIN_COAL_LIN_CONDITION )
    {
        return false;
    }

    int numExpCoal = CalcExpectedCoalLinNum( numLinsOrig, tLen );
    
//cout << "numLinsCoaled:" << numLinsCoaled << ", numLinsOrig:" << numLinsOrig << ", numExpCoal: " << numExpCoal << ", tLen:" << tLen << endl;
    //return ( numLinsCoaled - numExpCoal > DEF_FRAC_OFFSET_COAL_LIN_NUM * numLinsOrig  ) &&
    return ( numLinsCoaled - numExpCoal > GetRangeExpCoal() );
}

bool ApproxGeneTreeProbHelper :: IsCfgTooFewCoalLins( const ApproxGeneTreeProbAncConfig &cfgCoaled, const ApproxGeneTreeProbAncConfig &cfgOrig, double tLen )
{
//return false;
    //
    int numLinsCoaled = cfgCoaled.GetTotNumLins();
    int numLinsOrig = cfgOrig.GetTotNumLins();
    if( numLinsOrig < DEF_MIN_COAL_LIN_CONDITION )
    {
        return false;
    }
    
    int numExpCoal = CalcExpectedCoalLinNum( numLinsOrig, tLen );
    //return ( numExpCoal - numLinsCoaled > DEF_FRAC_OFFSET_COAL_LIN_NUM * numLinsOrig ) &&
    return ( numExpCoal - numLinsCoaled > GetRangeExpCoal() );
}

void ApproxGeneTreeProbHelper :: ConsDescCfgsToParCfgList(int nodeDesc, const set< ApproxGeneTreeProbAncConfig > &cfgDescList, set< ApproxGeneTreeProbAncConfig > &cfgParList) const
{
    // convert the list of cfgs of descendent to parent
    int nodePar = this->treeSpecies.GetParent( nodeDesc );
    for( set<ApproxGeneTreeProbAncConfig> :: const_iterator it = cfgDescList.begin(); it != cfgDescList.end(); ++it )
    {
        ApproxGeneTreeProbAncConfig cfgConv(*it);
        ConvDescACToParAC(nodePar, *it, cfgConv);
        if( cfgParList.find(cfgConv) == cfgParList.end() )
        {
            cfgParList.insert(cfgConv);
        }
        else
        {
            ApproxGeneTreeProbAncConfig &lcTot =  const_cast< ApproxGeneTreeProbAncConfig & >( *cfgParList.find(cfgConv) );
#ifndef LOG_CFG_PROB
            lcTot.SetProb( lcTot.GetProb()+it->GetProb());
#else
            lcTot.SetLogProb( GetLogSumOfTwo( lcTot.GetLogProb(), it->GetLogProb() ) );
#endif
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////


ApproxLinCfgSoreIterator :: ApproxLinCfgSoreIterator( int id, ApproxLineageConfigSore &ls ) : nodeId(id), lcStore(ls)
{
	// initialize it
	Init();
}

void ApproxLinCfgSoreIterator :: Init()
{
	YW_ASSERT_INFO( lcStore.statesDepot.find( nodeId) != lcStore.statesDepot.end(), "Fail to find it"  );
	it = lcStore.statesDepot[nodeId].begin();
}

bool ApproxLinCfgSoreIterator :: IsDone()
{
	return it == lcStore.statesDepot[nodeId].end();
}

void ApproxLinCfgSoreIterator :: Next()
{
	it ++;
}



////////////////////////////////////////////////////////////////////////////////////////////////

int ApproxLineageConfigSore :: maxLinCfgNum = HAP_MAX_INT;

ApproxLineageConfigSore :: ApproxLineageConfigSore(MarginalTree &ts, PhylogenyTreeBasic &tg, ApproxGeneTreeProbHelper &gst) : treeSpecies(ts), treeGene(tg), gstHelper(gst)
{
}

ApproxLineageConfigSore :: ApproxLineageConfigSore(const ApproxLineageConfigSore &rhs) : treeSpecies(rhs.treeSpecies), treeGene(rhs.treeGene), gstHelper(rhs.gstHelper), statesDepot(rhs.statesDepot)
{
    //
}

void ApproxLineageConfigSore :: SetMaxLinCfgNum(int num)
{
    maxLinCfgNum = num;
}

// add a record of LinCfg: for the purpose of computing the probablity, need to know which
// LinCfg it derives from. For leaves, we also support a plain version: with no probility
void ApproxLineageConfigSore :: AddLinCfg( int nodeId, const ApproxGeneTreeProbAncConfig &lcNew )
{
    //#if 0
	// for leaves, set prob to be 1.0
	//lcNew.SetProb(1.0);
    //cout << "AddLinCfg: node id = " << nodeId <<", cfg to add: ";
    //lcNew.Dump();
    
	// in this case, this must be the only state
	//YW_ASSERT_INFO( statesDepot.find( nodeId ) == statesDepot.end(), "Fail: leaf must only have one LinCfg" );
	if(  statesDepot.find( nodeId ) == statesDepot.end()  )
	{
		set<ApproxGeneTreeProbAncConfig> setLins;
		setLins.insert(lcNew);
		statesDepot.insert( map<int, set< ApproxGeneTreeProbAncConfig > > :: value_type(nodeId, setLins)  );
	}
	else
	{
        // YW: 08/10/15. CHANGE: if the cfg is already in the store, append it
        set< ApproxGeneTreeProbAncConfig > :: iterator it = statesDepot[nodeId].find(lcNew);
        if( it != statesDepot[nodeId].end() )
        {
            ApproxGeneTreeProbAncConfig &lcTot =  const_cast< ApproxGeneTreeProbAncConfig & >( *it );
#ifndef LOG_CFG_PROB
            lcTot.SetProb( lcTot.GetProb()+lcNew.GetProb());
#else
            lcTot.SetLogProb( GetLogSumOfTwo( lcTot.GetLogProb(), lcNew.GetLogProb() ) );
#endif
            //statesDepot[nodeId].erase( lcNew );
            //statesDepot[nodeId].insert( lcTot );
        }
        else
        {
            // Otherwise, just add it
            // can not be the same, already there
            //YW_ASSERT_INFO( statesDepot[nodeId].find( lcNew ) == statesDepot[nodeId].end(), "Can not insert duplicate lcNew"  );
            statesDepot[nodeId].insert( lcNew );
        }
        
		// now prune it
		Prune(nodeId);
	}
    //#endif
    
}

void ApproxLineageConfigSore :: Prune(int nodeId)
{
    TrimSetCfgs( statesDepot[nodeId] );
#if 0
	// in case there are too many cfgs, prune it
	if( (int)statesDepot[nodeId].size() >  maxLinCfgNum )
	{
		// prune half of it
		set< ApproxGeneTreeProbAncConfig > setCfgsKept;
        
		// find the median of prob
		map<double, set<const ApproxGeneTreeProbAncConfig *> > mapProbsCur;
		set< ApproxGeneTreeProbAncConfig > &listLinCfgsMap = statesDepot[nodeId];
		for(  set< ApproxGeneTreeProbAncConfig > :: iterator itt = listLinCfgsMap.begin(); itt != listLinCfgsMap.end(); ++itt )
		{
            if( mapProbsCur.find( itt->GetProb() ) == mapProbsCur.end() )
            {
                set<const ApproxGeneTreeProbAncConfig *> ss;
                mapProbsCur.insert( map<double, set<const ApproxGeneTreeProbAncConfig *> > :: value_type( itt->GetProb(), ss ) );
            }
            
			mapProbsCur[itt->GetProb()].insert( &(*itt) );
		}
		// scan it again
		for(  map<double, set<const ApproxGeneTreeProbAncConfig *> >  :: reverse_iterator itt = mapProbsCur.rbegin(); itt != mapProbsCur.rend(); ++itt )
		{
            for( set<const ApproxGeneTreeProbAncConfig *> :: iterator it2 = itt->second.begin(); it2 != itt->second.end(); ++it2 )
            {
                if( (int)setCfgsKept.size() < maxLinCfgNum   )
                {
                    setCfgsKept.insert( *(*it2) );
                }
                else
                {
                    break;
                }
            }
		}
        
		// update list
		statesDepot[nodeId] = setCfgsKept;
	}
#endif
}

void ApproxLineageConfigSore :: TrimSetCfgs(set<ApproxGeneTreeProbAncConfig> &setCfgsToTrim)
{
	// in case there are too many cfgs, prune it
	if( (int)setCfgsToTrim.size() >  maxLinCfgNum )
	{
		// prune half of it
		set< ApproxGeneTreeProbAncConfig > setCfgsKept;
        
		// find the median of prob
		map<double, set<const ApproxGeneTreeProbAncConfig *> > mapProbsCur;
		set< ApproxGeneTreeProbAncConfig > &listLinCfgsMap = setCfgsToTrim;
		for(  set< ApproxGeneTreeProbAncConfig > :: iterator itt = listLinCfgsMap.begin(); itt != listLinCfgsMap.end(); ++itt )
		{
            if( mapProbsCur.find( itt->GetProb() ) == mapProbsCur.end() )
            {
                set<const ApproxGeneTreeProbAncConfig *> ss;
                mapProbsCur.insert( map<double, set<const ApproxGeneTreeProbAncConfig *> > :: value_type( itt->GetProb(), ss ) );
            }
            
			mapProbsCur[itt->GetProb()].insert( &(*itt) );
		}
		// scan it again
		for(  map<double, set<const ApproxGeneTreeProbAncConfig *> >  :: reverse_iterator itt = mapProbsCur.rbegin(); itt != mapProbsCur.rend(); ++itt )
		{
            for( set<const ApproxGeneTreeProbAncConfig *> :: iterator it2 = itt->second.begin(); it2 != itt->second.end(); ++it2 )
            {
                if( (int)setCfgsKept.size() < maxLinCfgNum   )
                {
                    setCfgsKept.insert( *(*it2) );
                }
                else
                {
                    break;
                }
            }
		}
        
		// update list
		setCfgsToTrim = setCfgsKept;
	}
    
}



int ApproxLineageConfigSore :: GetNumLinCfgsAt(int nodeId)
{
	//
	if( statesDepot.find( nodeId ) == statesDepot.end() )
	{
		return 0;
	}
	else
	{
		return statesDepot[nodeId].size();
	}
}

void ApproxLineageConfigSore :: DumpConfigsAt(int nodeId)
{
	if( statesDepot.find( nodeId ) == statesDepot.end() )
	{
		return;
	}
	cout << "Configs at node " << nodeId << endl;
	for( set< ApproxGeneTreeProbAncConfig > :: iterator it = statesDepot[nodeId].begin(); it != statesDepot[nodeId].end(); ++it )
	{
		it->Dump();
	}
    if( this->treeSpecies.IsLeaf(nodeId) == false )
    {
        int nl = this->treeSpecies.GetLeftDescendant(nodeId);
        int nr = this->treeSpecies.GetRightDescendant(nodeId);
        cout << "Configs at left descendent " << nl << " (upper)" << endl;
        for( set< ApproxGeneTreeProbAncConfig > :: iterator it = statesDepotUpper[nl].begin(); it != statesDepotUpper[nl].end(); ++it )
        {
            it->Dump();
        }
        cout << "Configs at right descendent " << nr << " (upper)" << endl;
        for( set< ApproxGeneTreeProbAncConfig > :: iterator it = statesDepotUpper[nr].begin(); it != statesDepotUpper[nr].end(); ++it )
        {
            it->Dump();
        }
    }
}

#if 0
void ApproxLineageConfigSore :: SetLinCfgProbAt(int nodeId, ApproxGeneTreeProbAncConfig &lcNew, double probNew)
{
	YW_ASSERT_INFO(statesDepot.find( nodeId ) != statesDepot.end(), "Can not find nodeId" );
	//YW_ASSERT_INFO(statesDepot[nodeId].find( lcNew ) != statesDepot[nodeId].end(), "Can not find lcNew at nodeId" );
	// YW: changed at 080510, to support pruning
	if( statesDepot[nodeId].find( lcNew ) != statesDepot[nodeId].end() )
	{
		set< ApproxGeneTreeProbAncConfig >:: iterator it = statesDepot[nodeId].find(lcNew);
		const_cast< ApproxGeneTreeProbAncConfig * >(&(*it))->SetProb( probNew );
	}
}
#endif

double ApproxLineageConfigSore :: CalcTotProbAt(int nodeId)
{
//cout << "CalcTotProbAt: at node " << nodeId << endl;
	// this should be the root
	// here each config is going to coalesce into the final (infinite) branch out of species tree root
	YW_ASSERT_INFO( statesDepot.find( nodeId ) != statesDepot.end(), "Bad root node2"  );
	double res;
#ifndef LOG_CFG_PROB
    res = 0.0;
#else
    res = MAX_NEG_DOUBLE_VAL;
#endif
	for( set< ApproxGeneTreeProbAncConfig > :: iterator it = statesDepot[nodeId].begin(); it != statesDepot[nodeId].end(); ++it  )
	{
		// If this config has more than one branch, then need to compute one additional coefficient
		if( it->GetTotNumLins() == 1 )
		{
#ifndef LOG_CFG_PROB
			res += it->GetProb();
#else
            res = GetLogSumOfTwo( res, it->GetLogProb() );
#endif
		}
		else
		{
			// need to compute the final combinatorial factor
			ApproxGeneTreeProbAncConfig finalLC( treeSpecies.GetRoot() );
            finalLC.AddLinCluster(1);
            
            //
            double coeff = gstHelper.CalcCoalCoeffForTwoCfg( *it, finalLC );
            
            if( coeff < 0.0  )
			{
				//cout << "coeff = " << coeff << endl;
				//YW_ASSERT_INFO(false, "Coefficient wrong");
                ffastSTELLSProbComputeWarningFlag = true;
                coeff = 0.0;    // set prob to be 0.0 for now
			}
            
#ifndef LOG_CFG_PROB
            res += it->GetProb()*coeff;
#else
            double logcoeff = MAX_NEG_DOUBLE_VAL;
            if( coeff > 0.0 )
            {
                logcoeff = log(coeff);
            }
            res = GetLogSumOfTwo( res,  it->GetLogProb()+logcoeff );
#endif
            
//cout << "^^^One cfg prob: " << it->GetProb() << ", coeff: " << coeff << endl;
            
#if 0
			if( it->GetProb() < 0.0 )
			{
				//cout << "prob of the AC is wrong: ";
				//it->Dump();
				//YW_ASSERT_INFO(false, "AC prob wrong");
                ffastSTELLSProbComputeWarningFlag = true;
                ApproxGeneTreeProbAncConfig *pcfgUse = const_cast<ApproxGeneTreeProbAncConfig *>(&(*it));
                pcfgUse->SetProb(0.0);
			}
#endif
		}
	}
	return res;
}

void ApproxLineageConfigSore :: ResetAtMulti(const set<int> &setNodes)
{
    //
    for( set<int> :: const_iterator it = setNodes.begin(); it != setNodes.end(); ++it)
    {
        ResetAt( *it );
    }
}

void ApproxLineageConfigSore :: EqualCfgsTo(const ApproxLineageConfigSore &rhs)
{
    // caution: only meant to be identical topology
    this->statesDepot = rhs.statesDepot;
}

void ApproxLineageConfigSore :: CopyFromAtSTNode( int stNode, ApproxLineageConfigSore &linCfgStorePrev, int stNodePrev  )
{
    YW_ASSERT_INFO( linCfgStorePrev.statesDepot.find(stNodePrev) != linCfgStorePrev.statesDepot.end(), "Fail to find" );
    this->statesDepot.erase(stNode);
    for( set< ApproxGeneTreeProbAncConfig > :: const_iterator it = linCfgStorePrev.statesDepot[stNodePrev].begin(); it != linCfgStorePrev.statesDepot[stNodePrev].end(); ++it )
    {
        //
        ApproxGeneTreeProbAncConfig cfg( *it );
        cfg.SetNodeId(stNode);
        AddLinCfg( stNode, cfg );
    }
}


//////////////////////////////////////////////////////////////////////////////////
// Approx species tree prob


ApproxGeneTreeProb :: ApproxGeneTreeProb( MarginalTree &treeSpeciesIn, PhylogenyTreeBasic &treeGeneIn ) : treeSpecies(treeSpeciesIn), treeGene(treeGeneIn)
{
    //
    //treeSpecies.BuildDescendantInfo();
    
    // get the subtree that we will use
    set<int> species;
    GetLeavesSpeciesFromGT( treeGene, species );
    CreateSubtreeFromLeaves( treeSpecies, species, treeSpeciesUse, this->mapNewNodeToOldNode );
    
    InitBranchConversion();
    
    pgstHelper = new ApproxGeneTreeProbHelper(treeSpeciesUse, treeGene);
    // YW: a bug? 05/19/16 ==> treeSpeciesUse or treeSpecies
    pstoreLinCfgs = new ApproxLineageConfigSore(treeSpeciesUse, treeGene, *pgstHelper);
    //pstoreLinCfgs = new ApproxLineageConfigSore(treeSpecies, treeGene, *pgstHelper);
    //pstoreLinCfgsBackup = NULL;
    //fRestoreMode = false;
}

ApproxGeneTreeProb :: ~ApproxGeneTreeProb()
{
    //
    delete pgstHelper;
    delete pstoreLinCfgs;
    //if( pstoreLinCfgsBackup != NULL )
    //{
    //    delete pstoreLinCfgsBackup;
    //    pstoreLinCfgsBackup = NULL;
    //}
}

void ApproxGeneTreeProb :: InitBranchConversion()
{
    // assume mapNewNodeToOldNode has been initialized
    // now find out the mapping btw original ST to mapped ST
    InverseMap( this->mapNewNodeToOldNode, this->mapSTOldNodeToNewNode );
    // also find out all the edges in between (if there are such)
    for( int i=0; i<treeSpeciesUse.GetTotNodesNum(); ++i )
    {
        //
        if( treeSpeciesUse.GetRoot() == i )
        {
            continue;
        }
        YW_ASSERT_INFO( this->mapNewNodeToOldNode.find(i) != this->mapNewNodeToOldNode.end(), "Fail to find" );
        int iOld = this->mapNewNodeToOldNode[i];
        
        int ip = treeSpeciesUse.GetParent(i);
//cout << "i: " << i << ", parent: " << ip << endl;
        YW_ASSERT_INFO( this->mapNewNodeToOldNode.find(ip) != this->mapNewNodeToOldNode.end(), "Fail111" );
        int ipOld = this->mapNewNodeToOldNode[ip];
        set<int> ssint;
        treeSpecies.GetPath(iOld, ipOld, ssint);
        ssint.erase( ipOld );
        ssint.insert(iOld);
//cout << "ssint: ";
//DumpIntSet(ssint);
        for( set<int> :: iterator it = ssint.begin(); it != ssint.end(); ++it )
        {
            //
            this->mapSTOldNodeToNewNode.insert( map<int,int> :: value_type( *it, i ) );
        }
    }
#if 0
cout << "mapNewNodeToOldNode:";
for(map<int,int> :: iterator it = mapNewNodeToOldNode.begin(); it != mapNewNodeToOldNode.end(); ++it)
{
cout << it->first << "," << it->second << "  ";
}
cout << endl;
cout << "mapSTOldNodeToNewNode:";
for(map<int,int> :: iterator it = mapSTOldNodeToNewNode.begin(); it != mapSTOldNodeToNewNode.end(); ++it)
{
cout << it->first << "," << it->second << "  ";
}
cout << endl;
#endif
}

double ApproxGeneTreeProb :: CalcProb()
{
    //return CalcProbArray();
//#if 0
    if( IsRecomputeMode() == true )
    {
        double res = RecalculateProb();
//cout << "*** RecalculateProb: prob = " << res << endl;
        return res;
    }
//#endif
    
//#if 0
    // prepare the comuptation by re-initialize
    //this->ReInit();
    
//cout << "---- In ApproxGeneTreeProb :: CalcProb()\n";
    // collect ACs at leaves of ST first
    // for each internal node of ST, collect ACs
    // Calculate the AC
	for(int iv = 0; iv < treeSpeciesUse.GetTotNodesNum(); ++iv)
	{
        if(fVerboseMode == true)
        {
            cout << "iv = " << iv << endl;
        }
        
        // skip if it has been precomputed
        //pstoreLinCfgs->ResetAt(iv);
//#if 0
        if( pstoreLinCfgs->IsComputedBefore( iv ) == true )
        {
            continue;
        }
//#endif
        
		// is it a leaf? If so, collect all the corresponding lineages for this species
		if( treeSpeciesUse.IsLeaf( iv ) == true )
		{
            //cout << "Is leaf\n";
			// get label for it
			int lbl = treeSpeciesUse.GetLabel(iv );
			set<int> geneAlleles;
			pgstHelper->GetGeneAllelesForSpecies(lbl, geneAlleles);
            //cout << "geneAlleles: ";
            //DumpIntSet( geneAlleles );
			ApproxGeneTreeProbAncConfig linConfig(iv);
            vector<int> vecLeafLinsCount;
            pgstHelper->GetLeafLinCountsAtSTNode( iv, vecLeafLinsCount );
			pgstHelper->FormLinConfig( iv, vecLeafLinsCount, linConfig );
#ifndef LOG_CFG_PROB
			linConfig.SetProb(1.0);		// leaves are prob 1.0
#else
            linConfig.SetLogProb(0.0);
#endif
            
			// add a record for it
			pstoreLinCfgs->AddLinCfg(iv, linConfig);
//linConfig.Dump();
		}
		else
		{
            //cout << "Non-leaf\n";
			//int numProc = 0;
            
			// otherwise, we examine its two descendents to see what kinds of states they have
			// we can delete them afterwards (TBD)
			// first find the two descendents of iv
			int nodeLeft = treeSpeciesUse.GetLeftDescendant(iv);
			int nodeRight = treeSpeciesUse.GetRightDescendant(iv);
            if( fVerboseMode == true )
            {
                cout << "LeftNode = " << nodeLeft << ", rightNode=" << nodeRight << endl;
                cout << "The number of config at left = " << pstoreLinCfgs->GetNumLinCfgsAt(nodeLeft) << endl;
                cout << "The number of config at right = " << pstoreLinCfgs->GetNumLinCfgsAt(nodeRight) << endl;
            }
            
			// collect ancestral cfgs on left/right
            if( pstoreLinCfgs->IsUpperComputedBefore(nodeLeft) == false )
            {
                set<ApproxGeneTreeProbAncConfig> configsNewLeft;
                pstoreLinCfgs->SetLCSetUpperAt( nodeLeft, configsNewLeft );
            
                set< ApproxGeneTreeProbAncConfig > &cfgListOldLeft = pstoreLinCfgs->GetLCSetAt(nodeLeft);
                //pgstHelper->FastCollectAncConfig( nodeLeft, cfgListOldLeft, configsNewLeft  );
                
                set<ApproxGeneTreeProbAncConfig> configsLeftUpper;
                pgstHelper->FastCollectAncConfigHeu( nodeLeft, cfgListOldLeft, configsLeftUpper );
                pgstHelper->ConsDescCfgsToParCfgList(nodeLeft, configsLeftUpper, pstoreLinCfgs->GetLCSetUpperAt(nodeLeft)  );
                
                //pgstHelper->FastCollectAncConfigHeu( nodeLeft, cfgListOldLeft, pstoreLinCfgs->GetLCSetUpperAt(nodeLeft)  );
                ApproxLineageConfigSore :: TrimSetCfgs( pstoreLinCfgs->GetLCSetUpperAt(nodeLeft) );
                //cout << "configsNewLeft.size = " << configsNewLeft.size() << endl;
            }
//cout << "now process right child...\n";
            if( pstoreLinCfgs->IsUpperComputedBefore(nodeRight) == false )
            {
                set<ApproxGeneTreeProbAncConfig> configsNewRight;
                pstoreLinCfgs->SetLCSetUpperAt( nodeRight, configsNewRight );
                
                set< ApproxGeneTreeProbAncConfig > &cfgListOldRight = pstoreLinCfgs->GetLCSetAt(nodeRight);
                //pgstHelper->FastCollectAncConfig( nodeRight, cfgListOldRight, configsNewRight  );
                set<ApproxGeneTreeProbAncConfig> configsRightUpper;
                pgstHelper->FastCollectAncConfigHeu( nodeRight, cfgListOldRight, configsRightUpper );
                pgstHelper->ConsDescCfgsToParCfgList(nodeRight, configsRightUpper, pstoreLinCfgs->GetLCSetUpperAt(nodeRight)  );
                
                //pgstHelper->FastCollectAncConfigHeu( nodeRight, cfgListOldRight, pstoreLinCfgs->GetLCSetUpperAt(nodeRight)  );
                ApproxLineageConfigSore :: TrimSetCfgs( pstoreLinCfgs->GetLCSetUpperAt( nodeRight ) );
            }
//#if 0
//cout << "now perform merging....\n";
            // try the new way of merging
            set<ApproxGeneTreeProbAncConfig> configsMergedAll;
            pstoreLinCfgs->SetLCSetAt( iv, configsMergedAll );
            pgstHelper->ConsLinearArrayOfTwoDescCfgsToParCfgsAt( iv, pstoreLinCfgs->GetLCSetUpperAt(nodeLeft), pstoreLinCfgs->GetLCSetUpperAt(nodeRight), pstoreLinCfgs->GetLCSetAt(iv) );
            //pgstHelper->ConsLinearArrayOfTwoDescCfgsToParCfgsAt( iv, configsNewLeft, configsNewRight, pstoreLinCfgs->GetLCSetAt(iv) );
            //pgstHelper->ConsLinearArrayOfTwoDescCfgsToParCfgsAt( iv, configsNewLeft, configsNewRight, configsMergedAll );
            //for( set<ApproxGeneTreeProbAncConfig> :: iterator itg = configsMergedAll.begin(); itg != configsMergedAll.end(); ++itg )
            //{
            //    pstoreLinCfgs->AddLinCfg(iv, *itg );
            //}
//#endif
//cout << "Done with merging for this node only\n";
            
            // for benchmarking
            ApproxGTPStats::Instance().RecordMaxACSize( configsMergedAll.size() );
            
#if 0
//cout << "Num of configurations left/right = " << configsNewLeft.size() << ", " << configsNewRight.size() << endl;
            //cout << "configsNewRight.size = " << configsNewRight.size() << endl;
			// now let us merge them pairwise to form new cfg
			// append and insert into state depot
			for( set<ApproxGeneTreeProbAncConfig> :: iterator it1 = configsNewLeft.begin(); it1 != configsNewLeft.end(); ++it1 )
			{
                //cout << "Here\n";
                //cout << "Left ances: ";
                //configsNewLeft[ii]->Dump();
				for( set<ApproxGeneTreeProbAncConfig> :: iterator it2 = configsNewRight.begin(); it2 != configsNewRight.end(); ++it2 )
				{
                    //cout << "Right ances: ";
                    //configsNewRight[jj]->Dump();
					// form a new one
					ApproxGeneTreeProbAncConfig lcNew(iv);
					pgstHelper->FormLinConfig(iv,*it1,  *it2, lcNew);
					// setup prob
					lcNew.SetProb(  (*it1).GetProb()*(*it2).GetProb() );
					if( lcNew.GetProb() < 0.0)
					{
						cout << "The left config prob is: " << (*it1).GetProb() << ", and the right config prob is: " << (*it2).GetProb() << endl;
						YW_ASSERT_INFO(false, "AC: prob is negative");
					}
					//statesDepot[iv].insert( lcNew );
					pstoreLinCfgs->AddLinCfg(iv, lcNew );
                    
					//numProc++;
					//if( (numProc % 10000 ) == 0 )
					//{
					//	cout << "Processing " << numProc << "...\n";
					//}
                    //cout << "After FormLinConfig, find a new LC: ";
                    //lcNew.Dump();
				}
			}
#endif
//cout << "The total number of config at this node = " << pstoreLinCfgs->GetNumLinCfgsAt(iv) << endl;
//cout << "List of configurations: ";
//pstoreLinCfgs->DumpConfigsAt(iv);
		}
		if( fVerboseMode == true)
		{
			cout << "*************At species tree node " << iv << ", list of configurations: \n";
			pstoreLinCfgs->DumpConfigsAt(iv);
		}
	}
    

	int rootId = treeSpeciesUse.GetTotNodesNum()-1;
//cout << "At root: set of configurations: ";
//pstoreLinCfgs->DumpConfigsAt(rootId);
    
    
	double totProb = pstoreLinCfgs->CalcTotProbAt(rootId);
	//cout << "Total probability = " << setprecision(12)<< totProb << endl;
    
    //#if 0
	if( fVerboseMode == true)
	{
		int maxNumCfgs = 0;
		int totNumCfgs = 0;
		for(int nid=0; nid<=rootId; ++nid)
		{
            int n1 = pstoreLinCfgs->GetNumLinCfgsAt( nid );
            totNumCfgs+= n1;
            if(maxNumCfgs < n1 )
            {
                maxNumCfgs = n1;
            }
            //cout << "At node " << nid << ", number of configurations: ";
            //cout << storeLinCfgs.GetNumLinCfgsAt( nid ) << endl;
		}
		cout << "Maximum number of config at this computation: " << maxNumCfgs << endl;
		cout << "TOTAL number of config at this computation: " << totNumCfgs << endl;
	}
    //#endif
    static int numProbComputed = 0;
    if( ++numProbComputed % 1000 == 0 )
    {
        if( fVerboseModeExtern == true )
        {
            cout << "Number of probability computation: " << numProbComputed << endl;
        }
    }
    
//cout << "---Done with ApproxGeneTreeProb :: CalcProb(): totProb: " << totProb << endl;
	return totProb;
//#endif
}

double ApproxGeneTreeProb :: CalcLogProb()
{
#ifndef LOG_CFG_PROB
    return log( CalcProb() );
#else
    return CalcProb();
#endif
}

// attempt to change a branch to a new length, and update the prob. Since we may need to recover the original
// unchanged probs, we just save those changed one (i.e. keep a copy of what was there before)
double ApproxGeneTreeProb :: TestNewBranchLenAt( int threadId, int branch, double lenNew, map<int,set< LineageConfig,LTLinCfg > > &origLinCfgs, bool fSetBrLen )
{
    // first make a copy of current cfgs
    //if( pstoreLinCfgsBackup != NULL )
    //{
    //    delete pstoreLinCfgsBackup;
    //}
    //ApproxLineageConfigSore *pstoreLinCfgsSave = new ApproxLineageConfigSore( *pstoreLinCfgs );
    
    // simply set the ebranch length
//    double brOld = treeSpecies.GetEdgeLen( branch );
    pgstHelper->SetThreadId(threadId);
    
    //this->fRestoreMode = false;
    if( fSetBrLen == true )
    {
        SetSTBranchLen(branch, lenNew);
    }
    double res = CalcLogProb();
    
#if 0
    // set the old branch length back
    //this->fRestoreMode = true;
    if( fSetBrLen == true )
    {
        SetSTBranchLen( branch, brOld );
        
        // also set the prob directly
        //this->pstoreLinCfgs->EqualCfgsTo( *pstoreLinCfgsSave );
    }
#endif
    
    //delete pstoreLinCfgsSave;
    
    return res;
}

void ApproxGeneTreeProb :: SetLinCfgs(map<int,set< LineageConfig,LTLinCfg > > &linCfgsToSet)
{
//cout << "Restoring original configurations...\n";
    // useful when we want to un-do the effect of the previous tweaking of branch length
    // right now useless
    //ReInit();
    //CalcProb();
    //YW_ASSERT_INFO( pstoreLinCfgsBackup != NULL, "FATAL ERROR: cannot SetLinCfgs in ApproxGeneTreeprob" );
    //this->pstoreLinCfgs->EqualCfgsTo( *pstoreLinCfgsBackup );
}
void ApproxGeneTreeProb :: SetSTBranchLen(int br, double brLen)
{
#if 0
    // get the current edge
    double brCurr = treeSpeciesUse.GetEdgeLen(br);
    if( RoundDoubleValTo( brLen, numBranchLenDigit ) == RoundDoubleValTo( brCurr, numBranchLenDigit ) )
    {
        // do nothing
        return;
    }
    
    brLen = RoundDoubleValTo( brLen, numBranchLenDigit );
#endif
//cout << "Set branch " << br << " to length: " << brLen << endl;
    
    //
    treeSpecies.SetBranchLen(br, brLen);
    
    // update AC
    OnBrLenUpdate( br );
    
    // now should set the branch length of the used species tree
    UpdateBranchLenInSubtree( treeSpecies, this->mapNewNodeToOldNode, treeSpeciesUse );
    
	pgstHelper->ClearBranchLenCache();
}
void ApproxGeneTreeProb :: GetGeneAllelesForSpecies( int taxon, set<int> &geneAlleles)
{
    pgstHelper->GetGeneAllelesForSpecies( taxon, geneAlleles); 
}

void ApproxGeneTreeProb :: ReInit()
{
    //
    pstoreLinCfgs->Reset();
}

void ApproxGeneTreeProb :: OnBrLenUpdate(int brST)
{
    //if( this->fRestoreMode == true )
    //{
    //    // donothing if we will restore prob
    //    return;
    //}
    
    // branch length of a ST is updated, so need to recompute (part) of the ACs
    int brSTUsed;
    YW_ASSERT_INFO(this->mapSTOldNodeToNewNode.find(brST) != this->mapSTOldNodeToNewNode.end(), "Not found");
    brSTUsed = this->mapSTOldNodeToNewNode[brST];
    
#if 0
    set<int> setPathToRoot;
    this->treeSpeciesUse.GetPath( brSTUsed, this->treeSpeciesUse.GetRoot(), setPathToRoot );
    setPathToRoot.insert( this->treeSpeciesUse.GetRoot() );
    // remove the current branch
    setPathToRoot.erase( brSTUsed );
    this->pstoreLinCfgs->ResetAtMulti( setPathToRoot );
    this->pstoreLinCfgs->ResetUpperAt( brSTUsed );      // once braanch is changed, need to reset ancestral cfgs
#endif
    // remember the change of branch length
    this->setBrLenChanged.insert(brSTUsed);
    
    // re-compute prob
    //CalcProb();
}

void ApproxGeneTreeProb :: JumpStartAtSTNodes( GenericGeneSpeciesTreeProb *pProbPrev, const set<int> &setSTNodesToInit, map<int,int> &mapSTToPrevST )
{
    //
    YW_ASSERT_INFO( pProbPrev != NULL, "Cannot jumpstart with null" );
    ApproxGeneTreeProb *pProbPrevConv = dynamic_cast< ApproxGeneTreeProb * >(pProbPrev);
    if( pProbPrevConv == NULL )
    {
        YW_ASSERT_INFO(false, "wrong type");
    }
    
    //
    for( set<int> :: const_iterator it = setSTNodesToInit.begin(); it != setSTNodesToInit.end(); ++it)
    {
        //
        YW_ASSERT_INFO( mapSTToPrevST.find(*it) != mapSTToPrevST.end(), "Fail to find ST" );
        int stIndex =  mapSTToPrevST.find(*it)->second;
        this->pstoreLinCfgs->CopyFromAtSTNode( *it, *(pProbPrevConv->pstoreLinCfgs), stIndex );
    }
}

double ApproxGeneTreeProb :: RecalculateProb()
{
//cout << "RE-COMPUTING\n";
    // recalculate prob after some branch length has been changed
    AGTPACRecomputeContext context(pgstHelper, this->setBrLenChanged);
    
    // find out set of lower/upper cfgs to change
    set<int> setSTNodesToUpdateLower, setSTNodesToUpdateUpper;
    for( set<int> :: iterator it = this->setBrLenChanged.begin(); it != this->setBrLenChanged.end(); ++it)
    {
        set<int> setPathToRoot;
        this->treeSpeciesUse.GetPath( *it, this->treeSpeciesUse.GetRoot(), setPathToRoot );
        setPathToRoot.insert( this->treeSpeciesUse.GetRoot() );
        UnionSets( setSTNodesToUpdateUpper,  setPathToRoot);
        set<int> setPathToRootRmOne = setPathToRoot;
        setPathToRootRmOne.erase( *it );
        UnionSets( setSTNodesToUpdateLower, setPathToRootRmOne );
    }
    //
    setSTNodesToUpdateUpper.erase( this->treeSpeciesUse.GetRoot() );
    
    
    // loop over all nodes to reevaluate the prob
    for(int iv = 0; iv < treeSpeciesUse.GetTotNodesNum(); ++iv)
	{
        if(fVerboseMode == true)
        {
            cout << "iv = " << iv << endl;
        }
        
        // skip if it has been precomputed
        //pstoreLinCfgs->ResetAt(iv);
        //#if 0
        if( setSTNodesToUpdateLower.find( iv ) != setSTNodesToUpdateLower.end() )
        {
            // so re-compute each cfg
            YW_ASSERT_INFO( pstoreLinCfgs->IsComputedBefore(iv) == true, "FATAL ERROR" );
            set<ApproxGeneTreeProbAncConfig> &setCfgsLower = pstoreLinCfgs->GetLCSetAt(iv);
            for( set<ApproxGeneTreeProbAncConfig> :: iterator it2 = setCfgsLower.begin(); it2 != setCfgsLower.end(); ++it2 )
            {
                ApproxGeneTreeProbAncConfig *pcfg = const_cast<ApproxGeneTreeProbAncConfig *>(&(*it2));
                YW_ASSERT_INFO( pcfg->GetHist() != NULL, "Cannot be NULL6" );
#ifndef LOG_CFG_PROB
                pcfg->SetProb( pcfg->GetHist()->Recompute( context, pcfg ) );
#else
                pcfg->SetLogProb(  pcfg->GetHist()->Recompute( context, pcfg ) );
#endif
            }
        }
        if( setSTNodesToUpdateUpper.find( iv ) != setSTNodesToUpdateUpper.end() )
        {
            // so re-compute each cfg
            YW_ASSERT_INFO( pstoreLinCfgs->IsComputedBefore(iv) == true, "FATAL ERROR" );
            set<ApproxGeneTreeProbAncConfig> &setCfgsUpper = pstoreLinCfgs->GetLCSetUpperAt(iv);
            for( set<ApproxGeneTreeProbAncConfig> :: iterator it2 = setCfgsUpper.begin(); it2 != setCfgsUpper.end(); ++it2 )
            {
                ApproxGeneTreeProbAncConfig *pcfg = const_cast<ApproxGeneTreeProbAncConfig *>(&(*it2));
                YW_ASSERT_INFO( pcfg->GetHist() != NULL, "Cannot be NULL7" );
#ifndef LOG_CFG_PROB
                pcfg->SetProb( pcfg->GetHist()->Recompute( context, pcfg )  );
#else
                pcfg->SetLogProb( pcfg->GetHist()->Recompute( context, pcfg )  );
#endif
            }
        }
	}
    
    
	int rootId = treeSpeciesUse.GetTotNodesNum()-1;
//cout << "At root: set of configurations: ";
//pstoreLinCfgs->DumpConfigsAt(rootId);
    
    
	double totProb = pstoreLinCfgs->CalcTotProbAt(rootId);
	//cout << "Total probability = " << setprecision(12)<< totProb << endl;
    
    //#endif
    static int numReProbComputed = 0;
    if( ++numReProbComputed % 1000 == 0 )
    {
        if( fVerboseModeExtern == true )
        {
            cout << "Number of probability re-computation: " << numReProbComputed << endl;
        }
    }
    
    
    // finally clear up the branch length changes
    this->setBrLenChanged.clear();
    
//cout << "---Done with ApproxGeneTreeProb :: RecalculateProb(): totProb: " << totProb << endl;
	return totProb;
}

bool ApproxGeneTreeProb :: IsRecomputeMode() const
{
    // only do recomputing if the cfgs have all been collected
    int numCfgRoot = this->pstoreLinCfgs->GetNumLinCfgsAt( this->treeSpeciesUse.GetRoot() );
//cout << "Number of cfgs at root: " << numCfgRoot << endl;
    return numCfgRoot > 0;
}



