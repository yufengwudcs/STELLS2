//
//  ProbSeqOnTrees.h
//  
//
//  Created by Yufeng Wu on 5/7/15.
//
//

#ifndef ____ProbSeqOnTrees__
#define ____ProbSeqOnTrees__

#include "NexusUtils.h"
#include "PhylogenyTreeBasic.h"
#include "Utils4.h"

//*****************************************************************************
// Global: list of alignment input

extern vector<MSAMatrix> listInputSeqAlignments;        // a list of sequence alignments

//*****************************************************************************
// Prob of sequences on gene tree

class ProbSeqOnTrees
{
public:
    ProbSeqOnTrees( PhylogenyTreeBasic &geneTreeIn, MSAMatrix &msaIn );
    double GetMutParam() const { return mutParam; }
    void SetMutParam(double p) { mutParam = p; }
    double CalcMutProbOfBranch( double brLen, TreeNode *nodeUnderBranch ) const;
    
private:
    void Init();
    void InitProcMSASite(int site);
    string GetUserLabel( TreeNode *pn ) const;
    
    PhylogenyTreeBasic &geneTree;
    MSAMatrix &msa;
    double mutParam;
    map<TreeNode *, int> mapTreeBranchStateChanges;     // for each branch in GT, the number of likely base changes along the branch
    map<TreeNode *, string> mapLeafLabelGT;             // leaf label on gene tree
};



#endif /* defined(____ProbSeqOnTrees__) */
