//
//  FastSpeciesTreeBuilder.cpp
//  
//
//  Created by Yufeng Wu on 3/27/16.
//
//

#include "FastSpeciesTreeBuilder.h"
#include <queue>
#include <ctime>
#include <cstdlib>
#include "Utils4.h"

const int DEF_MIN_SZ_SUBTREE = 3;
const int DEF_MAX_SZ_SUBTREE = 5;
//const int DEF_MAX_SZ_SUBTREE = 6;
const int DEF_MAX_SZ_IDENTSUBTREE = 1;
const int DEF_MAX_SZ_SUBGENTREE = 6;
//const int DEF_MAX_SZ_SUBGENTREE = 6;
const int DEF_MAX_NUM_ITERATION = 5;
const int DEF_RAND_SEED = 122949829;
const int DEF_FSTIC_MAX_PARTS = 4;
const double DEF_FSTIC_SIBPAIRS_RATIO = 0.99;

//////////////////////////////////////////////////////////////////////////////////
// Sibling analysis

bool FSTISiblingPair :: IsSame( const FSTISiblingPair &rhs ) const
{
    // have the same taxa pair?
    return (GetTaxon1() == rhs.GetTaxon1() && GetTaxon2() == rhs.GetTaxon2() ) || ( (GetTaxon1() == rhs.GetTaxon2() && GetTaxon2() == rhs.GetTaxon1()  ) ) ;
}

bool FSTISiblingPair :: HasSameTaxa( int t1, int t2) const
{
    return (GetTaxon1() == t1 && GetTaxon2() == t2 ) || ( (GetTaxon1() == t2 && GetTaxon2() == t1  ) );
}

bool FSTISiblingPair :: FindBestSibAlsoIn2ndList( const set<pair<int,int> > &listSibPairs1, const vector<FSTISiblingPair> &listSibPairs2, pair<int,int> &pairToChoose )
{
    // find the first sib that is also in the second sib
    bool fres = false;
    for(int j=0; j<(int)listSibPairs2.size(); ++j)
    {
        for(set<pair<int,int> > :: const_iterator it = listSibPairs1.begin(); it != listSibPairs1.end(); ++it)
        {
            //
            if ( listSibPairs2[j].HasSameTaxa( it->first, it->second ) == true )
            {
                fres = true;
                pairToChoose = *it;
                break;
            }
        }
        if( fres == true )
        {
            break;
        }
    }
    return fres;
}

//////////////////////////////////////////////////////////////////////////////////
// Sibling analysis


FSTISiblingAnalyzer :: FSTISiblingAnalyzer() : minTrustSibRatio(DEF_FSTIC_SIBPAIRS_RATIO)
{
    //
}

void FSTISiblingAnalyzer :: AnalyzeTree( MarginalTree &mtreeSub )
{
    // get all the taxa labels
    vector<int> listLbls;
    mtreeSub.GetLabelListForLeaf(listLbls);
    set<int> setListLbls;
    PopulateSetByVec( setListLbls, listLbls );
    
    // get all the siblings
    vector< pair<int,int> > listSibPairs;
    mtreeSub.FindSibLeafPairs( listSibPairs );
//cout << "Set of taxa: ";
//DumpIntSet( setListLbls );
//cout << "Found sib pairs: ";
//for(int i=0; i<(int)listSibPairs.size(); ++i)
//{
//cout << "[" << listSibPairs[i].first << "," << listSibPairs[i].second << "]  ";
//}
    // note: need to conver to labels
    set< pair<int,int> > setAllSibs;
    for( int i=0; i<(int)listSibPairs.size(); ++i )
    {
        //
        pair<int,int> pp;
        pp.first = mtreeSub.GetLabel( listSibPairs[i].first );
        pp.second = mtreeSub.GetLabel( listSibPairs[i].second );
        OrderInt( pp.first, pp.second );
        setAllSibs.insert(pp);
        
        // add one to this sibling
        if( mapSibPosNegCounts.find(pp) == mapSibPosNegCounts.end() )
        {
            pair<int,int> pp2(0,0);
            mapSibPosNegCounts.insert( map< pair<int,int>, pair<int,int> > :: value_type( pp, pp2 )  );
        }
        ++mapSibPosNegCounts[pp].first;
    }
    
    // now consider all pairs of taxa in this tree
    for( set<int> :: iterator it1 = setListLbls.begin(); it1 != setListLbls.end(); ++it1)
    {
        set<int> :: iterator it2 = it1;
        ++it2;
        for(; it2 != setListLbls.end(); ++it2)
        {
            pair<int,int> pp(*it1, *it2);
            if( setAllSibs.find(pp) == setAllSibs.end() )
            {
                // put to negative
                if( mapSibPosNegCounts.find(pp) == mapSibPosNegCounts.end() )
                {
                    pair<int,int> pp2(0,0);
                    mapSibPosNegCounts.insert( map< pair<int,int>, pair<int,int> > :: value_type( pp, pp2 )  );
                }
                ++mapSibPosNegCounts[pp].second;
            }
        }
    }
}

bool FSTISiblingAnalyzer :: FindTrustedSibPairs( set< pair<int,int> > &setSibPairs ) const
{
//cout << "In FindTrustedSibPairs: ";
//Dump();
    const int MAX_NUM_SIBPAIRS_USE = 5;
    
    // rank sib pairs from high to low and pick those not in conflict
    
    map< double, set< pair<int,int> > > mapRankedSibs;
    for( map< pair<int,int>, pair<int,int> > :: const_iterator it = mapSibPosNegCounts.begin(); it != mapSibPosNegCounts.end(); ++it )
    {
        //
        double score = it->second.first/( it->second.first+it->second.second );
        if( mapRankedSibs.find(score) == mapRankedSibs.end() )
        {
            //
            set< pair<int,int> > ss;
            mapRankedSibs.insert( map< double, set< pair<int,int> > > :: value_type( score, ss ) );
        }
        mapRankedSibs[score].insert( it->first );
    }
    
    // iterate from high to low
    set<int> setLinsMerged, setLinsMerged2;
    set< pair<int,int> > setSibPairsBackup;
    for( map< double, set< pair<int,int> > > :: reverse_iterator it = mapRankedSibs.rbegin(); it != mapRankedSibs.rend(); ++it )
    {
        if( it->first >= this->minTrustSibRatio )
        {
            for( set< pair<int,int> > :: iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2 )
            {
                // skip if any lineages has been merged already
                if( setLinsMerged.find( it2->first ) != setLinsMerged.end() ||  setLinsMerged.find( it2->second ) != setLinsMerged.end() )
                {
                    //
                    continue;
                }
                
                setSibPairs.insert( *it2 );
                setLinsMerged.insert( it2->first );
                setLinsMerged.insert( it2->second );
            }
        }
        else
        {
            bool fFull = false;
            for( set< pair<int,int> > :: iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2 )
            {
                // skip if any lineages has been merged already
                if( setLinsMerged2.find( it2->first ) != setLinsMerged2.end() ||  setLinsMerged2.find( it2->second ) != setLinsMerged2.end() )
                {
                    //
                    continue;
                }
                
                if( (int)setSibPairsBackup.size() >  MAX_NUM_SIBPAIRS_USE )
                {
                    fFull = true;
                    break;
                }
                
                setSibPairsBackup.insert( *it2 );
                setLinsMerged2.insert( it2->first );
                setLinsMerged2.insert( it2->second );
            }
            
            if( fFull == true )
            {
                break;
            }
        }
    }
    
    // if no trusted sib is found, get the one with largest support and warn
    bool fres = true;
    if( setSibPairs.size() == 0 )
    {
//cout << "WARNING: trusted sibling pair is not found. We go with the sibling pair with the largest support." << endl;
        // in this case, return the top k siblings
        
        setSibPairs = setSibPairsBackup;
        
        //pair<int,int> pp = *(mapRankedSibs.rbegin()->second.begin() );
        //setSibPairs.insert(pp);
        fres = false;
    }
    return fres;
}

void FSTISiblingAnalyzer :: Dump() const
{
    for( map< pair<int,int>, pair<int,int> > :: const_iterator it = mapSibPosNegCounts.begin(); it != mapSibPosNegCounts.end(); ++it )
    {
        //
        cout << "[" << it->first.first << "," << it->first.second << "]: " << it->second.first << "," << it->second.second << endl;
    }
}

//////////////////////////////////////////////////////////////////////////////////
// Found clusters structure (tree like)


FSTIClusterEvalCluster :: FSTIClusterEvalCluster(const set<int> &clusterIn) : cluster(clusterIn), score(0)
{
}

FSTIClusterEvalCluster :: ~FSTIClusterEvalCluster()
{
    // free children if there are
    for(int i=0; i<(int)listChildren.size(); ++i)
    {
        delete listChildren[i];
    }
    listChildren.clear();
}

void FSTIClusterEvalCluster :: AddChild( FSTIClusterEvalCluster *pChild )
{
    listChildren.push_back( pChild );
}

void FSTIClusterEvalCluster :: GetAllClustersBottomup( vector< set<int> > &listClusters )
{
    // first get all the children
    for(int i=0; i<(int)listChildren.size(); ++i)
    {
        listChildren[i]->GetAllClustersBottomup( listClusters );
    }
    listClusters.push_back( this->cluster );
}

void FSTIClusterEvalCluster :: Dump() const
{
    // best found: 
    cout << "[score:" << GetScore() << "]: number children:" << listChildren.size() << ", cluster:";
    DumpIntSet(this->cluster);
    cout << "List of children: ";
    for(int i=0;i<(int)listChildren.size(); ++i)
    {
        listChildren[i]->Dump();
    }
}

//////////////////////////////////////////////////////////////////////////////////
// Evaluate clusters of gene trees

void TestFSTIClusterEval( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP  )
{
    FSTIClusterEval feval;
    feval.EvaluateTrees( listGeneTreePtrs, listMP );
    feval.Dump();
    
    YW_ASSERT_INFO( listGeneTreePtrs.size() > 0, "Must have some trees" );
    
    vector<int> listLeafLabels;
    listGeneTreePtrs[0]->GetAllLeafIntLabeles(listLeafLabels);
    set<int> setTaxa;
    PopulateSetByVec( setTaxa, listLeafLabels );
    
    //
    FSTIClusterEvalCluster *pPartitions = feval.FindClusterPartitions( setTaxa );
//cout << "The cluster info found: ";
//pPartitions->Dump();
    YW_ASSERT_INFO(pPartitions != NULL, "Not found");
    vector<set<int> > listPartitions;
    pPartitions->GetAllClustersBottomup( listPartitions );
    
    cout << "Found partitions:";
    for(int i=0; i<(int)listPartitions.size(); ++i)
    {
        DumpIntSet(listPartitions[i]);
    }
}

void TestTriplesInf( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP, TaxaMapper &mapperTaxaIds )
{
    FSTISiblingAnalyzer sibAnalyzer;
    
    // note: assume each gene tree contains the same set of taxa
    // inf species trees for all triples
    vector<int> listLeafLabels;
    listGeneTreePtrs[0]->GetAllLeafIntLabeles(listLeafLabels);
    set<int> setTaxa;
    PopulateSetByVec( setTaxa, listLeafLabels );
    vector<int> listSetTaxa;
    PopulateVecBySet( listSetTaxa, setTaxa );
    vector<int> posvec;
    GetFirstCombo(3, (int)listSetTaxa.size(), posvec);
    while(true)
    {
        // inf these three things
        set<int> setTaxaUse;
        for(int i=0; i<(int)posvec.size(); ++i )
        {
            setTaxaUse.insert( listSetTaxa[ posvec[i] ] );
        }
        
        
        // setTaxa: what subset of taxa to infer
        vector<PhylogenyTreeBasic *> listSubgtrees;
        for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
        {
            PhylogenyTreeBasic *ptr = FastSpeciesTreeInference :: CreateSubGenetreeFor( setTaxaUse, listGeneTreePtrs[i] );
            listSubgtrees.push_back( ptr );
        }
        
        
        // convert genetrees to zero-based
        TaxaMapper mapperSubtree;
        ConvPhyloTreesToZeroBasedId( listSubgtrees, &mapperSubtree );
        
        vector<string> vecNWParsTrees;
        bool fDiffTaxaInGTrees = false;
        const int numMDCLevels = 5;
        const int fMoreClade = false;
        const int maxNumMDCMoreClades = 0;
        int numTreeSamples = 50;
        ConsInitTreesFromInputTrees(listSubgtrees, listMP, mapperSubtree, vecNWParsTrees, false, numMDCLevels, fMoreClade, maxNumMDCMoreClades, numTreeSamples, fDiffTaxaInGTrees);
        //cout << "Initial trees: \n";
        //for(int i=0; i<(int)vecNWParsTrees.size(); ++i)
        //{
        //cout << mapperSubtree.ConvIdStringWithOrigTaxa( vecNWParsTrees[i] ) << endl;
        //}
        
        // Reduce the size of subtrees
        //ReduceSubtrees( listSubgtrees );
        //cout << "After gene tree reduction, the size of gene trees: ";
        //for(int i=0; i<(int)listSubgtrees.size(); ++i)
        //{
        //cout << listSubgtrees[i]->GetNumLeaves() << ", ";
        //}
        //cout << endl;
        
        // here also ensure the gene trees are not too large
        //for(int i=0; i<(int)listSubgtrees.size(); ++i)
        //{
        //    RandTrimLeavesFromTree( listSubgtrees[i], maxGTreeSz );
        //}
        
        // infer the tree
        SpeciesTreeExplorer streeExplorer2( 3, listSubgtrees, listMP, mapperSubtree );
        streeExplorer2.SetOutputTreeHere( false );
        streeExplorer2.SetOutputMoreInfo( false );
        streeExplorer2.ExploreFrom(vecNWParsTrees);
        MarginalTree mtreeSub;
        streeExplorer2.GetBestInfSpeicesMargTreeConv( mtreeSub );
        string resTreeNW = streeExplorer2.GetBestInfSpeicesTreeConv();
        ReadinMarginalTreesNewickWLenString( resTreeNW, setTaxaUse.size(), mtreeSub );
        RemapMargTree( mtreeSub, mapperTaxaIds );
        //cout << "Sub-tree (with new taxa id): " << mtreeSub.GetNewick() << "  for taxa: ";
        //DumpIntSet(setTaxaUse);
        //cout << "Sub-tree (with original taxa id): " << mapperTaxaIds.ConvIdStringWithOrigTaxa( mtreeSub.GetNewick() ) << endl;
        cout << "Sub-tree (with original taxa id): " << mtreeSub.GetNewick() << endl;
        
        sibAnalyzer.AnalyzeTree( mtreeSub );
        
        // freeup
        for(int i=0; i<(int)listSubgtrees.size(); ++i)
        {
            delete listSubgtrees[i];
        }        
        
        
        //
        if( GetNextCombo(3, (int)listSetTaxa.size(), posvec) == false )
        {
            break;
        }
    }
    
    // now find the siblings as merge candidates
    set< pair<int,int> > setSibPairCandidates;
    sibAnalyzer.FindTrustedSibPairs( setSibPairCandidates );
    cout << "Found sibling pairs: ";
    for( set< pair<int,int> > :: iterator it = setSibPairCandidates.begin(); it != setSibPairCandidates.end(); ++it )
    {
        cout << "[" << it->first << "," << it->second << "]  ";
    }
    cout << endl;
}

void TestTriplesFromTrees( vector<string> &listTreeNWs, int numTaxa, TaxaMapper &mapperTaxaIds )
{
cout << "TestTriplesFromTrees: " << listTreeNWs.size() << endl;
    // analyze the list of trees (w/ br len) to find common siblings 
    // construct marginal trees from these
    FSTISiblingAnalyzer analyzerTrip;
    for(int i=0; i<(int)listTreeNWs.size(); ++i)
    {
        string trNW = listTreeNWs[i];
        string trNWConv = mapperTaxaIds.ConvIdStringWithOrigTaxa( trNW );
cout << "Triple: analyzinig: " << trNWConv << endl;
        MarginalTree mtreeCurr;
        ReadinMarginalTreesNewickWLenString( trNWConv, numTaxa, mtreeCurr );
        analyzerTrip.AnalyzeTree( mtreeCurr );
    }
    set<pair<int,int> > setSibPairs;
    analyzerTrip.FindTrustedSibPairs( setSibPairs );
    cout << "Found sibling pairs: ";
    for( set< pair<int,int> > :: iterator it = setSibPairs.begin(); it != setSibPairs.end(); ++it )
    {
        cout << "[" << it->first << "," << it->second << "]  ";
    }
    cout << endl;
}

//////////////////////////////////////////////////////////////////////////////////
// Evaluate clusters of gene trees


FSTIClusterEval :: FSTIClusterEval() : maxNumParts(DEF_FSTIC_MAX_PARTS)
{
    //
}

void FSTIClusterEval :: EvaluateTrees( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMP )
{
    //
    YW_ASSERT_INFO( listGeneTreePtrs.size() == listMP.size(), "Wrong");
    for(int i=0; i<(int) listGeneTreePtrs.size(); ++i )
    {
cout << "Processing tree ";
string treeNW;
listGeneTreePtrs[i]->ConsNewick( treeNW );
cout << treeNW << endl;
        CheckSingleTree( listGeneTreePtrs[i], listMP[i] );
//exit(1);
    }
    AnalyzeClusters();
    
    // also collect cluster composition info
    EvaluateClustersInfo();
}

void FSTIClusterEval :: CheckSingleTree( PhylogenyTreeBasic *pGTree, int wt )
{
    // pGTTree: one gene tree; wt: its weight (e.g. multiplicity)
    vector<set<int> > listClades;
    pGTree->GetAllCladesList(listClades);
    
    // remember how often these clusters occur
    for( int i=0; i<(int)listClades.size(); ++i )
    {
//cout << "Clade: ";
//DumpIntSet(listClades[i]);
        if( mapClusterOcc.find( listClades[i] ) == mapClusterOcc.end() )
        {
            mapClusterOcc.insert( map< set<int>, int> :: value_type( listClades[i], 0 ) );
        }
        mapClusterOcc[ listClades[i] ] += wt;
    }
}

void FSTIClusterEval :: AnalyzeClusters()
{
    // find out which leaf belongs to which cluster
    for( map< set<int>, int> :: iterator it = mapClusterOcc.begin(); it != mapClusterOcc.end(); ++it )
    {
        for( set<int> :: const_iterator it2 = it->first.begin(); it2 != it->first.end(); ++it2)
        {
            int lflbl = *it2;
            if( mapLeafInClusters.find(lflbl) == mapLeafInClusters.end()  )
            {
                set< const set<int> *> ss;
                mapLeafInClusters.insert( map< int, set<const set<int> *> > :: value_type(lflbl, ss) );
            }
            mapLeafInClusters[lflbl].insert( &( it->first ) );
        }
    }
    
cout << "So far: ";
this->Dump();
    //
    for( map< set<int>, int> :: iterator it = mapClusterOcc.begin(); it != mapClusterOcc.end(); ++it )
    {
        AnalyzeSingleCluster( it->first );
    }
}

void FSTIClusterEval :: AnalyzeSingleCluster( const set<int> &cluster )
{
    //
    YW_ASSERT_INFO( mapClusterOcc.find(cluster) != mapClusterOcc.end(), "Fail" );
    //int numOccThis = mapClusterOcc[ cluster ];
//#if 0
    // exam each leaf in cluster
    int sumMatch = 0;
    int sumMismatch = 0;        // how many clusters don't agree with these
    set< const set<int> *> setRelvantClusters;
    for( set<int> :: const_iterator it = cluster.begin(); it != cluster.end(); ++it )
    {
        int lfl = *it;
        YW_ASSERT_INFO( mapLeafInClusters.find(lfl) != mapLeafInClusters.end(), "Fail" );
        for( set< const set<int> *> :: iterator it3 = mapLeafInClusters[lfl].begin(); it3 != mapLeafInClusters[lfl].end(); ++it3 )
        {
            // incompatible if (1) has intersection and (2) the intersection is not all the
            set<int> sint;
            JoinSets( cluster, *(*it3), sint );
            if( sint.size() > 0 )
            {
                //
                YW_ASSERT_INFO( mapClusterOcc.find(*(*it3)) != mapClusterOcc.end(), "Fail to find" );
                int occ = mapClusterOcc[ *(*it3) ];
                if( sint.size() == (*it3)->size() )
                {
                    // this is a match
                    sumMatch += occ;
                }
                else if( sint.size() != cluster.size() )
                {
                    // the two clusters split and thus dont agree
                    sumMismatch += occ;
                }
            }
        }
    }
    // for now, the match score is what we will use
    int score = sumMatch;
//#endif
    
    //int score  = numOccThis;
    
    mapClusterSupport.insert( map< set<int>, int> :: value_type( cluster, score )) ;
    // also record the inverse
    if( mapClusterSupportInv.find(score) == mapClusterSupportInv.end() )
    {
        set<const set<int> *> ss;
        mapClusterSupportInv.insert( map< int, set< const set< int > * > > :: value_type(score, ss) );
    }
    mapClusterSupportInv[score].insert( &(mapClusterSupport.find(cluster)->first ) );
}

void FSTIClusterEval ::  EvaluateClustersInfo()
{
    // evalute each cluster
    // first sort the subset of size by sz
    map< int, set< const set< int > * > > mapSizeCluster;
    for( map< set<int>, int> :: iterator it = mapClusterOcc.begin(); it != mapClusterOcc.end(); ++it )
    {
        int sz = it->first.size();
        if( mapSizeCluster.find(sz) == mapSizeCluster.end() )
        {
            //
            set< const set< int > * > ss;
            mapSizeCluster.insert(  map< int, set< const set< int > * > >:: value_type(sz, ss) );
        }
        mapSizeCluster[sz].insert( &(it->first) );
    }
//cout << "here.\n";
    // create a table of cluster info; essentially a DP approach
    vector< FSTIClusterEvalCluster * > listTblEntries;
    // start from small subsets
    for(  map< int, set< const set< int > * > > :: iterator it = mapSizeCluster.begin(); it != mapSizeCluster.end(); ++it )
    {
        //
        for( set< const set< int > * > :: iterator it2 = it->second.begin(); it2 != it->second.end(); ++it2 )
        {
            //
            set<int> clusterCur = *( *it2 );
            
            FSTIClusterEvalCluster *pClusInfo = new FSTIClusterEvalCluster( clusterCur );
            
            // for single taxon, just uses its current score
            int score = 0;
            if( clusterCur.size() == 1 )
            {
                YW_ASSERT_INFO( mapClusterSupport.find( clusterCur ) != mapClusterSupport.end(), "Fail" );
                score = mapClusterSupport[ clusterCur ];
            }
            else
            {
                vector<FSTIClusterEvalCluster *> listClusChildren;
                score = EvaluateClustersInfoFromListFor( clusterCur, listTblEntries, listClusChildren );
                // add children to the current cluster
                for(int i=0; i<(int)listClusChildren.size(); ++i)
                {
                    pClusInfo->AddChild( listClusChildren[i] );
                }
            }
            pClusInfo->SetScore(score);
            
            listTblEntries.push_back( pClusInfo );
//cout << "Constructed one cluster info entry: ";
//pClusInfo->Dump();
        }
    }
    // store it
    for( int i=0; i<(int)listTblEntries.size(); ++i )
    {
        //
        mapClusterToClusInfo.insert(map< set<int>, FSTIClusterEvalCluster * > :: value_type( *(listTblEntries[i]->GetClusPtr()), listTblEntries[i] ));
    }
}

int FSTIClusterEval :: EvaluateClustersInfoFromListFor( const set<int> &cluster, vector<FSTIClusterEvalCluster *> &listClusInfoSoFar, vector<FSTIClusterEvalCluster *> &listClusChildren )
{
cout << "maxNumParts: " << maxNumParts << ", cluster: ";
DumpIntSet(cluster);

    // for the cluster, find subsets of the max total score (and cannot have too many subsets)
    int score = 0;
    bool fres = FindClusterSubPartitions( this->maxNumParts, cluster, listClusInfoSoFar, (int)listClusInfoSoFar.size()-1, listClusChildren, score );
    if( fres == 0 )
    {
        listClusChildren.clear();
        return 0;
    }
    else
    {
        //
        return score;
    }
}

// given a cluster, how can we partition to the most supported parts?
FSTIClusterEvalCluster * FSTIClusterEval :: FindClusterPartitions( const set<int> &cluster ) const
{
cout << "FindClusterPartitions: " << ", cluster: ";
DumpIntSet(cluster);

    
    //
    YW_ASSERT_INFO( mapClusterToClusInfo.find( cluster ) != mapClusterToClusInfo.end(), "Fail to find" );
    return mapClusterToClusInfo.find(cluster)->second;

}

bool FSTIClusterEval :: FindClusterSubPartitions( int maxNumPartsStep, const set<int> &cluster, vector< FSTIClusterEvalCluster *> &listClusInfoSoFar, int listPosStartHigh, vector< FSTIClusterEvalCluster *> &listPartitions, int &scoreRes ) const
{
//cout << "FindClusterSubPartitions: maxNumPartsStep: " << maxNumPartsStep << ", listPosStartHigh:" << listPosStartHigh << ", listPartitions size: " << listPartitions.size()  << ", cluster: ";
//DumpIntSet(cluster);
    // find sublist of partitions
    // need at least oene part
    scoreRes = 0;
    
    if( listPosStartHigh <0 )
    {
        return false;
    }
    
    if( maxNumPartsStep == 0 )
    {
        if( cluster.size() == 0 )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    // now we still have something to use
    // so find the next lower one that can give good partition
    int posNext = listPosStartHigh;
    int posBest = -1;
    vector<FSTIClusterEvalCluster * > listPartitionsSubBest;
    int scoreMax = 0;
    while(posNext >= 0 )
    {
        //
        const set<int> *pss = listClusInfoSoFar[posNext]->GetClusPtr();
        if( pss->size() <= cluster.size() && listClusInfoSoFar[posNext]->IsGood() == true && IsSetContainer( cluster, *pss ) == true )
        {
//cout << "Testing one cluster: ";
//listClusInfoSoFar[posNext]->Dump();
            
            // if found an exact match, then return it
            if( pss->size() == cluster.size() )
            {
                listPartitions.push_back( listClusInfoSoFar[posNext] );
                scoreRes = listClusInfoSoFar[posNext]->GetScore();
                return true;
            }
            
            // try to use split this
            set<int> ssComplement = cluster;
            SubtractSets( ssComplement, *pss );
            vector<FSTIClusterEvalCluster * > listPartitionsSub = listPartitions;
            int scoreRest = 0;
            bool fTrial = FindClusterSubPartitions( maxNumPartsStep-1,  ssComplement, listClusInfoSoFar, posNext-1, listPartitionsSub, scoreRest );
            if( fTrial == true )
            {
                //listPartitions = listPartitionsSub;
                //listPartitions.push_back( listClusInfoSoFar[posNext] );
                if(  scoreRest > scoreMax )
                {
                    scoreMax = scoreRest;
                    posBest = posNext;
                    listPartitionsSubBest = listPartitionsSub;
                }
//cout << "Found one good partition: score = " << scoreRes << ", size of partition: " << listPartitions.size() << endl;
                //return true;
            }
        }
        --posNext;
    }
    
    if( scoreMax > 0 )
    {
        YW_ASSERT_INFO( posBest >= 0, "Fail" );
        listPartitions = listPartitionsSubBest;
        listPartitions.push_back( listClusInfoSoFar[posBest] );
        scoreRes = scoreMax + listClusInfoSoFar[posBest]->GetScore();
        return true;
    }
    
    return false;
}


void FSTIClusterEval :: Dump() const
{
    //
    cout << "***Number of clusters:  " << mapClusterOcc.size() << endl;
    cout << "^^Cluster occurance: \n";
    for( map< set<int>, int> :: const_iterator it = mapClusterOcc.begin(); it != mapClusterOcc.end(); ++it )
    {
        cout << "[" << it->second << "]: ";
        DumpIntSet(it->first);
    }
    cout << "^^Cluster support: \n";
    for( map< set<int>, int> :: const_iterator it = mapClusterSupport.begin(); it != mapClusterSupport.end(); ++it)
    {
        cout << "[" << it->second << "]: ";
        DumpIntSet(it->first);
    }
    //map< int, set< const set< int > * > > mapClusterSupportInv;
    //map< int, set<const set<int> *> > mapLeafInClusters;
    cout << "Cluster info list:\n";
    for( map< set<int>, FSTIClusterEvalCluster * > :: const_iterator it = mapClusterToClusInfo.begin(); it != mapClusterToClusInfo.end(); ++it )
    {
        (it->second)->Dump();
    }
}

//////////////////////////////////////////////////////////////////////////////////
// how to collapse subtrees


STSiblingInfo :: STSiblingInfo( MarginalTree *pSTreeIn, int nodePos1In, int nodePos2In ) : pSTree(pSTreeIn), nodePos1(nodePos1In), nodePos2(nodePos2In)
{
    //
}

STSiblingInfo :: STSiblingInfo(const STSiblingInfo &rhs) : pSTree(rhs.pSTree), nodePos1(rhs.nodePos1), nodePos2(rhs.nodePos2)
{
    //
}

bool STSiblingInfo :: operator<(const STSiblingInfo &rhs)
{
    // the ordering ignores the source of merginal tree
    if( this->nodePos1 <rhs.nodePos1 )
    {
        //
        return true;
    }
    else if( this->nodePos1 == rhs.nodePos1)
    {
        return this->nodePos2 < rhs.nodePos2;
    }
    return false;
}

void STSiblingInfo :: GetSubtree( set<int> &stree )
{
    // return position of the trees (not labels)
    set<int> ss1, ss2;
    pSTree->GetLeavesUnder( nodePos1, ss1 );
    pSTree->GetLeavesUnder( nodePos2, ss2 );
    set<int> streePos = ss1;
    UnionSets(streePos, ss2);
    stree.clear();
    pSTree->GetlabelsFor( streePos, stree );
}

int STSiblingInfo :: GetParPos() const
{
    //
    YW_ASSERT_INFO( pSTree->GetParent(nodePos1) == pSTree->GetParent(nodePos2), "Fail2" );
    return pSTree->GetParent(nodePos1);
}

//////////////////////////////////////////////////////////////////////////////////
// What trees have been inferred before


FastSpeciesTreeInfHist :: FastSpeciesTreeInfHist(int numSpeciesIn) : numSpecies(numSpeciesIn), idMergedNext( numSpeciesIn+1 )
{
    //
    //InitRandom( DEF_RAND_SEED );
    
    //each leaf maps to itself initially
    for(int i=0; i<numSpeciesIn; ++i)
    {
        set<int> ss;
        ss.insert(i);
        mapSetofTaxaToId.insert( map< set<int>, int > :: value_type(ss, i) );
        mapIdToSetofTaxa.insert( map<int, set<int> > :: value_type(i, ss) );
    }
}

FastSpeciesTreeInfHist :: FastSpeciesTreeInfHist( const FastSpeciesTreeInfHist &rhs ) : mapSubsetInfTrees(rhs.mapSubsetInfTrees), mapPairTaxaSibFreq(rhs.mapPairTaxaSibFreq), mapPairTaxaSibLens(rhs.mapPairTaxaSibLens), mapMergedTaxa(rhs.mapMergedTaxa), mapMergedTaxaParent(rhs.mapMergedTaxaParent), setMergedPairs(rhs.setMergedPairs), mapSetofTaxaToId(rhs.mapSetofTaxaToId), mapIdToSetofTaxa(rhs.mapIdToSetofTaxa), mapSubTrTaxaSibFreq(rhs.mapSubTrTaxaSibFreq), numSpecies(rhs.numSpecies), idMergedNext(rhs.idMergedNext)
{
    //
}

void FastSpeciesTreeInfHist :: AddInfTree( const set<int> &setTaxa, MarginalTree &mtree )
{
    //
    mapSubsetInfTrees.insert( map< set<int>, MarginalTree> :: value_type( setTaxa, mtree ) );
    
    AnalyzeTree( setTaxa, mtree );
}

void FastSpeciesTreeInfHist :: ExpandContractedSubtrees( MarginalTree &margStree )
{
    // only look at leaves
    while(true)
    {
//cout << "ExpandContractedSubtrees: At present: the tree is: " << margStree.GetNewick() << endl;
//margStree.Dump();
        bool fUpdated = false;
        for(int i=0; i<margStree.GetNumLeaves(); ++i )
        {
            int lbl = margStree.GetLabel(i);
            if( mapMergedTaxa.find(lbl) != mapMergedTaxa.end() )
            {
                // update tree
                int lblChild1 = mapMergedTaxa[lbl].first;
                int lblChild2 = mapMergedTaxa[lbl].second;
                YW_ASSERT_INFO(mapMergedTaxaParent.find(lblChild1)!=mapMergedTaxaParent.end(), "Fail to find(2)");
                YW_ASSERT_INFO(mapMergedTaxaParent.find(lblChild2)!=mapMergedTaxaParent.end(), "Fail to find(3)");
                double len1 = mapMergedTaxaParent[lblChild1].second;
                double len2 = mapMergedTaxaParent[lblChild2].second;
                margStree.MakeLeafSubtreeOfTwo( i, lblChild1, lblChild2, len1, len2 );
                fUpdated = true;
                break;
            }
        }
        if( fUpdated == false )
        {
            break;
        }
            
    }
}

int FastSpeciesTreeInfHist :: MergePair( pair<int,int> &pairToMerge1, const pair<double,double> &pairToMergeDist )
{
    // ensure it is ordered
    pair<int,int> pairToMergeUse = pairToMerge1;
    OrderInt( pairToMergeUse.first, pairToMergeUse.second );
    
    pair<double,double> pairToMergeDistUse = pairToMergeDist;
    if( pairToMergeUse.first != pairToMerge1.first )
    {
        SwapPairGen( pairToMergeDistUse );
    }
//cout << "merge pair: " << pairToMergeUse.first << "," << pairToMergeUse.second << endl;
    setMergedPairs.insert( pairToMergeUse );
    //
    int idMergeUse = idMergedNext++;
    mapMergedTaxa.insert( map<int, pair<int,int> > :: value_type(idMergeUse, pairToMergeUse) );
    
    pair<double,double> pairToMergeLen;
    if( mapPairTaxaSibLens.find(pairToMergeUse)!=mapPairTaxaSibLens.end() )
    {
        YW_ASSERT_INFO( mapPairTaxaSibLens[pairToMergeUse].first > 0, "Cannot be zero");
        int numOcc = mapPairTaxaSibLens[pairToMergeUse].first;
        pairToMergeLen.first = mapPairTaxaSibLens[pairToMergeUse].second.first/numOcc;
        pairToMergeLen.second = mapPairTaxaSibLens[pairToMergeUse].second.second/numOcc;
    }
    else if( pairToMergeDistUse.first >=0.0 && pairToMergeDistUse.second >= 0.0 )
    {
        // use the given estimate
        pairToMergeLen = pairToMergeDistUse;
//cout << "$$$$$$Using panel provided dists: " << pairToMergeDistUse.first << "," << pairToMergeDistUse.second << endl;
    }
    else
    {
        // now check for subsets
        int t1 = pairToMergeUse.first;
        int t2 = pairToMergeUse.second;
        YW_ASSERT_INFO( mapIdToSetofTaxa.find(t1) != mapIdToSetofTaxa.end(), "Fail22"  );
        YW_ASSERT_INFO( mapIdToSetofTaxa.find(t2) != mapIdToSetofTaxa.end(), "Fail33" );
        set<int> ss1 = mapIdToSetofTaxa[t1];
        set<int> ss2 = mapIdToSetofTaxa[t2];
//cout << "t1: " << t1 << ", ss1: ";
//DumpIntSet(ss1);
//cout << "t2: " << t2 << ", ss2: ";
//DumpIntSet(ss2);
        YW_ASSERT_INFO( mapSubTrTaxaSibFreq.find(ss1) != mapSubTrTaxaSibFreq.end(), "Fail44" );
        YW_ASSERT_INFO( mapSubTrTaxaSibFreq.find(ss2) != mapSubTrTaxaSibFreq.end(), "Fail55");
        pairToMergeLen.first = mapSubTrTaxaSibFreq[ss1].second/mapSubTrTaxaSibFreq[ss1].first;
        pairToMergeLen.second = mapSubTrTaxaSibFreq[ss2].second/mapSubTrTaxaSibFreq[ss2].first;
    }
    
    pair<int,double> pp1( idMergeUse, pairToMergeLen.first );
    pair<int,double> pp2( idMergeUse, pairToMergeLen.second );
    mapMergedTaxaParent.insert( map<int, pair<int,double> > :: value_type( pairToMergeUse.first, pp1 ) );
    mapMergedTaxaParent.insert( map<int, pair<int,double> > :: value_type( pairToMergeUse.second, pp2 ) );
    
//cout << "^^merged a new lin: " << idMergeUse << " for " << pairToMergeUse.first << "," << pairToMergeUse.second << endl;
    return idMergeUse;
}

void  FastSpeciesTreeInfHist :: AccumSubtreeDistInfo(const set<int> &setIds, pair<int,double> &pairOccTotDist) const
{
    //
    if( mapSubTrTaxaSibFreq.find(setIds) != mapSubTrTaxaSibFreq.end() )
    {
        pair<int,double> pp = mapSubTrTaxaSibFreq.find(setIds)->second;
        pairOccTotDist.first += pp.first;
        pairOccTotDist.second += pp.second;
    }
}

void FastSpeciesTreeInfHist :: MergeSetofTaxa(const set<int> &setTaxa, const pair<double,double> &htsTwoSubchild)
{
    // merge a set of taxa
    YW_ASSERT_INFO(setTaxa.size() >=2, "must have at least two");
    // check each mapped subset
    set<int> setTaxaMergedAll;
    GetMergedLinsFrom( setTaxa, setTaxaMergedAll );
//cout << "MergeSetofTaxa:  setTaxa:";
//DumpIntSet(setTaxa);
//cout << "setTaxaMergedAll:";
//DumpIntSet(setTaxaMergedAll);
    
    bool fFound = false;
    for( map< set<int>, int > :: iterator it = mapSetofTaxaToId.begin(); it != mapSetofTaxaToId.end(); ++it )
    {
        // must be two leaves
        set<int> spart1 = it->first;
        if( setTaxaMergedAll.size() <= spart1.size() || IsSetContainer( setTaxaMergedAll, spart1 ) == false  )
        {
            continue;
        }
        set<int> spart2 = setTaxaMergedAll;
        SubtractSets(spart2, spart1);
        YW_ASSERT_INFO( spart2.size()>0 && spart1.size()+spart2.size() == setTaxaMergedAll.size(), "Fail9" );
        
        if( mapSetofTaxaToId.find( spart2 ) == mapSetofTaxaToId.end() )
        {
            // this set is not mapped yet
            continue;
        }
        
        int t1=it->second;
        int t2=mapSetofTaxaToId.find( spart2 )->second;
        
        //
        pair<int,int> pp(t1,t2);
        int idUsed = MergePair(pp, htsTwoSubchild);
        // record this mapping btw subset and id
        mapSetofTaxaToId.insert( map< set<int>, int > :: value_type(setTaxaMergedAll, idUsed) );
        mapIdToSetofTaxa.insert( map<int, set<int> > :: value_type(idUsed, setTaxaMergedAll) );
        fFound = true;
        break;
    }
    if( fFound == false )
    {
        cout << "MergeSetofTaxa: Taxa set: ";
        DumpIntSet(setTaxa);
        cout << "taxa set merged: ";
        DumpIntSet( setTaxaMergedAll );
    }
    YW_ASSERT_INFO(fFound == true, "Wrong in MergeSetofTaxa");
}

void FastSpeciesTreeInfHist :: GetMergedLinsFrom( const set<int> &setIds, set<int> &setMergedLins ) const
{
    //
    setMergedLins.clear();
    for(set<int> :: const_iterator it = setIds.begin(); it != setIds.end(); ++it)
    {
        YW_ASSERT_INFO( mapIdToSetofTaxa.find(*it)!=mapIdToSetofTaxa.end(), "Fail to find" );
        UnionSets( setMergedLins, mapIdToSetofTaxa.find(*it)->second );
    }
}

void FastSpeciesTreeInfHist :: GetMergedSubtrees( const set<int> &setIds, set< set<int> > &setSubtrees ) const
{
    // a set of taxa: break them into a set of merged subtrees
    // initially everything is un-mereged
    setSubtrees.clear();
    set<int> setIdsUse = setIds;
    while( setIdsUse.size() > 0 )
    {
        int tid = *( setIdsUse.begin() );
        // find out which maximal subtree contain this
        int szMaxCur = 0;
        set<int> stMax;
        for( map< set<int>, int > :: const_iterator it1 =  mapSetofTaxaToId.begin(); it1 != mapSetofTaxaToId.end(); ++it1 )
        {
            //
            if( it1->first.find( tid ) != it1->first.end() && szMaxCur < (int)it1->first.size() )
            {
                szMaxCur = (int)it1->first.size();
                stMax = it1->first;
            }
        }
        if( szMaxCur == 0 )
        {
            stMax.insert( tid );
        }
        
        // add this record
        setSubtrees.insert(stMax);
        
        // reduce the subtree
        SubtractSets( setIdsUse, stMax );
    }
}

int FastSpeciesTreeInfHist :: GetNumMergedPairsWithin(const set<int> &setTaxa) const
{
//cout << "GetNumMergedPairsWithin: settaxa:";
//DumpIntSet(setTaxa);
    //
    int res = 0;
    
    // check all merged pairs to see if their taxa sets are contained in these taxa
    for( set< pair<int,int> > :: const_iterator it = setMergedPairs.begin(); it != setMergedPairs.end(); ++it )
    {
        int t1 = it->first;
        int t2 = it->second;
        YW_ASSERT_INFO( mapIdToSetofTaxa.find(t1)!=mapIdToSetofTaxa.end(), "Fail77" );
        YW_ASSERT_INFO( mapIdToSetofTaxa.find(t2)!=mapIdToSetofTaxa.end(), "Fail88" );
        if( IsSetContainer( setTaxa, mapIdToSetofTaxa.find(t1)->second ) == true && IsSetContainer(setTaxa, mapIdToSetofTaxa.find(t2)->second) == true )
        {
//cout << "These two lineages: " << t1 << "," << t2 << endl;
            ++res;
        }
    }
    
    //for( set<int> :: iterator it1 = setTaxa.begin(); it1 != setTaxa.end(); ++it1)
    //{
    //    set<int> :: iterator it2 = it1;
    //    ++it2;
    //    for(; it2 != setTaxa.end(); ++it2)
    //    {
    //        pair<int,int> pp(*it1, *it2);
    //        if( setMergedPairs.find(pp) != setMergedPairs.end() )
    //        {
    //            ++res;
    //        }
    //    }
    //}
    return res;
}

void FastSpeciesTreeInfHist :: AnalyzeTree( const set<int> &setTaxa, MarginalTree &mtree )
{
    //
    vector<pair<int,int> > listSibPairs;
    mtree.FindSibLeafPairs( listSibPairs );
    
    for(int i=0; i<(int)listSibPairs.size(); ++i)
    {
//cout << "leaf1 position: " << listSibPairs[i].first << ", leaf2 position: " << listSibPairs[i].second << endl;
        //
        pair<int,int> ppuse;
        ppuse.first = mtree.GetLabel( listSibPairs[i].first );
        ppuse.second = mtree.GetLabel( listSibPairs[i].second );
        OrderInt(ppuse.first, ppuse.second);
        //
        if( mapPairTaxaSibFreq.find(ppuse) == mapPairTaxaSibFreq.end() )
        {
            pair<int,int> ppfreq(0,0);
            mapPairTaxaSibFreq.insert( map< pair<int,int>, pair<int,int> > :: value_type( ppuse, ppfreq ) );
        }
        ++mapPairTaxaSibFreq[ppuse].first;
        
        // also maintain branch length info
        if( mapPairTaxaSibLens.find(ppuse) == mapPairTaxaSibLens.end() )
        {
            pair<double,double> pp1(0.0,0.0);
            pair<int,pair<double,double> > pp2(0, pp1);
            mapPairTaxaSibLens.insert( map< pair<int,int>, pair<int,pair<double,double> > > :: value_type( ppuse, pp2 ) );
        }
        ++mapPairTaxaSibLens[ppuse].first;
        
        //
        double len1 = mtree.GetEdgeLen( listSibPairs[i].first );
        double len2 = mtree.GetEdgeLen( listSibPairs[i].second );
        if( ppuse.first != listSibPairs[i].first )
        {
            // need switch
            len2 = mtree.GetEdgeLen( listSibPairs[i].first );
            len1 = mtree.GetEdgeLen( listSibPairs[i].second );
        }
        
        mapPairTaxaSibLens[ppuse].second.first += len1;
        mapPairTaxaSibLens[ppuse].second.second += len2;
    }
    
    // add appearence of all pairs by 1
    for( set<int> :: const_iterator it1 = setTaxa.begin(); it1 != setTaxa.end(); ++it1 )
    {
        set<int> :: const_iterator it2 = it1;
        ++it2;
        for(; it2 != setTaxa.end(); ++it2 )
        {
            pair<int,int> ppuse(*it1, *it2);

            if( mapPairTaxaSibFreq.find(ppuse) == mapPairTaxaSibFreq.end() )
            {
                pair<int,int> ppfreq(0,0);
                mapPairTaxaSibFreq.insert( map< pair<int,int>, pair<int,int> > :: value_type( ppuse, ppfreq ) );
            }
            ++mapPairTaxaSibFreq[ppuse].second;
        }
    }
    
    // also record for each subtree
    vector<set<int> > listSubtrees;
    mtree.ConsDecedentLeavesInfoLabels( listSubtrees );
    
    for(int i=0; i<(int)listSubtrees.size(); ++i)
    {
        set<int> setTaxaMerged;
        GetMergedLinsFrom( listSubtrees[i], setTaxaMerged );
        
        if( mapSubTrTaxaSibFreq.find( setTaxaMerged ) == mapSubTrTaxaSibFreq.end()  )
        {
            //
            pair<int,double> pp(0,0.0);
            mapSubTrTaxaSibFreq.insert( map<set<int>, pair<int,double> > :: value_type( setTaxaMerged, pp )  );
        }
        
        
        ++mapSubTrTaxaSibFreq[setTaxaMerged ].first;
        mapSubTrTaxaSibFreq[setTaxaMerged ].second += mtree.GetEdgeLen( i );
//cout << "Adding a record for subset of taxa: ";
//DumpIntSet(listSubtrees[i]);
//cout << ", and the merged lins: ";
//DumpIntSet(setTaxaMerged);
    }
}

void FastSpeciesTreeInfHist :: Dump() const
{
    cout << "Inference history: merged history: ";
    for( map<int, pair<int,int> > :: const_iterator it = mapMergedTaxa.begin(); it != mapMergedTaxa.end(); ++it )
    {
        cout << "<" << it->first << ">: " << it->second.first << "," << it->second.second << "  ";
    }
    cout << endl;
    cout << "For each merged child: its parent and length: ";
    for( map<int, pair<int,double> > :: const_iterator it = mapMergedTaxaParent.begin(); it != mapMergedTaxaParent.end(); ++it )
    {
        cout << "child[" << it->first << "]: " << it->second.first << ":" << it->second.second << "  ";
    }
    cout << endl;
}

void FastSpeciesTreeInfHist :: CreateTaxaMap( const set<int> &setTaxa, map<int,int> &mapTaxaToMerged )
{
//cout << "createTaxaMap:\n";
    //
    mapTaxaToMerged.clear();
    
    map<int, set<int> > mapParDesc;
    // initially everything just by itself
    for(set<int> :: const_iterator it = setTaxa.begin(); it != setTaxa.end(); ++it)
    {
        set<int> ss;
        ss.insert(*it);
        mapParDesc.insert( map<int,set<int> > :: value_type(*it, ss) );
    }
    // now start merging
    while(true)
    {
        bool fUpdated = false;
        for( map<int, set<int> > :: iterator it1 = mapParDesc.begin(); it1 != mapParDesc.end(); ++it1 )
        {
//cout << "process1: " << it1->first << ": ";
//DumpIntSet(it1->second);
            map<int, set<int> > :: iterator it2 =it1;
            ++it2;
            for(; it2 != mapParDesc.end(); ++it2)
            {
//cout << "process2: " << it2->first << ": ";
//DumpIntSet(it2->second);
                //
                pair<int,int> pp(it1->first, it2->first);
                if( setMergedPairs.find(pp) != setMergedPairs.end() )
                {
//cout << "This pair has been merged: " << pp.first << "," << pp.second << endl;
                    // merge these too
                    set<int> ssnew = it1->second;
                    UnionSets( ssnew, it2->second );
                    fUpdated = true;
                    YW_ASSERT_INFO( mapMergedTaxaParent.find(it1->first) != mapMergedTaxaParent.end(), "Fail10" );
                    int parnew = mapMergedTaxaParent[it1->first].first;
                    mapParDesc.erase( it1 );
                    mapParDesc.erase( it2 );
                    YW_ASSERT_INFO( mapParDesc.find(parnew) == mapParDesc.end(), "fail2" );
                    mapParDesc.insert( map<int,set<int> > :: value_type( parnew, ssnew )  );
                    break;
                }
            }
            if( fUpdated == true )
            {
                break;
            }
        }
        if( fUpdated == false )
        {
            break;
        }
    }
    // assing map
    for( map<int, set<int> > :: iterator it1 = mapParDesc.begin(); it1 != mapParDesc.end(); ++it1  )
    {
        for( set<int> :: iterator it2 = it1->second.begin(); it2 != it1->second.end(); ++it2 )
        {
            mapTaxaToMerged.insert( map<int,int> :: value_type( *it2, it1->first ) );
        }
    }
    
    
#if 0
    for( set<int> :: const_iterator it = setTaxa.begin(); it != setTaxa.end(); ++it )
    {
        //
        int tid = *it;
        if( mapMergedTaxaParent.find(tid) == mapMergedTaxaParent.end() )
        {
            mapTaxaToMerged.insert( map<int,int> :: value_type(tid, tid) );
        }
        else
        {
            mapTaxaToMerged.insert( map<int,int> :: value_type(tid, mapMergedTaxaParent[tid].first ) );
        }
    }
#endif
#if 0
cout << "Mapping btw taxa: ";
for(map<int,int> :: iterator it = mapTaxaToMerged.begin(); it != mapTaxaToMerged.end(); ++it)
{
cout << it->first << ": " << it->second << "   ";
}
cout << " for settaxa: ";
DumpIntSet(setTaxa);
#endif
}

int FastSpeciesTreeInfHist :: FindAncestralLin( int linId )
{
    // in the case this lineage is merged, trace to the current merged one
    if( mapMergedTaxaParent.find(linId) == mapMergedTaxaParent.end() )
    {
        return linId;
    }
    int parId = mapMergedTaxaParent[linId].first;
    return FindAncestralLin(parId);
}

void FastSpeciesTreeInfHist :: FindUnmergedLins( const set<int> &setTaxa, set<int> &setTaxaUnmerged )
{
    //
    setTaxaUnmerged.clear();
    for(set<int> :: const_iterator it = setTaxa.begin(); it != setTaxa.end(); ++it)
    {
        int idAnces = FindAncestralLin(*it);
        if( idAnces == *it)
        {
            // unmerged
            setTaxaUnmerged.insert(*it);
        }
        else
        {
            setTaxaUnmerged.insert(idAnces);
        }
    }
}

// data structure for picking subtrees to collpase

void FastSpeciesTreeInfHist :: FindSubtreesToMergeRand(const set<int> &setTaxa, int maxSzSubtree, int numAlreadyMerged, vector< set<int> > &listMergedSTs)
{
    // listMergedSTsPairSubtreeHts: lengths of two sub-trees merged
    vector<MarginalTree *> listMargTrees;
    GetRecentTree( setTaxa, listMargTrees );
    
    // initially only allow all the leaves to merge
    vector< set<int> > listMTActiveNodes;
    for(int i=0; i<(int)listMargTrees.size(); ++i)
    {
        set<int> ss;
        PopulateSetWithInterval( ss, 0, listMargTrees[i]->GetNumLeaves()-1 );
        listMTActiveNodes.push_back(ss);
    }
    
    // collect all subtrees from low to high
    int numPairsToChoose = (int)setTaxa.size()-maxSzSubtree-numAlreadyMerged;
    YW_ASSERT_INFO(numPairsToChoose>0, "Wrong: must have some to choose");
    
    listMergedSTs.clear();
    while( (int)listMergedSTs.size() < numPairsToChoose)
    {
        vector< STSiblingInfo > listSubtreesToMerge;
        for(int i=0; i<(int)listMargTrees.size(); ++i)
        {
            FindMergableSubtreesFrom(listMargTrees[i], listMTActiveNodes[i], listSubtreesToMerge);
        }
        
        //
        YW_ASSERT_INFO( listSubtreesToMerge.size() > 0, "Must have something" );
        
        // random pick one to merge
        int posToUse = (int)(GetRandFraction() * listSubtreesToMerge.size() );
        //
        set<int> stree;
        listSubtreesToMerge[posToUse].GetSubtree( stree );
        set<int> streeMerged;
        GetMergedLinsFrom(stree, streeMerged);
        listMergedSTs.push_back( streeMerged );
        
        // erase those merged nodes
        MarginalTree *ptreeCur = listSubtreesToMerge[posToUse].GetMargTree();
        int ptreeCurIndex = GetItemIndexInVecGen( listMargTrees, ptreeCur );
        YW_ASSERT_INFO( ptreeCurIndex >=0, "fail to find(1)" );
        int pos1ToErase = listSubtreesToMerge[posToUse].GetPos1();
        int pos2ToErase = listSubtreesToMerge[posToUse].GetPos2();
        YW_ASSERT_INFO( listMTActiveNodes[ptreeCurIndex].find( pos1ToErase ) != listMTActiveNodes[ptreeCurIndex].end(), "Fail1" );
        YW_ASSERT_INFO( listMTActiveNodes[ptreeCurIndex].find( pos2ToErase ) != listMTActiveNodes[ptreeCurIndex].end(), "Fail2" );
        listMTActiveNodes[ptreeCurIndex].erase( pos1ToErase );
        listMTActiveNodes[ptreeCurIndex].erase( pos2ToErase );
        int parNew = listSubtreesToMerge[posToUse].GetParPos();
        listMTActiveNodes[ptreeCurIndex].insert( parNew );
    }
}

void FastSpeciesTreeInfHist :: GetRecentTree(const set<int> &setTaxa, vector<MarginalTree *> &listMargTrees )
{
//cout << "GetRecentTree: setTaxa: ";
//DumpIntSet(setTaxa);
    //
    set<int> setTaxaCurr = setTaxa;
    while( setTaxaCurr.size() > 0 )
    {
//cout << "setTaxaCurr:";
//DumpIntSet(setTaxaCurr);
        // pick the one that contains this node and is the largest
        MarginalTree *ptreeCur = NULL;
        set<int> setLeavesFound;
        int szMaxCur = 0;
        for( map< set<int>, MarginalTree> :: iterator it = mapSubsetInfTrees.begin(); it != mapSubsetInfTrees.end(); ++it )
        {
            if( IsSetContainer( setTaxaCurr, it->first ) == true && szMaxCur < (int)it->first.size() )
            {
                //
                szMaxCur = (int)it->first.size();
                ptreeCur = &(it->second);
                setLeavesFound = it->first;
            }
        }
        if(ptreeCur!=NULL)
        {
            listMargTrees.push_back( ptreeCur );
        }
        else
        {
            break;
        }
        SubtractSets( setTaxaCurr, setLeavesFound );
    }
    // should be exactly two trees found
    //YW_ASSERT_INFO( listMargTrees.size() == 2, "Should have exactly two trees found" );
}

MarginalTree * FastSpeciesTreeInfHist :: GetMargTreeForTaxa(const set<int> &setTaxa) const
{
    if( mapSubsetInfTrees.find(setTaxa) == mapSubsetInfTrees.end() )
    {
        cout << "In GetMargTreeForTaxa: not found: ";
        DumpIntSet(setTaxa);
        
        return NULL;
    }
    
    YW_ASSERT_INFO( mapSubsetInfTrees.find(setTaxa) != mapSubsetInfTrees.end(), "Fail12" );
    MarginalTree *pres = const_cast<MarginalTree *>(&( mapSubsetInfTrees.find(setTaxa)->second));
    return pres;
}

void FastSpeciesTreeInfHist :: FindMergableSubtreesFrom( MarginalTree *ptreeCur, const set<int> &setTaxaToUse, vector< STSiblingInfo > &listSubtreesToMerge )
{
    // find all mergable items
    set<int> setPosDone;
    for(set<int> :: const_iterator it = setTaxaToUse.begin(); it != setTaxaToUse.end(); ++it)
    {
        //
        if( setPosDone.find(*it) != setPosDone.end() )
        {
            continue;
        }
        // check whether its sibling is there, if so, add this pair
        int nodeIndex = *it;
        if( nodeIndex != ptreeCur->GetRoot() )
        {
            int sibling = ptreeCur->GetSibling( nodeIndex );
            if( setTaxaToUse.find( sibling) != setTaxaToUse.end() )
            {
                STSiblingInfo sibInfo( ptreeCur, nodeIndex, sibling );
                listSubtreesToMerge.push_back(sibInfo);
                
                setPosDone.insert(nodeIndex);
                setPosDone.insert( sibling );
            }
        }
    }
}

void FastSpeciesTreeInfHist :: FindEnclosedSubtrees( const set<int> &setTaxa, set<int> &setTaxaSub1, set<int> &setTaxaSub2  ) const
{
    //
    setTaxaSub1.clear();
    int szMaxCur = 0;
    for( map< set<int>, MarginalTree> :: const_iterator it = mapSubsetInfTrees.begin(); it != mapSubsetInfTrees.end(); ++it )
    {
        if( IsSetContainer( setTaxa, it->first ) == true && szMaxCur < (int)it->first.size() )
        {
            //
            szMaxCur = (int)it->first.size();
            setTaxaSub1 = it->first;
        }
    }
    YW_ASSERT_INFO( setTaxaSub1.size() > 0, "Fail to find" );
    setTaxaSub2 = setTaxa;
    SubtractSets( setTaxaSub2, setTaxaSub1 );
}

//////////////////////////////////////////////////////////////////////////////////
// Fast inference of species tree


FastSpeciesTreeInference :: FastSpeciesTreeInference( int numSpeciesIn, vector<PhylogenyTreeBasic *> &listGeneTreePtrsIn, const vector<int> &listMP, TaxaMapper &mapperTaxaIdsIn, const string &strTreeInitIn ) : numSpecies(numSpeciesIn), listGeneTreePtrs(listGeneTreePtrsIn), listMultiplicity(listMP), mapperTaxaIds(mapperTaxaIdsIn), strTreeInit(strTreeInitIn), minSzSubtree(DEF_MIN_SZ_SUBTREE), maxSzSubtree(DEF_MAX_SZ_SUBTREE), maxIdentSubtreeSz(DEF_MAX_SZ_IDENTSUBTREE), maxGTreeSz(DEF_MAX_SZ_SUBGENTREE), maxNumIterations(DEF_MAX_NUM_ITERATION)
{
    //
}

FastSpeciesTreeInference :: ~FastSpeciesTreeInference()
{
    //
}

bool FastSpeciesTreeInference :: InfConverge()
{
    //
    MarginalTree initST;
    BuildInitST(initST);
    
    
    MarginalTree mtreeCurOpt = initST;
    mtreeCurOpt.SortByLeafId();
    
    //const int maxNumIterations = 10;
    int numIters = 0;
    bool fConverged = false;
    
    while( ++numIters <= maxNumIterations )
    {
cout << "In iteration " << numIters << " for searching species tree, current estimate of species tree: " << mapperTaxaIds.ConvIdStringWithOrigTaxa( mtreeCurOpt.GetNewick() ) << endl;
//cout << "********************** Iteration: " << numIters << ": current guide tree is: " << mapperTaxaIds.ConvIdStringWithOrigTaxa( mtreeCurOpt.GetNewick() ) << endl;
    
        // use the approach of converging: each round should use a new history record
        FastSpeciesTreeInfHist histSTInf(numSpecies);
        
        vector< set<int> > listSubtreesToProc;
        GetSubtreesBottomUp( mtreeCurOpt, listSubtreesToProc );
//cout << "List of subtrees: \n";
//for(int i=0; i<(int)listSubtreesToProc.size(); ++i)
//{
//DumpIntSet(listSubtreesToProc[i]);
//}
        
        //
        MarginalTree mtreeCur;
        
        for(int i=0; i<(int)listSubtreesToProc.size(); ++i)
        {
//cout << "**Processing subset: ";
//DumpIntSet(listSubtreesToProc[i]);
            // skip subtrees that are too small
            if( (int)listSubtreesToProc[i].size() < minSzSubtree )
            {
                continue;
            }
            
            // if the subset is too large
            int numAlreadyMerged = histSTInf.GetNumMergedPairsWithin( listSubtreesToProc[i] );
            if( (int)listSubtreesToProc[i].size() > maxSzSubtree+numAlreadyMerged )
            {
                vector< set<int> > listMergedSTs;
                vector< pair<double,double> > listMergedSTsPairSubtreeHts;
                histSTInf.FindSubtreesToMergeRand(listSubtreesToProc[i], maxSzSubtree, numAlreadyMerged, listMergedSTs);
 
//cout << "List of subtrees to merge: \n";
//for(int i=0; i<(int)listMergedSTs.size(); ++i)
//{
//DumpIntSet(listMergedSTs[i]);
//}
//cout << "List of sub-children hts: ";
//for(int i=0; i<(int)listMergedSTsPairSubtreeHts.size(); ++i)
//{
//cout << listMergedSTsPairSubtreeHts[i].first << "," << listMergedSTsPairSubtreeHts[i].second << endl;
//}
                
                // update history???
                for(int jj=0;jj<(int)listMergedSTs.size(); ++jj)
                {
                    pair<double,double> pp(-1.0,-1.0);
                    if( listMergedSTsPairSubtreeHts.size() == listMergedSTs.size() )
                    {
                        pp = listMergedSTsPairSubtreeHts[jj];
                    }
                    histSTInf.MergeSetofTaxa( listMergedSTs[jj], pp );
                }
            }
            
            // now infer it
            MarginalTree mtreeSub;
            InfSubST( histSTInf, listSubtreesToProc[i], mtreeSub );
            
            histSTInf.AddInfTree( listSubtreesToProc[i], mtreeSub );
            
//cout << "The inferred sub-species tree: ";
//cout << mtreeSub.GetNewick() << " for subset: ";
//DumpIntSet( listSubtreesToProc[i] );
        
            mtreeCur = mtreeSub;
        }
    
        // now get the original set of taxa back
        histSTInf.ExpandContractedSubtrees( mtreeCur );
        mtreeCur.SortByLeafId();
        //cout << "After expaning: the inferred species tree: " << mtreeCur.GetNewick() << endl;
//string treeInfNW = mtreeCur.GetNewick();
//cout << "The inferred species tree: " << mapperTaxaIds.ConvIdStringWithOrigTaxa(treeInfNW) << endl;
        
        // stop if converged: get the same topology as
        if( mtreeCurOpt.IsToplogicSame( mtreeCur ) == true )
        {
            fConverged = true;
            break;
        }
        else
        {
            mtreeCurOpt = mtreeCur;
        }
        
        // dump out history
        //histSTInf.Dump();
    }
    
    // save the final tree
    //this->strTreeInferred = mapperTaxaIds.ConvIdStringWithOrigTaxa( mtreeCurOpt.GetNewick() );
    this->strTreeInferred = mtreeCurOpt.GetNewick();
    
    //if( fConverged == true )
    //{
    //    cout << "************************************************************************\n";
    //    cout << "The fastSTELLS INFERRED SPECIES TREE: " << this->strTreeInferred << endl;
    //}
    //if( fConverged == false )
    //{
        //cout << "Warning: convergence is not achieved within the number of allowed iterations. You may consider changing the settings (e.g. increasing the number of allowed iterations.\n";
    //}
    return fConverged;
}

//
void FastSpeciesTreeInference :: BuildInitST(MarginalTree &initST)
{
    // the default one is using MDC trees
	ReadinMarginalTreesNewickWLenString( strTreeInit, GetNumSpecies(), initST );
	// init branch length of every edge to be 1.0
	const double DEFAULT_BRANCH_LEN = 1.0;
	for( int b=0; b<initST.GetTotNodesNum()-1; ++b )
	{
		initST.SetBranchLen(b, DEFAULT_BRANCH_LEN);
	}
}

void FastSpeciesTreeInference :: GetSubtreesBottomUp( MarginalTree &mtree, vector<set<int> > &listSubtrees )
{
    //
    mtree.ConsDecedentLeavesInfo( listSubtrees );
}

void FastSpeciesTreeInference :: InfSubST( FastSpeciesTreeInfHist &histSTInf, const set<int> &setTaxa, MarginalTree &mtreeSub )
{
    int szSubtree = (int)setTaxa.size() - histSTInf.GetNumMergedPairsWithin( setTaxa );
//cout << "infsubst: szSubtree:" << szSubtree << endl;
    // setTaxa: what subset of taxa to infer
    vector<PhylogenyTreeBasic *> listSubgtrees;
    CreateSubGenetrees( setTaxa, listSubgtrees );
    
    vector<int> listMultiplicity;
    for(int i=0; i<(int)listSubgtrees.size(); ++i)
    {
        listMultiplicity.push_back(1);
    }
    
    // relabel all gene trees
    for(int i=0; i<(int)listSubgtrees.size(); ++i)
    {
        RelabelGenetree( listSubgtrees[i], histSTInf, false );
    }
    
    // convert genetrees to zero-based
    TaxaMapper mapperSubtree;
    ConvPhyloTreesToZeroBasedId( listSubgtrees, &mapperSubtree );
    
    vector<string> vecNWParsTrees;
    bool fDiffTaxaInGTrees = false;
    const int numMDCLevels = 5;
    const int fMoreClade = false;
    const int maxNumMDCMoreClades = 0;
    int numTreeSamples = 50;
    ConsInitTreesFromInputTrees(listSubgtrees, listMultiplicity, mapperSubtree, vecNWParsTrees, false, numMDCLevels, fMoreClade, maxNumMDCMoreClades, numTreeSamples, fDiffTaxaInGTrees);
//cout << "Initial trees: \n";
//for(int i=0; i<(int)vecNWParsTrees.size(); ++i)
//{
//cout << mapperSubtree.ConvIdStringWithOrigTaxa( vecNWParsTrees[i] ) << endl;
//}
    
    // Reduce the size of subtrees
    ReduceSubtrees( listSubgtrees );
//cout << "After gene tree reduction, the size of gene trees: ";
//for(int i=0; i<(int)listSubgtrees.size(); ++i)
//{
//cout << listSubgtrees[i]->GetNumLeaves() << ", ";
//}
//cout << endl;
    
    // here also ensure the gene trees are not too large
    for(int i=0; i<(int)listSubgtrees.size(); ++i)
    {
        RandTrimLeavesFromTree( listSubgtrees[i], maxGTreeSz );
    }
    
    // infer the tree
    SpeciesTreeExplorer streeExplorer2( szSubtree, listSubgtrees, listMultiplicity, mapperSubtree );
    streeExplorer2.SetOutputTreeHere( false );
    streeExplorer2.SetOutputMoreInfo( false );
    streeExplorer2.ExploreFrom(vecNWParsTrees);
    streeExplorer2.GetBestInfSpeicesMargTreeConv( mtreeSub );
    //string resTreeNW = streeExplorer2.GetBestInfSpeicesTreeConv();
    //ReadinMarginalTreesNewickWLenString( resTreeNW, setTaxa.size(), mtreeSub );
//cout << "mtreesub: " << mtreeSub.GetNewick() << endl;
    // freeup
    for(int i=0; i<(int)listSubgtrees.size(); ++i)
    {
        delete listSubgtrees[i];
    }
}

void FastSpeciesTreeInference :: CreateSubGenetrees( const set<int> &setTaxa, vector<PhylogenyTreeBasic *> &listSubgtrees )
{
    //
    for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
    {
        PhylogenyTreeBasic *ptr = CreateSubGenetreeFor( setTaxa, listGeneTreePtrs[i] );
        listSubgtrees.push_back( ptr );
    }
}

PhylogenyTreeBasic * FastSpeciesTreeInference :: CreateSubGenetreeFor( const set<int> &setTaxa, PhylogenyTreeBasic *pgtree )
{
    set<string> setStrs;
    for(set<int> :: iterator it = setTaxa.begin(); it != setTaxa.end(); ++it )
    {
        char buf[100];
        sprintf(buf, "%d", *it);
        string sbuf(buf);
        setStrs.insert(sbuf);
    }
    
    //
    PhylogenyTreeBasic *ptreeNew = new PhylogenyTreeBasic;
    pgtree->CreatePhyTreeFromLeavesWithLabels(setStrs, *ptreeNew, true);
    AssignConsecutiveIdsForTree( *ptreeNew );
    return ptreeNew;
}

void FastSpeciesTreeInference :: RelabelGenetree( PhylogenyTreeBasic *pgtree, FastSpeciesTreeInfHist &histSTInf, bool fUpdateUserLbl )
{
    // some taxa may have already merged; so relabel those merged labels
    // create map first
//cout << "RelabelGenetree:";
//string strNWOld;
//pgtree->ConsNewick(strNWOld);
    
    vector<int> listLbls;
    pgtree->GetAllLeafIntLabeles( listLbls );
    set<int> setListLbls;
    PopulateSetByVec(setListLbls, listLbls);
    map<int,int> mapLabelToMerged;
    histSTInf.CreateTaxaMap( setListLbls, mapLabelToMerged );
    ChangeLeafIntLabelOfTree(*pgtree, mapLabelToMerged, fUpdateUserLbl);
//string strNWNew;
//pgtree->ConsNewick(strNWNew, false, 1.0, true);
//cout << "Before conversion: tree: " << strNWOld << ". After conversion: tree: " << strNWNew << endl;
}

void FastSpeciesTreeInference :: ReduceSubtrees( vector<PhylogenyTreeBasic *> &listSubgtrees )
{
    // try to reduce the size of subtrees
    vector<PhylogenyTreeBasic *> listSubgtreesNew;
    for(int i=0; i<(int)listSubgtrees.size(); ++i)
    {
        //
//cout << "In ReduceSubtrees: ";
//listSubgtrees[i]->Dump();
        PhylogenyTreeBasic *phtreeSmaller = ConsPhyTreeShrinkIdentSubtrees( listSubgtrees[i], maxIdentSubtreeSz, true );
        delete listSubgtrees[i];
        listSubgtreesNew.push_back( phtreeSmaller );
    }
    listSubgtrees = listSubgtreesNew;
}

// *************************************************************************************************************************
// inf species tree based on triples
void FastSpeciesTreeInference :: InferTriples()
{
    //
    // use the approach of converging: each round should use a new history record
    FastSpeciesTreeInfHist histSTInf(numSpecies);
    
    int numSpeciesCurr = numSpecies;
    set<int> setTaxaCurr;
    PopulateSetWithInterval( setTaxaCurr, 0, numSpecies-1 );
    MarginalTree mtreeFinal;
    
    map< set<int>, MarginalTree > mapSubsetInfTrees;
    //set<int> setTidsNew;
    
    // infer triples if there are
    while( numSpeciesCurr >= 2 )
    {
//cout << "In iteration: number of taxa left: " << numSpeciesCurr << " and current history of merging: ";
//histSTInf.Dump();
//cout << "Current set of taxa: ";
//DumpIntSet(setTaxaCurr);
        

        // inf sibling pairs from these trees
        vector<FSTISiblingPair> listSibPairs;
        bool fTriple = InfSiblingPairs( setTaxaCurr, histSTInf, listSibPairs, mapSubsetInfTrees );
        
        // save the final tree
        if(  fTriple == false || numSpeciesCurr <= 3 )
        {
            //
            YW_ASSERT_INFO( mapSubsetInfTrees.find( setTaxaCurr ) != mapSubsetInfTrees.end(), "Fail to find the inferred tree" );
            mtreeFinal = mapSubsetInfTrees[ setTaxaCurr ];
            break;
        }
        
        // update sibling info
        int numTriplesApplied = 0;
        for( vector<FSTISiblingPair> :: iterator it = listSibPairs.begin(); it != listSibPairs.end(); ++it )
        {
            // don't add triples if the taxa set is already small enough
            if( (int)setTaxaCurr.size() <=  this->maxSzSubtree )
            {
                break;
            }
            
            // now consier merging it
            pair<int,int> pp1( it->GetTaxon1(), it->GetTaxon2() );
            pair<double,double> pp2( it->GetTaxon1Dist(), it->GetTaxon2Dist() );
            int sibPar = histSTInf.MergePair( pp1, pp2  );
            //setTidsNew.insert(sibPar);
            setTaxaCurr.insert(sibPar);
            setTaxaCurr.erase( it->GetTaxon1() );
            setTaxaCurr.erase( it->GetTaxon2() );
            --numSpeciesCurr;
            ++numTriplesApplied;
        }
        
        if( numTriplesApplied == 0 )
        {
            break;
        }

//dump out history
//histSTInf.Dump();
    }
    
    // now get the original set of taxa back
    histSTInf.ExpandContractedSubtrees( mtreeFinal );
    mtreeFinal.SortByLeafId();
//cout << "After expaning: the inferred species tree: " << mtreeFinal.GetNewick() << endl;
    string treeInfNW = mtreeFinal.GetNewick();
    //this->strTreeInferred = mapperTaxaIds.ConvIdStringWithOrigTaxa(treeInfNW) ;
    //cout << "The triple-based inferred species tree: " << this->strTreeInferred << endl;
    this->strTreeInferred = treeInfNW;
        
}

bool FastSpeciesTreeInference :: InfSiblingPairs( const set<int> &setTaxa, FastSpeciesTreeInfHist &histSTInf, vector<FSTISiblingPair> &setSibPairs, map< set<int>, MarginalTree > &mapSubsetInfTrees )
{
    // return false if no triple is returned
//cout << "InfSiblingPairs: setTaxa: ";
//DumpIntSet( setTaxa);
    
    // if there are only two taxa left, directly infer the subtree without taking the triples
    bool fTripleMode = true;
    int szSubset = 3;
    if( setTaxa.size() == 2 )
    {
        szSubset = 2;
        fTripleMode = false;
    }
    // if the subset is small enough, infer the tree directly
    else if( (int)setTaxa.size() <= this->maxSzSubtree )
    {
        szSubset = (int)setTaxa.size();
        fTripleMode = false;
    }
    
    // don't use fixed coalescent mode since it may be too slow for large trees
    if( fTripleMode == false )
    {
        SetFixedCoalCalcMode(false);
    }
    
    
    //
    FSTISiblingAnalyzer sibAnalyzer;
    
    // first create gene trees
    //
    vector<PhylogenyTreeBasic *> listGTreesConv;
    CreateSubGenetreesForMergedTaxa( histSTInf, listGTreesConv );
//for(int i=0; i<(int)listGTreesConv.size(); ++i )
//{
//cout << "Converted tree: ";
//string nwt;
//listGTreesConv[i]->ConsNewick(nwt);
//cout << nwt << endl;
//}
    
    // note: assume each gene tree contains the same set of taxa
    // inf species trees for all triples
    vector<int> listSetTaxa;
    PopulateVecBySet( listSetTaxa, setTaxa );
    vector<int> posvec;
    GetFirstCombo(szSubset, (int)listSetTaxa.size(), posvec);
    while(true)
    {
        // inf these three things
        set<int> setTaxaUse;
        for(int i=0; i<(int)posvec.size(); ++i )
        {
            setTaxaUse.insert( listSetTaxa[ posvec[i] ] );
        }
        
        // skip if it is already inferred before
        MarginalTree mtreeSub;
        
        if( mapSubsetInfTrees.find(setTaxaUse) != mapSubsetInfTrees.end() )
        {
            // retrive that tree and pass it to analyzer
            mtreeSub = mapSubsetInfTrees[setTaxaUse];
        }
        else
        {
            // need to infer the tree
            // setTaxa: what subset of taxa to infer
            vector<PhylogenyTreeBasic *> listSubgtrees;
            vector<int> listMPUse;
            for(int i=0; i<(int)listGTreesConv.size(); ++i)
            {
                // if not all these taxa appears in the gene tree, skip
                vector<int> listLeafLabels;
                listGTreesConv[i]->GetAllLeafIntLabeles(listLeafLabels);
                set<int> setTaxaStep;
                PopulateSetByVec( setTaxaStep, listLeafLabels );
                if( IsSetContainer( setTaxaStep, setTaxaUse ) == false )
                {
                    continue;
                }
                
                PhylogenyTreeBasic *ptr = FastSpeciesTreeInference :: CreateSubGenetreeFor( setTaxaUse, listGTreesConv[i] );
                listSubgtrees.push_back( ptr );
                listMPUse.push_back( listMultiplicity[i] );
            }
            
            // if no tree is found, done
            if( listSubgtrees.size() == 0 )
            {
                cout << "WARNING: there is no trees containing this triples: ";
                DumpIntSet( setTaxaUse );
                continue;
            }
            
            // convert genetrees to zero-based
            TaxaMapper mapperSubtree;
            ConvPhyloTreesToZeroBasedId( listSubgtrees, &mapperSubtree );
            
            vector<string> vecNWParsTrees;
            bool fDiffTaxaInGTrees = false;
            const int numMDCLevels = 5;
            const int fMoreClade = false;
            const int maxNumMDCMoreClades = 0;
            int numTreeSamples = 50;
            ConsInitTreesFromInputTrees(listSubgtrees, listMPUse, mapperSubtree, vecNWParsTrees, false, numMDCLevels, fMoreClade, maxNumMDCMoreClades, numTreeSamples, fDiffTaxaInGTrees);
            //cout << "Initial trees: \n";
            //for(int i=0; i<(int)vecNWParsTrees.size(); ++i)
            //{
            //cout << mapperSubtree.ConvIdStringWithOrigTaxa( vecNWParsTrees[i] ) << endl;
            //}
            
            // Reduce the size of subtrees
            //ReduceSubtrees( listSubgtrees );
            //cout << "After gene tree reduction, the size of gene trees: ";
            //for(int i=0; i<(int)listSubgtrees.size(); ++i)
            //{
            //cout << listSubgtrees[i]->GetNumLeaves() << ", ";
            //}
            //cout << endl;
            
            // here also ensure the gene trees are not too large
            //for(int i=0; i<(int)listSubgtrees.size(); ++i)
            //{
            //    RandTrimLeavesFromTree( listSubgtrees[i], maxGTreeSz );
            //}
            
            // infer the tree
            SpeciesTreeExplorer streeExplorer2( szSubset, listSubgtrees, listMPUse, mapperSubtree );
            streeExplorer2.SetOutputTreeHere( false );
            streeExplorer2.SetOutputMoreInfo( false );
            streeExplorer2.ExploreFrom(vecNWParsTrees);

            streeExplorer2.GetBestInfSpeicesMargTreeConv( mtreeSub );
            string resTreeNW = streeExplorer2.GetBestInfSpeicesTreeConv();
            //ReadinMarginalTreesNewickWLenString( resTreeNW, setTaxaUse.size(), mtreeSub );
            //RemapMargTree( mtreeSub, mapperTaxaIds );
            //cout << "Sub-tree (with new taxa id): " << mtreeSub.GetNewick() << "  for taxa: ";
            //DumpIntSet(setTaxaUse);
            //cout << "Sub-tree (with original taxa id): " << mapperTaxaIds.ConvIdStringWithOrigTaxa( mtreeSub.GetNewick() ) << endl;
//cout << "Sub-tree (with original taxa id): " << mtreeSub.GetNewick() << endl;
            
            // remember it
            mapSubsetInfTrees.insert(  map< set<int>, MarginalTree > :: value_type( setTaxaUse, mtreeSub ) );

            
            // freeup
            for(int i=0; i<(int)listSubgtrees.size(); ++i)
            {
                delete listSubgtrees[i];
            }
        }
        
        // now analyze this tree
        if( fTripleMode == true )
        {
            sibAnalyzer.AnalyzeTree( mtreeSub );
        }
        
        //
        if( GetNextCombo(szSubset, (int)listSetTaxa.size(), posvec) == false )
        {
            break;
        }
    }
    
//cout << "Done with subtree inference...\n";
    
    // now find the siblings as merge candidates
    setSibPairs.clear();
    
    // if subset size is 3 (i.e. has at least three taxa left)
    if( fTripleMode == true )
    {
        set< pair<int,int> > setSibPairsTaxa;
        bool fTrusted = sibAnalyzer.FindTrustedSibPairs( setSibPairsTaxa );
        
        //
        if( fTrusted == false )
        {
            cout << "WARNING: did not find any trusted siblings. Use MDC to assist sibling identificaiton.\n";
//cout << "WARNING: did not find any trusted siblings. Here are possible candidates:";
//cout << "Found sibling pairs: ";
//for( set< pair<int,int> > :: iterator it = setSibPairsTaxa.begin(); it != setSibPairsTaxa.end(); ++it )
//{
//cout << "[" << it->first << "," << it->second << "]  ";
//}
//cout << endl;
            // now also consult MDC
            const int MDC_LEVEL = 1;
            vector<FSTISiblingPair> listSibPairsMDC;
            InfSiblingPairsMDC( MDC_LEVEL, setTaxa, histSTInf, listSibPairsMDC );
            
//cout << "Found sibling pairs (MDC) candidate: ";
//for( int iii=0; iii< (int) listSibPairsMDC.size(); ++iii )
//{
//cout << "[" << listSibPairsMDC[iii].GetTaxon1() << "," << listSibPairsMDC[iii].GetTaxon2() << "]  ";
//}
//cout << endl;
            
            // if MDC found trusted ones, use it
            //if( fMDC == true )
            //{
            //    //
            //    setSibPairsTaxa.clear();
            //    for(int jj=0; jj<(int)listSibPairsMDC.size(); ++jj)
            //    {
            //        pair<int,int> pp( listSibPairsMDC[jj].GetTaxon1(), listSibPairsMDC[jj].GetTaxon2() );
            //        setSibPairsTaxa.insert(pp);
//cout << "Now use MDC trusted pair: " << pp.first << "," << pp.second << endl;
            //    }
            //}
            //else
            //{
            // find the first regular sib that agree with MDC
            pair<int,int> ppTOMerge;
            bool fFound = FSTISiblingPair::FindBestSibAlsoIn2ndList( setSibPairsTaxa, listSibPairsMDC, ppTOMerge );
            if( fFound == false )
            {
                // use the very first one
                YW_ASSERT_INFO( setSibPairsTaxa.size() > 0, "Empty" );
                ppTOMerge = *( setSibPairsTaxa.begin() );
//cout << "There is no MDC involved pair is found. So use the first original pair\n";
            }
            else
            {
//cout << "This is a MDC assisted silb pair" << endl;
            }
            // use this instead
            setSibPairsTaxa.clear();
            setSibPairsTaxa.insert( ppTOMerge );
            //}
        }
        YW_ASSERT_INFO( setSibPairsTaxa.size() > 0, "Cannot be empty" );
        
//cout << "Found sibling pairs: ";
//for( set< pair<int,int> > :: iterator it = setSibPairsTaxa.begin(); it != setSibPairsTaxa.end(); ++it )
//{
//cout << "[" << it->first << "," << it->second << "]  ";
//}
//cout << endl;
        
        // now find out the est branch lengths
        for( set< pair<int,int> > :: iterator it = setSibPairsTaxa.begin(); it != setSibPairsTaxa.end(); ++it )
        {
            double dist1 = 0.0, dist2 = 0.0;
            EstSibPairDist( mapSubsetInfTrees, it->first, it->second, dist1, dist2 );
            FSTISiblingPair sinfo( it->first, it->second, dist1, dist2 );
            setSibPairs.push_back( sinfo );
//cout << "For siblings: " << it->first << "," << it->second << ": dist1=" << dist1 << ", dist2=" << dist2 << endl;
        }
    }
    
    // free
    for(int i=0; i<(int)listGTreesConv.size(); ++i)
    {
        delete listGTreesConv[i];
    }
    listGTreesConv.clear();
    
    return fTripleMode;
}

// infer MDC based trees
bool FastSpeciesTreeInference :: InfSiblingPairsMDC( int mdcLevel, const set<int> &setTaxa, FastSpeciesTreeInfHist &histSTInf, vector<FSTISiblingPair> &setSibPairs)
{
//cout << "InfSiblingPairsMDC: setTaxa: ";
//DumpIntSet(setTaxa);
    //
    FSTISiblingAnalyzer sibAnalyzer;
    
    // first create gene trees
    //
    vector<PhylogenyTreeBasic *> listGTreesConv;
    CreateSubGenetreesForMergedTaxa( histSTInf, listGTreesConv );
//for(int i=0;i<(int)listGTreesConv.size(); ++i)
//{
//string strNW;
//listGTreesConv[i]->ConsNewick(strNW);
//cout << "In InfSiblingPairsMDC: tree: " << strNW << endl;
//}
    
    // convert tree id
    TaxaMapper mapperSubtree;
    ConvPhyloTreesToZeroBasedId( listGTreesConv, &mapperSubtree );
    
    // construct MDC trees
    const int maxNumMDCTreeSamples = 100;
    vector<string> vecNWParsTrees;
    bool fDiffTaxaInGTrees = false;
    ConsInitTreesFromInputTrees(listGTreesConv, listMultiplicity, mapperTaxaIds, vecNWParsTrees, true, mdcLevel, false, 0, maxNumMDCTreeSamples, fDiffTaxaInGTrees);
    
    //
//cout << "InfSiblingPairsMDC: " << vecNWParsTrees.size() << endl;
    // analyze the list of trees (w/ br len) to find common siblings
    // construct marginal trees from these
    FSTISiblingAnalyzer analyzerTrip;
    for(int i=0; i<(int)vecNWParsTrees.size(); ++i)
    {
        string trNW = vecNWParsTrees[i];
//cout << "trNW: " << trNW << endl;
        string trNWConv1 = mapperSubtree.ConvIdStringWithOrigTaxa( trNW );
//cout << "trNWConv1: " << trNWConv1 << endl;
//        string trNWConv = mapperTaxaIds.ConvIdStringWithOrigTaxa( trNWConv1 );
        cout << "Triple: analyzinig: " << trNWConv1 << endl;
        MarginalTree mtreeCurr;
        ReadinMarginalTreesNewickWLenString( trNWConv1, (int)setTaxa.size(), mtreeCurr );
        analyzerTrip.AnalyzeTree( mtreeCurr );
    }
    
    
    set<pair<int,int> > setSibPairsTaxa;
    bool fMDC = analyzerTrip.FindTrustedSibPairs( setSibPairsTaxa );
    cout << "Found sibling pairs: ";
    for( set< pair<int,int> > :: iterator it = setSibPairsTaxa.begin(); it != setSibPairsTaxa.end(); ++it )
    {
        cout << "[" << it->first << "," << it->second << "]  ";
    }
    cout << endl;
    
    // now find out the est branch lengths
    for( set< pair<int,int> > :: iterator it = setSibPairsTaxa.begin(); it != setSibPairsTaxa.end(); ++it )
    {
        // MDC does not have distance
        double dist1 = 1.0, dist2 = 1.0;
        FSTISiblingPair sinfo( it->first, it->second, dist1, dist2 );
        setSibPairs.push_back( sinfo );
//cout << "For MDC siblings: " << it->first << "," << it->second << ": dist1=" << dist1 << ", dist2=" << dist2 << endl;
    }
    return fMDC;
}


// construct gene trees with the taxa (which may be those obtained after merging)
void FastSpeciesTreeInference :: CreateSubGenetreesForMergedTaxa( FastSpeciesTreeInfHist &histSTInf, vector<PhylogenyTreeBasic *> &listSubgtrees )
{
    //
    for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
    {
        // create a subtree
        PhylogenyTreeBasic *ptrTreeConv = listGeneTreePtrs[i]->Copy();
        RelabelGenetree(ptrTreeConv, histSTInf, true);
        listSubgtrees.push_back( ptrTreeConv );
    }
    
    // reduce the size of gene trees
    ReduceSubtrees( listSubgtrees );
}

void FastSpeciesTreeInference :: EstSibPairDist( map< set<int>, MarginalTree > &mapSubsetInfTrees, int sibId1, int sibId2, double &dist1, double &dist2 )
{
    // estimate distance of the two pairs
    dist1 = 0.0;
    dist2 = 0.0;
    int numOcc = 0;
    for( map< set<int>, MarginalTree > :: iterator it = mapSubsetInfTrees.begin(); it != mapSubsetInfTrees.end(); ++it )
    {
        MarginalTree mtreeCur = it->second;
        
        //
        int post1 = mtreeCur.GetPosForLabel(sibId1);
        int post2 = mtreeCur.GetPosForLabel(sibId2);
        if( post1 >= 0 && post2 >= 0 )
        {
            int mrca = mtreeCur.GetMRCA( post1, post2 );
            double dist1Step = mtreeCur.GetPathLen( post1, mrca );
            double dist2Step = mtreeCur.GetPathLen( post2, mrca );
            dist1 += dist1Step;
            dist2 += dist2Step;
            ++numOcc;
        }
    }
    if( numOcc > 0 )
    {
        dist1 = dist1/numOcc;
        dist2 = dist2/numOcc;
    }
}

