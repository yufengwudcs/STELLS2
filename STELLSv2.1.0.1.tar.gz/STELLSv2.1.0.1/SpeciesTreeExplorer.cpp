#include "SpeciesTreeExplorer.h"
#include "STBranchLenFinder.h"
#include "DeepCoalescence.h"
#include "TreeInfSubsets.h"
#include "UtilsNumerical.h"


// hill climb param
const double MIN_LIKELIHOOD_INC_RATIO_TOPO = 1.05;
//const double MIN_LOGLIKELI_INC_TOPO = log(MIN_LIKELIHOOD_INC_RATIO_TOPO);
double thresMinLikelihoodIncRatioTopo = MIN_LIKELIHOOD_INC_RATIO_TOPO;

double GetLikeliThresTopo()
{
    return thresMinLikelihoodIncRatioTopo;
}
void SetLikeliThresTopo(double thres)
{
    thresMinLikelihoodIncRatioTopo = thres;
}

//////////////////////////////////////////////////////////////////////////////////
// Finding candidate trees from a single tree through NNI


// take a single tree and explore its NNI trees
NNINgbrTreesFinder :: NNINgbrTreesFinder(PhylogenyTreeBasic &stcur) : speciesTreeCur( stcur )
{
}

// find NNI neighbor trees (represented by Newick)
void NNINgbrTreesFinder :: Find(set<string> &setNgbrNWTrees)
{
	setNgbrNWTrees.clear();
	// iterate each non-leaf node
	PhylogenyTreeIterator itorPT(speciesTreeCur);
	itorPT.Init();
	while( itorPT.IsDone() == false )
	{
		TreeNode *pntree = itorPT.GetCurrNode();
		// only consider non-leaf and non-root
		if( pntree->IsLeaf() == false  &&  pntree != speciesTreeCur.GetRoot() )
		{
			// try to move it around
			vector<TreeNode *> listSibs;
			pntree->GetSiblings(listSibs);
			// only work with binary tree for now
			YW_ASSERT_INFO( listSibs.size() == 1, "Tree not binary" );
			TreeNode *pnsib = listSibs[0];
			YW_ASSERT_INFO( pntree->GetChildrenNum() == 2, "Not binary tree. Wrong" );
			TreeNode *pnchild1 = pntree->GetChild(0);
			TreeNode *pnchild2 = pntree->GetChild(1);

			// perform temp change of parent-ship and get Newick
			string nwtreetmp1;
			GetTempChangedTreeAt( pnsib, pnchild1, nwtreetmp1 );
			string nwtreetmp2;
			GetTempChangedTreeAt( pnsib, pnchild2, nwtreetmp2 );

			// add to record
			setNgbrNWTrees.insert(nwtreetmp1);
			setNgbrNWTrees.insert(nwtreetmp2);
		}

		// move on to next
		itorPT.Next();
	}
}



// temparary change the tree by swapping the two nodes and get the modified tree
void NNINgbrTreesFinder :: GetTempChangedTreeAt( TreeNode *tnchange1, TreeNode *tnchange2, string & nwtreetmp )
{
	// keep track of nodes so we can detach and attach it
	TreeNode *pncpar1 = tnchange1->GetParent();
	TreeNode *pncpar2 = tnchange2->GetParent();
	YW_ASSERT_INFO(pncpar1 != NULL && pncpar2 != NULL, "Can not swap nodes if parents are null");
	pncpar1->RemoveChild(tnchange1);
	pncpar2->RemoveChild(tnchange2);
	vector<int> labelsEmpty;
	pncpar1->AddChild(tnchange2, labelsEmpty);
	pncpar2->AddChild(tnchange1, labelsEmpty);

	//now order the original tree before computing the Newick
	speciesTreeCur.Order();
	speciesTreeCur.ConsNewick(nwtreetmp);

	// now attach it back
	pncpar1->RemoveChild(tnchange2);
	pncpar2->RemoveChild(tnchange1);
	pncpar1->AddChild(tnchange1, labelsEmpty);
	pncpar2->AddChild(tnchange2, labelsEmpty);
}


//////////////////////////////////////////////////////////////////////////////////
// NNI search history

const int DEF_MIN_NUM_SKIP = 5;
const double DEF_FRAC_SKIP = 0.8;

NNISearchHelp :: NNISearchHelp() : minNumDecision(DEF_MIN_NUM_SKIP), minFracSkip(DEF_FRAC_SKIP)
{
    //
}

void NNISearchHelp :: AddNNIRecord( const set<int> &origCluster, const set<int> &clusterByNNI, double logLikeliDiff )
{
#if 0
cout << "Add record: logLiklidiff:" << logLikeliDiff << ", origCluster: ";
DumpIntSet(origCluster);
cout << "  clusterByNNI: ";
DumpIntSet(clusterByNNI);
#endif
//return;
    //
    pair< set<int>, set<int>  > ss( origCluster, clusterByNNI );
    if( mapSetChangeDiffs.find(ss) == mapSetChangeDiffs.end() )
    {
        pair<int,int> pp(0,0);
        mapSetChangeDiffs.insert( map< pair< set<int>, set<int>  >, pair<int,int> > :: value_type(ss, pp) );
    }
    ++mapSetChangeDiffs[ss].first;
    // high (positive) value: not very good
    if( logLikeliDiff >= 0.0 )
    {
        //
        -- mapSetChangeDiffs[ss].second;
    }
    else
    {
        ++ mapSetChangeDiffs[ss].second;
    }
    
    // add one of those
    //if( logLikeliDiff > 0.0 )
    //{
    //    // new is better
    //    setBeatenClusters.insert( origCluster );
    //}
    //else
    //{
    //    setBeatenClusters.insert( clusterByNNI );
    //}
}

void NNISearchHelp :: AddBeatenCluster( const set<int> &clusterBeaten )
{
cout << "AddBeatenCluster: add cluster:";
DumpIntSet( clusterBeaten );
    //
    setBeatenClusters.insert(clusterBeaten);
}

bool NNISearchHelp :: CanSkip( const set<int> &origCluster, const set<int> &clusterByNNI )
{
//return false;
    //
    bool fres = false;
    
    pair< set<int>, set<int>  > ss( origCluster, clusterByNNI );
    if( mapSetChangeDiffs.find(ss) != mapSetChangeDiffs.end() )
    {
        //
        int numOccs = mapSetChangeDiffs[ss].first;
        int numDiffRes = mapSetChangeDiffs[ss].second;
//cout << "numOccs: " << numOccs << ", numDiffRes: " << numDiffRes << endl;
        if( numOccs >= this->minNumDecision && numDiffRes >= (int)( numOccs*this->minFracSkip )  )
        {
            fres = true;
        }
    }
    
    if( fres == false )
    {
        // now see whether the new cluster has been beaten before
        if( setBeatenClusters.find( clusterByNNI) != setBeatenClusters.end() )
        {
//cout << "This cluster has been beaten before: ";
//DumpIntSet(clusterByNNI);
            fres = true;
        }
    }
    
    return fres;
}

void NNISearchHelp :: Dump() const
{
    //
    cout << "NNI Search help: min number to allow skip: " << this->minNumDecision << ", min fraction of vote to skip: " << this->minFracSkip << ": \n";
    for( map< pair< set<int>, set<int>  >, pair<int,int> > :: const_iterator it = mapSetChangeDiffs.begin(); it != mapSetChangeDiffs.end(); ++it )
    {
        cout << "Clusters in original and new tree: [" << it->second.first << ", " << it->second.second << "]: ";
        DumpIntSet( it->first.first );
        DumpIntSet( it->first.second );
    }
}


//////////////////////////////////////////////////////////////////////////////////
//extern const double DEF_MIN_BRANCH_LEN;
//extern const double DEF_MAX_BRANCH_LEN;
const double DEF_MIN_BRANCH_LEN = 0.005;
const double DEF_MAX_BRANCH_LEN = 5.0;
extern double minRatioHillClimb;
bool SpeciesTreeExplorer :: fFastNgbrSearch = false;

SpeciesTreeExplorer :: SpeciesTreeExplorer( int ns, vector<PhylogenyTreeBasic *> &lgtp, const vector<int> &listMP, TaxaMapper &mapperTI ) 
: numSpecies(ns), listGeneTreePtrs(lgtp), listMultiplicity(listMP), mapperTaxaIds(mapperTI), pBLFinderLastUsed(NULL), fBrentMode(true), fOutputTreeHere(true), fOutputMoreInfo(true)
{
	curLoglikeli = MAX_NEG_DOUBLE_VAL;
	YW_ASSERT_INFO(listGeneTreePtrs.size() > 0, "Fail");

	// initialize
	minBranchLenHillClimb = DEF_MIN_BRANCH_LEN;
	maxBranchLenHillClimb = DEF_MAX_BRANCH_LEN;
	fExploreNeighorTrees = true;

	// other init
	numNewTreesExplored = 0;
}

SpeciesTreeExplorer :: ~SpeciesTreeExplorer()
{
    // nothing for now
    if(pBLFinderLastUsed != NULL)
    {
        delete pBLFinderLastUsed;
        pBLFinderLastUsed = NULL;
    }
}

void SpeciesTreeExplorer :: SetFastNgbrSearch(bool f)
{
    fFastNgbrSearch = f;
}
bool SpeciesTreeExplorer :: IsFastNgbrSearch()
{
    return fFastNgbrSearch;
}

// setup branch length range
void SpeciesTreeExplorer :: SetBranchLenRange(double minBL, double maxBL)
{
    //
    minBranchLenHillClimb = minBL;
    maxBranchLenHillClimb = maxBL;
}

// explore from a set of 
void SpeciesTreeExplorer :: ExploreFrom( const vector<string> &listNWTreesInit  )
{
#if 0
cout << "SpeciesTreeExplorer :: ExploreFrom\n";
for(int i=0; i<(int)listGeneTreePtrs.size(); ++i)
{
cout << "Gene tree: ";
string strNW;
listGeneTreePtrs[i]->ConsNewick(strNW);
cout << "gene tree: " << strNW << endl;
}
#endif
    
	// 
	for(int tr=0; tr<(int)listNWTreesInit.size(); ++tr)
	{
//cout << "SpeciesTreeExplorer: Exploring from initial tree: " << listNWTreesInit[tr] << " for index: " << tr << endl;
		double initLoglikeli = -1.0*HAP_MAX_INT;
		ExploreFromOneTree(listNWTreesInit[tr] , true, initLoglikeli);
//cout << "Done with one tree....: " << tr << endl;
	}
    string nwST = bestSpciesMargTree.GetNewick();
    //cout << "(BEFORE conversion) The newick format of the inferred MLE species tree: \n" << nwST << endl;
    string nwSTConv = mapperTaxaIds.ConvIdStringWithOrigTaxa(nwST);
    
    if( fOutputMoreInfo == true )
    {
        cout << "Highest log likelihood of tree (found at tree space exploring) = " << GetCurBestLoglikeli() << endl;
        cout << "Number of explored trees: " << numNewTreesExplored << endl;
    }
    if( fOutputTreeHere == true )
    {
        // report some statistics
        cout << "The newick format of the inferred MLE species tree: " << nwSTConv << endl;
    }
}

void SpeciesTreeExplorer :: ReInit()
{
    //
    if( this->pBLFinderLastUsed != NULL )
    {
        delete this->pBLFinderLastUsed;
        this->pBLFinderLastUsed = NULL;
    }
}

void SpeciesTreeExplorer :: SetJumpStartHelper( STBranchLenFinder *pBLFinderToSet )
{
    //
    ReInit();
    this->pBLFinderLastUsed = pBLFinderToSet;;
}

void SpeciesTreeExplorer :: ExploreFromOneTree(const string &treeNWInit, bool fEvaluateInit, double initLogLikeli)
{
	// explore the space of trees from a single starting tree
	// is this new (not explored already)?
//#if 0
	if( processedNWTrees.find( treeNWInit) != processedNWTrees.end() )
	{
		return;
	}
    
    // re-init
    ReInit();
    
//#endif
	//processedNWTrees.insert(treeNWInit);
	//numNewTreesExplored++;
//if( fEvaluateInit == true )
//{
//cout << "Exploring from an initial tree: " << treeNWInit << endl;
//}
	// construct a phylogenetic tree and explore from it
	//PhylogenyTreeBasic treeToExplore;
	//treeToExplore.ConsOnNewick( strNWTree );
    
#if 0
    // faster exploration
    if( IsFastNgbrSearch() == true )
    {
        MarginalTree mtreeCur;
        double probCurBest = EvaluateOneTree( treeNWInit, NULL, &mtreeCur );
        
        while(true)
        {
            vector< MarginalTree > listNgbrTrees;
            FindOneNNIMTreesFrom( mtreeCur, listNgbrTrees );
            MarginalTree mtreeBestStep = mtreeCur;
            bool fCont = false;
            
cout << "The current tree: " << mtreeCur.GetNewick() << " with prob " << probCurBest << endl;
            for(int i=0; i<(int)listNgbrTrees.size(); ++i)
            {
                if( listNgbrTrees[i].IsToplogicSame(mtreeCur) == true )
                {
                    continue;
                }
                MarginalTree mtreeFound;
                double probStep = EvaluateOneTree( listNgbrTrees[i].GetNewick(), &mtreeBestStep, &mtreeFound );
                //double probStep = EvaluateOneMargTreeNoBrOpt( listNgbrTrees[i] );
cout << "processing ngbr tree: " << listNgbrTrees[i].GetNewick() << ", prob=" << probStep << endl;
                if( probStep > probCurBest)
                {
cout << "******processing ngbr tree: " << listNgbrTrees[i].GetNewick() << ", prob=" << probStep << endl;

                    probCurBest = probStep;
                    mtreeBestStep = mtreeFound;
                    //mtreeBestStep = listNgbrTrees[i];
                    fCont = true;
                }
            }
            if( fCont == false )
            {
                break;
            }
            
            mtreeCur = mtreeBestStep;
            
            // optiimize its branch length
            //string strNWExp = mtreeBestStep.GetNewickNoBrLen();
            
            //if( IsTreeOptBefore(strNWExp) == true )
            //{
            //    // this has been processed before, stop
            //    break;
            //}
            
            //probCurBest = EvaluateOneTree( strNWExp, &mtreeCur );
//cout << "Latest probCurBest: " << probCurBest << endl;
        }
    }
#endif
    //else
    //{

    if( IsFastNgbrSearch() == true )
    {
        ExploreFromOneTreeSimBrTopo(treeNWInit, initLogLikeli);
    }
    else
    {
//cout << "Exploring from initial tree: " << treeNWInit << endl;
        
//#if 0
        // use NNI trees that retain the current branch lengths
        // first get an initial tree
        MarginalTree mtreeCurrent;
        bool fCurBeingTreeInit = false;
        double logLikeliCurrent = EvaluateOneTree(treeNWInit, NULL, &mtreeCurrent, fCurBeingTreeInit);
        
        // if has done before, stop
        if( fCurBeingTreeInit == false)
        {
            return;
        }
        
        // now start to explore its neighbor
        while(true)
        {
//cout << "The current tree: " << mtreeCurrent.GetNewick() << " with prob " << logLikeliCurrent << endl;
            //
            vector<MarginalTree> listNgbrTrees;
            FindOneNNIMTreesFrom( mtreeCurrent, listNgbrTrees );
            
            bool fCont = false;
            
            //STBranchLenFinder *pBLFinderLastUsedNgbr = NULL;
            
            for(int i=0; i<(int)listNgbrTrees.size(); ++i)
            {
                //STBranchLenFinder *pBLFinderLastUsedNgbrStep = NULL;
                double logLikeliNgbr = EvaluateOneTreeWithLen( listNgbrTrees[i] );
                
//cout << "--- ngbr tree: " << listNgbrTrees[i].GetNewick() << endl;
                if( NumericalAlgoUtils:: IsLikeliSignificantlyLargeThresNum( logLikeliNgbr, logLikeliCurrent, 1, log(thresMinLikelihoodIncRatioTopo) ) ==  true )
                //if( NumericalAlgoUtils:: IsLikeliSignificantlyLargeThresNum( logLikeliNgbr, logLikeliCurrent, GetNumGenetrees(), log(thresMinLikelihoodIncRatioTopo) ) ==  true )
                //if( logLikeliNgbr > logLikeliCurrent + MIN_LOGLIKELI_INC_TOPO )
                {
//cout << "************************** Prob improved by this tree to "  << logLikeliNgbr << ", current loglikeli: " << logLikeliCurrent << endl;
                    logLikeliCurrent = logLikeliNgbr;
                    mtreeCurrent = listNgbrTrees[i];
                    fCont = true;
                    
#if 0
                    if( pBLFinderLastUsedNgbr != NULL )
                    {
                        delete pBLFinderLastUsedNgbr;
                    }
                    pBLFinderLastUsedNgbr = pBLFinderLastUsedNgbrStep;
#endif
                }
                //else
                //{
                //    delete pBLFinderLastUsedNgbrStep;
                //}
            }
            
            if( fCont == false )
            {
                break;
            }
            
            // update the current jumpstart helper
            //SetJumpStartHelper( pBLFinderLastUsedNgbr );
        }
//#endif
        
        
#if 0
        // create a stack of tree/cur prob. Represent: is this tree needs to be evaluated or not (or just to explore the ngbrs);
        // the tree to explore and the current prob
        stack< pair<bool, pair<string, double> > > stackTreesToExplore;
        pair<string, double>  pp1(treeNWInit,  GetDummyWorseLoglikeli() );
        pair<bool, pair<string, double> > pp( true, pp1 );
        stackTreesToExplore.push(pp);
        //int numTaxa = -1;

        while( stackTreesToExplore.empty() == false )
        {
            //
            pair<bool, pair<string, double> > ppcur = stackTreesToExplore.top();
            stackTreesToExplore.pop();
    #if 0
    cout << "curr tree: " << ppcur.second.first << ": prob: " << ppcur.second.second << endl;
    if( ppcur.first == true )
    {
    //
    cout << "THIS INIT TREE NEEDS probability computaiton\n";
    }
    else
    {
    cout << "NO: does not need init.\n";
    }
    #endif
            double initLogLikeli = ppcur.second.second;
            MarginalTree mtreeCurBegin;
            bool fCurBeingTreeInit = false;
            
            if( ppcur.first == true)
            {
                // need to evaluate the prob
                //MarginalTree mtreeDummy;
                double probOneTree = EvaluateOneTree(ppcur.second.first, NULL, &mtreeCurBegin, fCurBeingTreeInit);
                initLogLikeli = probOneTree;
                //numTaxa = mtreeCurBegin.GetNumLeaves();
            }
            if( fCurBeingTreeInit == false )
            {
                // construct marg tree
                ReadinMarginalTreesNewickWLenString( ppcur.second.first, GetNumSpecies(), mtreeCurBegin );
            }
    //cout << "In ExploreFromOneTree: mtreeCurBegin = " << mtreeCurBegin.GetNewick() << " with initial prob: " << initLogLikeli << endl;
            mtreeCurBegin.BuildDescendantInfo();
            double likeliOrigTree = initLogLikeli;

            // done if we do not explore tree space neighbours
            if( fExploreNeighorTrees == false )
            {
    //cout << "Don't explore other trees...\n";
                break;
            }

            // now evaluate its neighbours
            // now search its neighbourhood
            string strTreeNWNext;

            PhylogenyTreeBasic treeToExplore;
            treeToExplore.ConsOnNewick( ppcur.second.first );
            // find its ngbr
            NNINgbrTreesFinder nningbrFinder( treeToExplore );
            set<string> setNgbrNWTrees;
            nningbrFinder.Find( setNgbrNWTrees );
    //cout << "Size of ngbr trees: " << setNgbrNWTrees.size() << endl;
    //int treeIndex = 0;
            for( set<string> :: iterator itt= setNgbrNWTrees.begin(); itt != setNgbrNWTrees.end(); ++itt )
            {
//cout << ":--- ngbr tree: " << *itt << endl;
                //stackCandidateTrees.push(*itt);
                MarginalTree mtreeNgbr;
                bool fOptTreeFound = false;
                double probNgbrTr = EvaluateOneTree(*itt, &mtreeCurBegin, &mtreeNgbr, fOptTreeFound);
                
                // now analyze the result if there are work done
                if( fOptTreeFound == true )
                {
                    AnalyzeNNIRes( mtreeCurBegin, mtreeNgbr, likeliOrigTree, probNgbrTr );
                }
                
                if( probNgbrTr   > initLogLikeli + MIN_LOGLIKELI_INC_TOPO)
                {
//cout << "--- ngbr tree: " << *itt << endl;
//cout << "************************** Prob improved by this tree to " << probNgbrTr << endl;
                    initLogLikeli = probNgbrTr;
                    strTreeNWNext = *itt;
                    
                    // now the tree is beaten
                    if( fOptTreeFound == true )
                    {
                        AnalyzeBeanTrees( mtreeCurBegin, mtreeNgbr );
                    }
                }
            }

            // continue if we find another good choice
            if( strTreeNWNext.length() > 0 )
            {
                //
                //ExploreFromOneTree( strTreeNWNext, false, initLogLikeli );
                pair<string, double>  pp2(strTreeNWNext,  initLogLikeli );
                bool fRecompute = false;
                // always recompute the probablity if it is approx mode
                //if( IsApproxLikelihood() == true )
                //{
                //    fRecompute = true;
                //}
                pair<bool, pair<string, double> > pp3( fRecompute, pp2 );
                stackTreesToExplore.push(pp3);
            }	
        }
#if 0
        // save a record that the optimal tree is found
        pair<double,MarginalTree> pp2( GetCurBestLoglikeli(), this->bestSpciesMargTree );
        processedNWTrees.insert( map<string, pair<double,MarginalTree> > :: value_type( treeNWInit, pp2) );
#endif
        
#endif
    }
    

//   }
//cout << "Finishing exploration from tree: " << treeNWInit << endl;
}

void SpeciesTreeExplorer :: AnalyzeNNIRes( const MarginalTree &mtreeOrig, const MarginalTree &mtreeNNI, double logLikeliOrig, double logLikeliNNI )
{
    // YW: don't do this yet
    return;
//cout << "AnalyzeNNIRes: treeorig: " << mtreeOrig.GetNewick() << ", treeNNI: " << mtreeNNI.GetNewick() << endl;
    //
    double logLikeliDiff = logLikeliNNI - logLikeliOrig;
    set<int> setClusOnlyInNew, setClusOnlyInOrig;
    mtreeNNI.FindDiffSubtreesFrom( mtreeOrig, setClusOnlyInNew, setClusOnlyInOrig );
#if 0
cout << "setClusOnlyInOrig: ";
DumpIntSet( setClusOnlyInOrig );
cout << "setClusOnlyInNew: ";
DumpIntSet( setClusOnlyInNew );
#endif
    YW_ASSERT_INFO( setClusOnlyInOrig.size() == 1, "Wrong1" );
    YW_ASSERT_INFO( setClusOnlyInNew.size() == 1, "Wrong2" );
    vector< set<int> > listSubtreesRef;
    mtreeOrig.ConsDecedentLeavesInfoLabels( listSubtreesRef );
    vector< set<int> > listSubtreesNNI;
    mtreeNNI.ConsDecedentLeavesInfoLabels( listSubtreesNNI );
    this->helperNNISearch.AddNNIRecord( listSubtreesRef[ *setClusOnlyInOrig.begin() ], listSubtreesNNI[ *setClusOnlyInNew.begin() ], logLikeliDiff );
    
//cout << "After analyzing: helper: ";
//this->helperNNISearch.Dump();
}

void SpeciesTreeExplorer :: AnalyzeBeanTrees( const MarginalTree &mtreeOrig, const MarginalTree &mtreeNNI)
{
//cout << "AnalyzeBeanTrees: treeorig: " << mtreeOrig.GetNewick() << ", treeNNI: " << mtreeNNI.GetNewick() << endl;
return;
    //
    set<int> setClusOnlyInNew, setClusOnlyInOrig;
    mtreeNNI.FindDiffSubtreesFrom( mtreeOrig, setClusOnlyInNew, setClusOnlyInOrig );
//#if 0
    cout << "setClusOnlyInOrig: ";
    DumpIntSet( setClusOnlyInOrig );
    cout << "setClusOnlyInNew: ";
    DumpIntSet( setClusOnlyInNew );
//#endif
    YW_ASSERT_INFO( setClusOnlyInOrig.size() == 1, "Wrong1" );
    YW_ASSERT_INFO( setClusOnlyInNew.size() == 1, "Wrong2" );
    vector< set<int> > listSubtreesRef;
    mtreeOrig.ConsDecedentLeavesInfoLabels( listSubtreesRef );
cout << "listSubtreesRef: ";
for(int i=0; i<(int)listSubtreesRef.size(); ++i)
{
DumpIntSet( listSubtreesRef[i] );
}
    //vector< set<int> > listSubtreesNNI;
    //mtreeNNI.ConsDecedentLeavesInfoLabels( listSubtreesNNI );
    this->helperNNISearch.AddBeatenCluster( listSubtreesRef[ *setClusOnlyInOrig.begin() ]  );
}

bool SpeciesTreeExplorer :: CanSkip(const MarginalTree &mtreeOrig, const MarginalTree &mtreeNNI)
{
    // for now, don't skp
    return false;
//cout << "CanSkip: "  << "treeNNI: " << mtreeNNI.GetNewick() << endl << ", treeOrig:" << mtreeOrig.GetNewick() << endl;
    //
    set<int> setClusOnlyInNew, setClusOnlyInOrig;
    mtreeNNI.FindDiffSubtreesFrom( mtreeOrig, setClusOnlyInNew, setClusOnlyInOrig );
    YW_ASSERT_INFO( setClusOnlyInOrig.size() == 1, "Wrong3" );
    YW_ASSERT_INFO( setClusOnlyInNew.size() == 1, "Wrong4" );
    vector< set<int> > listSubtreesRef;
    mtreeOrig.ConsDecedentLeavesInfoLabels( listSubtreesRef );
    vector< set<int> > listSubtreesNNI;
    mtreeNNI.ConsDecedentLeavesInfoLabels( listSubtreesNNI );
#if 0
cout << "listSubtreesRef: ";
for(int i=0; i<(int)listSubtreesRef.size(); ++i)
{
DumpIntSet( listSubtreesRef[i] );
}
cout << "listSubtreesNNI: ";
for(int i=0; i<(int)listSubtreesNNI.size(); ++i)
{
DumpIntSet( listSubtreesNNI[i] );
}
cout << "setClusOnlyInOrig: ";
DumpIntSet( setClusOnlyInOrig );
cout << "setClusOnlyInNew: ";
DumpIntSet( setClusOnlyInNew );
#endif
    return this->helperNNISearch.CanSkip( listSubtreesRef[ *setClusOnlyInOrig.begin() ], listSubtreesNNI[ *setClusOnlyInNew.begin() ] );
}

double SpeciesTreeExplorer :: EvaluateOneMargTreeNoBrOpt(MarginalTree &mtree)
{
    // create prob components
    vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
    PreCreateListGTPComp(mtree, listGeneTreePtrs, listGSTProbFinder);
    //#endif
    
	STBranchLenFinder blFinder(listGeneTreePtrs, mtree, minBranchLenHillClimb, maxBranchLenHillClimb );
    //#if 0
    blFinder.SetGeneTreeProbComp( listGSTProbFinder );
    //#endif
	//blFinder.SetBrentMode( fBrentMode);
	blFinder.SetMultiplictyofTrees(listMultiplicity);
	// inform branch tree finder the current best likelihood,
	// which may help to determine whether it is profitable to do more
	//blFinder.SetKnownMaxLikeli(curLoglikeli);
    
    double probval = blFinder.CalcLogProb();
    
	return probval;
}

bool SpeciesTreeExplorer :: IsTreeOptBefore(const string &strNW)
{
    //
    return processedNWTrees.find(strNW) != processedNWTrees.end();
}


double SpeciesTreeExplorer :: EvaluateOneTree(const string &treeNW, const MarginalTree *ptreeOptCur, MarginalTree *ptreeOpt, bool &fOptFound)
{
//cout << "EvaluateOneTree: treeNW:" << treeNW << endl;
    fOptFound = false;
    
	//
	MarginalTree treePH1WLen;
	ReadinMarginalTreesNewickWLenString( treeNW, GetNumSpecies(), treePH1WLen );
    treePH1WLen.BuildDescendantInfo();
	//heuSTSampler.SampleBU(mTree);
	//MarginalTree treePH1WLen = mTree;
    
    string strTreeNW2 = treePH1WLen.GetNewickNoBrLen2();
	if( processedNWTrees.find( strTreeNW2 ) != processedNWTrees.end() )
	//if( processedNWTrees.find( treeNW  ) != processedNWTrees.end() )
	{
		// simple just return a smaller value
		//return GetDummyWorseLoglikeli();
        // just use the same tree
        
		return processedNWTrees[strTreeNW2].first;
	}
//cout << "EvaluateOneTree: treeNW:" << strTreeNW2 << endl;
	//processedNWTrees.insert(treeNW);
	numNewTreesExplored++;
//cout << "Exploring a new tree (in neighbourhood search): " << treeNW << endl;


    
    // can we skip this tree?
    if( ptreeOptCur != NULL && CanSkip( *ptreeOptCur, treePH1WLen ) == true )
    {
//cout << "***** This tree is skipped: " << treePH1WLen.GetNewick() << endl;
        
        // use the same tree
        // return a very small number
        return MAX_NEG_DOUBLE_VAL;
    }
    
    
	// init branch length of every edge to be 1.0
	const double DEFAULT_BRANCH_LEN = 1.0;
	for( int b=0; b<treePH1WLen.GetTotNodesNum()-1; ++b )
	{
		treePH1WLen.SetBranchLen(b, DEFAULT_BRANCH_LEN);
	}
    
//#if 0
    // create prob components
    vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
    PreCreateListGTPComp(treePH1WLen, listGeneTreePtrs, listGSTProbFinder);
//#endif
    
    // find the
    //set<int> setBrToExp, setBrClusDstroyed;
    //if( ptreeOptCur != NULL )
    //{
    //
    //treePH1WLen.FindDiffSubtreesFrom( *ptreeOptCur, setBrToExp, setBrClusDstroyed );
    //}
    //else
    //{
    // explore all edges
    //PopulateSetWithInterval( setBrToExp, 0, treePH1WLen.GetTotNodesNum()-1 );
    //}
#if 0
cout << "In exploring tree: " << treePH1WLen.GetNewick() << " and previously known tree is: ";
if( ptreeOptCur != NULL )
{
cout << ptreeOptCur->GetNewick() << " ";
}
else
{
cout << " N/A ";
}
DumpIntSet( setBrToExp );
#endif
	STBranchLenFinder *pblFinder = new STBranchLenFinder(listGeneTreePtrs, treePH1WLen, minBranchLenHillClimb, maxBranchLenHillClimb );
//#if 0
    pblFinder->SetGeneTreeProbComp( listGSTProbFinder );
//#endif
    //blFinder.SetBranchesToExp( setBrToExp );
	pblFinder->SetBrentMode( fBrentMode);
	pblFinder->SetMultiplictyofTrees(listMultiplicity);
	// inform branch tree finder the current best likelihood, 
	// which may help to determine whether it is profitable to do more
	pblFinder->SetKnownMaxLikeli(curLoglikeli);
    
#if 0
    // in approximate mode set the branch length optimizaton to be 1
    if( IsApproxLikelihood() == true )
    {
        pblFinder->SetMaxOptRounds(1);
    }
#endif

//#if 0
	if( minRatioHillClimb > 0.0 )
	{
		pblFinder->SetHillClimbRatioThres(minRatioHillClimb);
	}
    
    // use previous blfinder to quick start
    pblFinder->PreHillClimbBranchLenSearch();
    
#if 0
    if( this->pBLFinderLastUsed != NULL)
    {
        pblFinder->JumpStartBy(this->pBLFinderLastUsed);
        delete this->pBLFinderLastUsed;
    }
    this->pBLFinderLastUsed = pblFinder;
#endif
    
//#endif
	MarginalTree streeBLen;
	double probval = pblFinder->HillClimbBranchLen(streeBLen);
    //streeBLen.SortByLeafId();
    streeBLen.BuildDescendantInfo();
//cout << "Best branch length finder gives: " << probval << endl;
//cout << "The resulting tree: ";
//streeBLen.Dump();
	//string nwST = streeBLen.GetNewick();
	//cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;

	//if( t == 1 )
	//{
	//	mleTreeSearchProb = probval;
	//	mTreeMLE = streeBLen;
	//	lvOptRes = lv;
//cout << "Max prob. updated to " << probval << endl;
	//}
	if( curLoglikeli < probval )
	{
		curLoglikeli = probval;
		bestSpciesMargTree = streeBLen;
//cout << "Max log-likelihood updated to " << probval << endl;
	}
    YW_ASSERT_INFO(ptreeOpt != NULL, "Cannot be null");
    *ptreeOpt = streeBLen;
    fOptFound = true;
	// remember it
    string streeBLenNo = streeBLen.GetNewickNoBrLen2();
	pair<double,MarginalTree> tt(probval,streeBLen);
	processedNWTrees.insert(map<string,pair<double,MarginalTree> > :: value_type(streeBLenNo, tt) );
//cout << "EvaluateOneTree: resuting prob: " << probval << endl;
	return probval;
}

static int QSortCompareDoubleIntPair( const void *arg1, const void *arg2 )
{
   /* Compare all of both strings: */
    // assume sorting in accending order, and use the first value in the int pair to sort
    double n1 = ((pair<double,int> *) arg1)->first;
    double n2 = ((pair<double,int> *) arg2)->first;
//cout <<"arg1 = " << n1 << ", arg2 = " << n2 << endl;
    if( n1 > n2)
    {
        return 1;
    }
    else if( n1 < n2)
    {
        return -1;
    }
    else 
    {
        return 0;
    }
}

void SpeciesTreeExplorer :: OutputNearOptTrees(string fileNameInit)
{
	// output near optimal trees
	string fileNameUse = fileNameInit + "-nearopt.trees";

	// find a list of near opt trees For this, iterate through the list of trees
	vector< pair<string, double> > listProcTreesProb;
	for( map<string,pair<double,MarginalTree> > :: iterator itt = processedNWTrees.begin(); itt != processedNWTrees.end(); ++itt )
	{
		pair<string,double> pp;
		pp.first = itt->second.second.GetNewick();
		pp.second = itt->second.first;
		listProcTreesProb.push_back( pp );
	}
	// create a vector for sorting
	pair<double,int> *parraySortTreeIndProb = new pair<double,int>[listProcTreesProb.size()];
	for(int t=0; t<(int)listProcTreesProb.size(); ++t)
	{
		parraySortTreeIndProb[t].first = listProcTreesProb[t].second;
		parraySortTreeIndProb[t].second = t;
	}
    qsort( (void *)parraySortTreeIndProb, listProcTreesProb.size(), sizeof( pair<double,int>  ), QSortCompareDoubleIntPair );

	// now output these trees from the end
	ofstream outFileProbs( fileNameUse.c_str() );
	if(!outFileProbs)
	{
		cout << "Can not open near optimal output file: "<< fileNameUse <<endl;
		exit(1);
	}

	int numTreeOut = 0;
	for(int t=(int)listProcTreesProb.size()-1; t>=0 && numTreeOut < numNearOptTreesKept; t--)
	{
		//
		numTreeOut ++;
		outFileProbs << "[" << listProcTreesProb[ parraySortTreeIndProb[t].second ].second << "]";
		string strTr = mapperTaxaIds.ConvIdStringWithOrigTaxa(listProcTreesProb[ parraySortTreeIndProb[t].second ].first);
		outFileProbs << strTr << ";\n";
	}
    delete [] parraySortTreeIndProb;

	outFileProbs.close();
}

string SpeciesTreeExplorer :: GetBestInfSpeicesTree() const
{
    //
    return bestSpciesMargTree.GetNewick();
}

string SpeciesTreeExplorer :: GetBestInfSpeicesTreeConv() const
{
    // get tree w/ converted back
    string nwST = bestSpciesMargTree.GetNewick();
    //cout << "(BEFORE conversion) The newick format of the inferred MLE species tree: \n" << nwST << endl;
    return mapperTaxaIds.ConvIdStringWithOrigTaxa(nwST);
}

void SpeciesTreeExplorer :: GetBestInfSpeicesMargTreeConv( MarginalTree &treeInf ) const
{
    treeInf = bestSpciesMargTree;
    RemapMargTree( treeInf, mapperTaxaIds );
}

void SpeciesTreeExplorer :: PreCreateListGTPComp( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder )
{
    // YW: 11/30/15: there is a bug somewhere that makes the multithread version of init code invalid; may need to come back to this later. TBD
#if 0
    if( GetNumThreads() > 1 )
    {
        PreCreateListGTPCompMultithread( treeSpec, listGeneTreePtrs, listGSTProbFinder );
        return;
    }
#endif
    // take simple approach for now
    for( int tr=0; tr<(int)listGeneTreePtrs.size(); ++tr )
    {
        //
        GenericGeneSpeciesTreeProb *ptr = CreateGeneTreeProbComp(treeSpec, *(listGeneTreePtrs[tr]));
        listGSTProbFinder.push_back(ptr);
    }
}

typedef struct
{
    vector<PhylogenyTreeBasic *>listPtrGenetrees;
    int trStart;
    int trEnd;
    MarginalTree *ptrSpecTree;
    vector<GenericGeneSpeciesTreeProb *> listResProbComps;
} STProbInitThreadInfo;

static void *ThreadFuncProbInit(void *ptr)
{
    //
    STProbInitThreadInfo *ptinfo = (STProbInitThreadInfo *)ptr;
//cout << "Init with a thread: [" << ptinfo->trStart << "," << ptinfo->trEnd << "]\n";
    for(int tr=ptinfo->trStart; tr<=ptinfo->trEnd; ++tr)
    {
        GenericGeneSpeciesTreeProb *ptr = CreateGeneTreeProbComp(*ptinfo->ptrSpecTree, *ptinfo->listPtrGenetrees[tr]);
        ptinfo->listResProbComps.push_back( ptr );
    }
    return NULL;
}

void SpeciesTreeExplorer :: PreCreateListGTPCompMultithread( MarginalTree &treeSpec, vector<PhylogenyTreeBasic *> &listGeneTreePtrs, vector<GenericGeneSpeciesTreeProb *> &listGSTProbFinder )
{
    // create multiple threads for faster initialization
    
    // create all the thread for processing the trees by spliting the tasks evenly
    // init threads
    int numThreadsUse = GetNumThreads();
    // if not that many trees, reduce it
    if( numThreadsUse > (int) listGeneTreePtrs.size() )
    {
        //
        numThreadsUse = (int)listGeneTreePtrs.size();
    }
    
    pthread_t* pid = new pthread_t[numThreadsUse];
    STProbInitThreadInfo *pThreadInfo = new STProbInitThreadInfo[numThreadsUse];
    
    // start the threads
    int numTreesPerThread = (int)listGeneTreePtrs.size()/numThreadsUse;
    YW_ASSERT_INFO(numTreesPerThread>=1, "Must have at least one tree to process");
    int numLeftOver = (int)listGeneTreePtrs.size() - numThreadsUse * numTreesPerThread ;
    YW_ASSERT_INFO( numLeftOver >= 0, "Must be non-negative");
    int trCurToProc = 0;
    for(int i=0;i<numThreadsUse;++i)
    {
//cout << "Starting thread " << i << endl;
        // wait for all threads finishing
        pThreadInfo[i].trStart = trCurToProc;
        pThreadInfo[i].trEnd = trCurToProc + numTreesPerThread-1;
        trCurToProc += numTreesPerThread;
        // if there is leftover to do, add one more
        if( numLeftOver > 0 )
        {
            // add one more
            ++pThreadInfo[i].trEnd;
            ++trCurToProc;
            --numLeftOver;
        }
        pThreadInfo[i].listPtrGenetrees = listGeneTreePtrs;
        pThreadInfo[i].ptrSpecTree = &treeSpec;
        
        // start thread
        int ret = pthread_create(&pid[i], NULL, &ThreadFuncProbInit, (void *)&pThreadInfo[i]);
        if(ret)
        {
            cout << "Fatal error in creating pthread!" << endl;
            exit(1 );
        }
    }
    
    // free up resource
    for(int i=0;i<numThreadsUse;++i)
    {
        //wait for all threads finishing
        pthread_join(pid[i], NULL);
    }
    delete [] pid;
//cout << "Init finished.\n";;
    // collect results
    for( int i = 0; i<numThreadsUse; ++i )
    {
        for( int jj=0; jj<(int)pThreadInfo[i].listResProbComps.size(); ++jj)
        {
            listGSTProbFinder.push_back( pThreadInfo[i].listResProbComps[jj] );
        }
    }
    delete [] pThreadInfo;
}

double SpeciesTreeExplorer :: EvaluateOneTreeWithLen( MarginalTree &treeCurr)
//, STBranchLenFinder **ppSTOpt)
{
    // evaluate one tree (by using the current branch lengths)
    string treeNW = treeCurr.GetNewickNoBrLen2();
    
    //*ppSTOpt = NULL;
    
    if( processedNWTrees.find( treeNW) != processedNWTrees.end() )
	{
		// simple just return a smaller value
		//return GetDummyWorseLoglikeli();
        // just use the same tree
        
		return processedNWTrees[treeNW].first;
	}
//cout << "EvlautewithLen: treeNW: " << treeNW << endl;
	//processedNWTrees.insert(treeNW);
	numNewTreesExplored++;
    
    // YW: 05/19/16: do we have to do this? TBD
    //treeCurr.BuildDescendantInfo();
    //cout << "Exploring a new tree (in neighbourhood search): " << treeNW << endl;
    
    //#if 0
    // create prob components
    vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
    PreCreateListGTPComp(treeCurr, listGeneTreePtrs, listGSTProbFinder);
    //#endif
    
    // find the
    //set<int> setBrToExp, setBrClusDstroyed;
    //if( ptreeOptCur != NULL )
    //{
    //
    //treePH1WLen.FindDiffSubtreesFrom( *ptreeOptCur, setBrToExp, setBrClusDstroyed );
    //}
    //else
    //{
    // explore all edges
    //PopulateSetWithInterval( setBrToExp, 0, treePH1WLen.GetTotNodesNum()-1 );
    //}
#if 0
    cout << "In exploring tree: " << treeCurr.GetNewick() << " and previously known tree is: ";
#endif
	STBranchLenFinder *pblFinder = new STBranchLenFinder(listGeneTreePtrs, treeCurr, minBranchLenHillClimb, maxBranchLenHillClimb );
    //#if 0
    pblFinder->SetGeneTreeProbComp( listGSTProbFinder );
    //#endif
    //blFinder.SetBranchesToExp( setBrToExp );
	pblFinder->SetBrentMode( fBrentMode);
	pblFinder->SetMultiplictyofTrees(listMultiplicity);
	// inform branch tree finder the current best likelihood,
	// which may help to determine whether it is profitable to do more
	pblFinder->SetKnownMaxLikeli(curLoglikeli);
    
    //#if 0
	if( minRatioHillClimb > 0.0 )
	{
		pblFinder->SetHillClimbRatioThres(minRatioHillClimb);
	}
    //#endif
    pblFinder->PreHillClimbBranchLenSearch();
    if( this->pBLFinderLastUsed != NULL)
    {
        // don't replace
        pblFinder->JumpStartBy(this->pBLFinderLastUsed);
    }
    
	MarginalTree streeBLen;
	double probval = pblFinder->HillClimbBranchLen(streeBLen);
    streeBLen.SortByLeafId();
    streeBLen.BuildDescendantInfo();
    //cout << "Best branch length finder gives: " << probval << endl;
    //cout << "The resulting tree: ";
    //streeBLen.Dump();
	//string nwST = streeBLen.GetNewick();
	//cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;
    
	//if( t == 1 )
	//{
	//	mleTreeSearchProb = probval;
	//	mTreeMLE = streeBLen;
	//	lvOptRes = lv;
    //cout << "Max prob. updated to " << probval << endl;
	//}
	if( curLoglikeli < probval )
	{
		curLoglikeli = probval;
		bestSpciesMargTree = streeBLen;
        //cout << "Max log-likelihood updated to " << probval << endl;
	}
    
    // set the updated tree
    treeCurr = streeBLen;
    
	// remember it
	pair<double,MarginalTree> tt(probval,streeBLen);
    string stTreeNoBrLen = streeBLen.GetNewickNoBrLen2();
	processedNWTrees.insert(map<string,pair<double,MarginalTree> > :: value_type(stTreeNoBrLen, tt) );
    
    // free
    //*ppSTOpt = pblFinder;
    delete pblFinder;
    
    //cout << "EvaluateOneTree: resuting prob: " << probval << endl;
	return probval;
}

double SpeciesTreeExplorer :: EvaluateOneMargTreeSubsetBrOpt(MarginalTree &mtree, const set<int> &setBrToOpt)
{
//cout << "Optimizing branchs: ";
//DumpIntSet(setBrToOpt);
    //
    // evaluate one tree (by using the current branch lengths)
    string treeNW = mtree.GetNewickNoBrLen2();
    if( processedNWTrees.find( treeNW) != processedNWTrees.end() )
	{
		// simple just return a smaller value
		//return GetDummyWorseLoglikeli();
        // just use the same tree
        
		return processedNWTrees[treeNW].first;
	}
	//processedNWTrees.insert(treeNW);
	numNewTreesExplored++;
    //cout << "Exploring a new tree (in neighbourhood search): " << treeNW << endl;
    
    //#if 0
    // create prob components
    vector<GenericGeneSpeciesTreeProb *> listGSTProbFinder;
    PreCreateListGTPComp(mtree, listGeneTreePtrs, listGSTProbFinder);
    //#endif

#if 0
    cout << "In exploring tree: " << treeCurr.GetNewick() << " and previously known tree is: ";
#endif
	STBranchLenFinder blFinder(listGeneTreePtrs, mtree, minBranchLenHillClimb, maxBranchLenHillClimb );
    //#if 0
    blFinder.SetGeneTreeProbComp( listGSTProbFinder );
    //#endif
    blFinder.SetBranchesToExp( setBrToOpt );
	blFinder.SetBrentMode( fBrentMode);
	blFinder.SetMultiplictyofTrees(listMultiplicity);
	// inform branch tree finder the current best likelihood,
	// which may help to determine whether it is profitable to do more
	blFinder.SetKnownMaxLikeli(curLoglikeli);
    
    //#if 0
	if( minRatioHillClimb > 0.0 )
	{
		blFinder.SetHillClimbRatioThres(minRatioHillClimb);
	}
    //#endif
    blFinder.PreHillClimbBranchLenSearch();
    
	MarginalTree streeBLen;
	double probval = blFinder.HillClimbBranchLen(streeBLen);
    streeBLen.SortByLeafId();
    streeBLen.BuildDescendantInfo();
    //cout << "Best branch length finder gives: " << probval << endl;
    //cout << "The resulting tree: ";
    //streeBLen.Dump();
	//string nwST = streeBLen.GetNewick();
	//cout << "The newick format of the inferred species tree with branch length: " << nwST << endl;
    
	if( curLoglikeli < probval )
	{
		curLoglikeli = probval;
		bestSpciesMargTree = streeBLen;
        //cout << "Max log-likelihood updated to " << probval << endl;
	}
    
    // set the updated tree
    mtree = streeBLen;
    
	// remember it
	pair<double,MarginalTree> tt(probval,streeBLen);
	processedNWTrees.insert(map<string,pair<double,MarginalTree> > :: value_type(treeNW, tt) );
    //cout << "EvaluateOneTree: resuting prob: " << probval << endl;
	return probval;
}

// new test code: simulationiously update topology/branch length
void SpeciesTreeExplorer :: ExploreFromOneTreeSimBrTopo( const string &treeNWInit, double initLogLikeli )
{
    // first obtain a initila marg tree (w/ branch optimized)
    MarginalTree mtreeCurBeingOpt;

    // need to evaluate the prob
    //MarginalTree mtreeDummy;
    bool fCurBeingTreeInit = true;
    double logLikeliCurr = EvaluateOneTree(treeNWInit, NULL, &mtreeCurBeingOpt, fCurBeingTreeInit);

    // nothing to be done if it is has already been processed
    if( fCurBeingTreeInit == false)
    {
        return;
    }
//cout << "Initial tree: " << mtreeCurBeingOpt.GetNewick() << ": lileihood: " << logLikeliCurr << endl;
    //
    while(true)
    {
        // find all possible
        map<double, set< pair<int,int> > > mapSetPairEdgesToSwap;
        FindAllGoodEdgePairsToSwap( mtreeCurBeingOpt, logLikeliCurr, mapSetPairEdgesToSwap );
        
        // stop if nothing is found
        if( mapSetPairEdgesToSwap.size() == 0 )
        {
            break;
        }
        
        // apply these changes
        ApplyGoodEdgePairsSwap( mtreeCurBeingOpt, mapSetPairEdgesToSwap );
        
        // re-optimize branch lengths
        //STBranchLenFinder *pSTOpt = NULL;
        double logLikeliChanged = EvaluateOneTreeWithLen( mtreeCurBeingOpt );
        // don't use this
        //if( pSTOpt != NULL )
        //{
        //    delete pSTOpt;
        //}
        
//cout << "After one round of optimizaiton: " << mtreeCurBeingOpt.GetNewick() << ": lileihood: " << logLikeliChanged << endl;
        
        if( NumericalAlgoUtils:: IsLikeliSignificantlyLargeThresNum( logLikeliChanged, logLikeliCurr, 1, log(thresMinLikelihoodIncRatioTopo) ) == false )
        //if( NumericalAlgoUtils:: IsLikeliSignificantlyLargeThresNum( logLikeliChanged, logLikeliCurr, GetNumGenetrees(), log(thresMinLikelihoodIncRatioTopo) ) == false )
        //if( logLikeliChanged <= logLikeliCurr + MIN_LOGLIKELI_INC_TOPO  )
        {
            // stop if not much change
            break;
        }
        
        logLikeliCurr = logLikeliChanged;
        
        // also terminate if after one round of search, the likelihood is worse than the current best
        if( logLikeliCurr < GetCurBestLoglikeli() )
        {
//cout << "Early terminate: no need to continue optimization this initial tree.\n";
            break;
        }
    }
    
    // do one more round of exploration from the current one
    //ExploreFromOneTree( mtreeCurBeingOpt.GetNewick(), false, logLikeliCurr );

}

// find all good edge pairs to swap
void SpeciesTreeExplorer :: FindAllGoodEdgePairsToSwap( MarginalTree &mtreeCur, double loglikeliCur, map<double, set< pair<int,int> > > &  mapSetPairEdgesToSwap )
{
    const double MIN_LIKELIHOOD_INC_RATIO_QUICK = log( 1.05);
    
    vector< MarginalTree > listNgbrTrees;
    vector<pair<int,int> > listPairEdgesSwapped;
    FindOneNNIMTreesFrom( mtreeCur, listNgbrTrees, &listPairEdgesSwapped );
    
    //cout << "The ngbr trees from current tree: " << mtreeCur.GetNewick() << " with prob " << probCurBest << endl;
    for(int i=0; i<(int)listNgbrTrees.size(); ++i)
    {
        if( listNgbrTrees[i].IsToplogicSame(mtreeCur) == true )
        {
            continue;
        }
        // only opt branch length for the two involved branch lengths
        set<int> setBrsToOpt;
        setBrsToOpt.insert( listPairEdgesSwapped[i].first );
        setBrsToOpt.insert( listPairEdgesSwapped[i].second );
        int parBr1 = mtreeCur.GetParent(listPairEdgesSwapped[i].first);
        if(parBr1 >= 0 )
        {
            setBrsToOpt.insert( parBr1 );
        }
        int parBr2 = mtreeCur.GetParent(listPairEdgesSwapped[i].second);
        if(parBr2 >= 0 )
        {
            setBrsToOpt.insert( parBr2 );
        }
        
        //MarginalTree mtreeFound;
        //bool fOptFound = false;
        //double probStep = EvaluateOneTree( listNgbrTrees[i].GetNewick(), NULL, &mtreeFound, fOptFound );
        double probStep = EvaluateOneMargTreeSubsetBrOpt( listNgbrTrees[i], setBrsToOpt );
        //double probStep = EvaluateOneMargTreeNoBrOpt( listNgbrTrees[i] );
        //cout << "processing ngbr tree: " << listNgbrTrees[i].GetNewick() << ", prob=" << probStep << endl;
        if( probStep > loglikeliCur)
        {
            //cout << "******processing ngbr tree: " << listNgbrTrees[i].GetNewick() << ", prob=" << probStep << endl;
            
            // find out which two routes
            pair<int,int> pp = listPairEdgesSwapped[i];
            double probInc = probStep-loglikeliCur;
            
            if( probInc < MIN_LIKELIHOOD_INC_RATIO_QUICK )
            {
                continue;
            }
            if( mapSetPairEdgesToSwap.find(probInc) == mapSetPairEdgesToSwap.end() )
            {
                set< pair<int,int> > ss;
                mapSetPairEdgesToSwap.insert( map<double, set< pair<int,int> > > :: value_type(probInc, ss) );
            }
            mapSetPairEdgesToSwap[probInc].insert( pp );
        }
    }
    
    // if the prob difference is not large, then should do a more thorough search
    //double probIncMax = mapSetPairEdgesToSwap.rbegin()->first;
#if 0
    if( mapSetPairEdgesToSwap.size() == 0 )
    {
        //cout << "The ngbr trees from current tree: " << mtreeCur.GetNewick() << " with prob " << probCurBest << endl;
        for(int i=0; i<(int)listNgbrTrees.size(); ++i)
        {
            if( listNgbrTrees[i].IsToplogicSame(mtreeCur) == true )
            {
                continue;
            }
            MarginalTree mtreeFound;
            bool fOptFound = false;
            double probStep = EvaluateOneTree( listNgbrTrees[i].GetNewick(), NULL, &mtreeFound, fOptFound );
            //double probStep = EvaluateOneMargTreeNoBrOpt( listNgbrTrees[i] );
            //cout << "processing ngbr tree: " << listNgbrTrees[i].GetNewick() << ", prob=" << probStep << endl;
            if( probStep > loglikeliCur)
            {
                //cout << "******processing ngbr tree: " << listNgbrTrees[i].GetNewick() << ", prob=" << probStep << endl;
                
                // find out which two routes
                pair<int,int> pp = listPairEdgesSwapped[i];
                double probInc = probStep-loglikeliCur;
                if( mapSetPairEdgesToSwap.find(probInc) == mapSetPairEdgesToSwap.end() )
                {
                    set< pair<int,int> > ss;
                    mapSetPairEdgesToSwap.insert( map<double, set< pair<int,int> > > :: value_type(probInc, ss) );
                }
                mapSetPairEdgesToSwap[probInc].insert( pp );
            }
        }
    }
#endif
}

// apply these changes
void SpeciesTreeExplorer :: ApplyGoodEdgePairsSwap( MarginalTree &mtreeCurBeingOpt, const map<double, set< pair<int,int> > > & mapSetPairEdgesToSwap )
{
//cout << "ApplyGoodEdgePairsSwap: current tree: " << mtreeCurBeingOpt.GetNewick() << ", dump: ";
//mtreeCurBeingOpt.Dump();
    // simply apply all non-conflicted from high increment of likelihood to low
    set<int> setChangedEdges;
    for( map<double, set< pair<int,int> > > :: const_reverse_iterator it = mapSetPairEdgesToSwap.rbegin(); it != mapSetPairEdgesToSwap.rend(); ++it )
    {
        //
        for( set< pair<int,int> > :: const_iterator itg = it->second.begin(); itg !=it->second.end(); ++itg  )
        {
            //
            if( setChangedEdges.find(itg->first) != setChangedEdges.end() || setChangedEdges.find(itg->second) != setChangedEdges.end() )
            {
                continue;
            }
//cout << "Swapping: " << itg->first << ", " << itg->second << endl;
            // swap the two edges
            mtreeCurBeingOpt.SwapBranches( itg->first, itg->second );
            
            // for now, only do one round
            break;
        }
        break;
    }
//cout << "After rearaagenment: tree is: ";
//mtreeCurBeingOpt.Dump();
    mtreeCurBeingOpt.RearrangeParIncOrder();
    mtreeCurBeingOpt.BuildDescendantInfo();
//cout << "Done with good swap.\n";
}




//////////////////////////////////////////////////////////////////////////////////
// Utilities

void ConsInitTreesFromInputTrees( vector<PhylogenyTreeBasic *> &listGeneTreePtrs, const vector<int> &listMultiplicity, TaxaMapper &mapperTaxaIds, vector<string> &vecNWParsTrees, bool fVerbose, int numMDCLevels, bool fMDCMoreClades, int maxNumMDCMoreClades, int numTreeSamples, bool &fDiffTaxaInGTrees )
{
    // in: list of gene tree pointers
    // out: list of seed tree (in Newick)
    if( AreGeneTreesWithSameTaxa( listGeneTreePtrs ) == true )
    {
        // use MDC to find seed tree if all gene trees have same set of taxa
        
        // by default, we use MDC
        // Use MDC to find a list of candidate trees
        //#if 0
        //const int MDC_NUM_LEVELS = 5;
        //const int MAX_NUM_ST_TREES = ;
        DeepCoalescence mdcSolver( listGeneTreePtrs, numMDCLevels);
        if( maxNumMDCMoreClades > 0 )
        {
            mdcSolver.SetMaxCladeNumLimit(maxNumMDCMoreClades);
        }
        mdcSolver.SetIncMoreCladFlag(fMDCMoreClades);
        mdcSolver.SetMultiplictyofTrees(listMultiplicity);
        int mdcRes = mdcSolver.FindMDCHeu();
        if( mdcRes < 0 )
        {
            if( fVerbose )
            {
                cout << "Heuristic MDC search found no candidate species tree. Now apply full MDC...\n";
            }
            // then try full-range search
            mdcRes = mdcSolver.FindMDC();
        }
        
        //	cout << "MDC result = " << mdcRes << endl;
        vector<set<string> > listNewickTrees;
        //cout << "********Now start outputting the near optimal speicies tree...\n";
        int numTreeTot = mdcSolver.RetrieveNearOptSTrees( listNewickTrees, numTreeSamples);
        if( fVerbose )
        {
            cout << "Total number of initial trees to start exploring: " << numTreeTot << endl;
        }
#if 0
        int lvCur = 1;
        for( vector<set<string> > :: iterator it = listNewickTrees.begin(); it != listNewickTrees.end(); ++it)
        {
            cout << "Level: " << lvCur++ << endl;
            for( set<string> :: iterator it2 = it->begin(); it2 != it->end(); ++it2)
            {
                cout << *it2 << endl;
            }
        }
#endif
        
        // merge all the trees. Reverse the order so the parsimonious trees will be explored earlier
        //for( int lv = (int)listNewickTrees.size()-1; lv >=0; lv-- )
        for( int lv = 0; lv < (int)listNewickTrees.size(); lv++ )
        {
            //cout << "Level: " << lvCur++ << endl;
            for( set<string> :: iterator it2 = listNewickTrees[lv].begin(); it2 != listNewickTrees[lv].end(); ++it2)
            {
                vecNWParsTrees.push_back( *it2 );
            }
        }
    }
    else
    {
        //
        fDiffTaxaInGTrees = true;
        int numSpecies = GetNumSpeciesFromGTs(listGeneTreePtrs);
        SpeciesTreeBuilderHeuGTSplits streeExplorer3( numSpecies, listGeneTreePtrs, listMultiplicity, mapperTaxaIds );
        streeExplorer3.Infer(true);
        string strHeuTree = streeExplorer3.GetNWTreeInfChangedTaxon();
        // YW: in the new version of species tree, do want the original species
        //if( fFastCoal == true )
        //{
        //    strHeuTree = streeExplorer3.GetNWTreeInf();
        //}
        vecNWParsTrees.push_back(strHeuTree);
    }
    
    
}

